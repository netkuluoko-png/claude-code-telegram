"""Quick state checker: full per-contact info + DB state + logs."""

import asyncio
import json
from datetime import date
from pathlib import Path

import aiosqlite


async def main() -> None:
    db_path = Path("data/logist.db")
    log_path = Path("logs") / f"logist_{date.today().isoformat()}.log"

    async with aiosqlite.connect(str(db_path)) as db:
        db.row_factory = aiosqlite.Row

        # --- Per-contact full profile ---
        async with db.execute(
            "SELECT * FROM contacts ORDER BY last_seen DESC"
        ) as c:
            contacts = [dict(r) for r in await c.fetchall()]

        for ct in contacts:
            cid = ct["id"]
            print(f"\n{'='*60}")
            print(f"CONTACT: {ct['first_name']} | type={ct['type']} | "
                  f"tg_id={ct['tg_id']} | msgs={ct['total_messages']}")
            print(f"  id={cid}")
            print(f"  first_seen={ct['first_seen']} | last_seen={ct['last_seen']}")

            # Psychology
            async with db.execute(
                "SELECT * FROM contact_psychology WHERE contact_id=?", (cid,)
            ) as c2:
                psy = await c2.fetchone()
                if psy:
                    p = dict(psy)
                    del p["contact_id"]
                    non_null = {k: v for k, v in p.items() if v is not None}
                    if non_null:
                        print(f"  psychology: {non_null}")

            # Reliability
            async with db.execute(
                "SELECT * FROM contact_reliability WHERE contact_id=?", (cid,)
            ) as c2:
                rel = await c2.fetchone()
                if rel:
                    r = dict(rel)
                    del r["contact_id"]
                    non_default = {k: v for k, v in r.items()
                                   if v and v != 0 and v != "unknown"}
                    if non_default:
                        print(f"  reliability: {non_default}")

            # Routes
            async with db.execute(
                "SELECT from_city, to_city, frequency FROM contact_routes "
                "WHERE contact_id=?", (cid,)
            ) as c2:
                routes = await c2.fetchall()
                if routes:
                    print(f"  routes: {[f'{r[0]}->{r[1]} (x{r[2]})' for r in routes]}")

            # Phones
            async with db.execute(
                "SELECT phone, source FROM contact_phones WHERE contact_id=?", (cid,)
            ) as c2:
                phones = await c2.fetchall()
                if phones:
                    print(f"  phones: {[f'{r[0]} ({r[1]})' for r in phones]}")

            # Source groups
            async with db.execute(
                "SELECT group_name FROM contact_source_groups WHERE contact_id=?", (cid,)
            ) as c2:
                groups = await c2.fetchall()
                if groups:
                    print(f"  source_groups: {[r[0] for r in groups]}")

            # Price records
            async with db.execute(
                "SELECT route_from, route_to, price, currency, date, source "
                "FROM price_records WHERE contact_id=? ORDER BY date DESC LIMIT 5",
                (cid,),
            ) as c2:
                prices = await c2.fetchall()
                if prices:
                    for pr in prices:
                        print(f"  price: {pr[0]}->{pr[1]} = {pr[2]} {pr[3]} "
                              f"({pr[4]}, {pr[5]})")

            # Active deals
            async with db.execute(
                "SELECT id, status, route_from, route_to, customer_price, "
                "carrier_price, margin, departure_date FROM deals "
                "WHERE customer_contact_id=? OR carrier_contact_id=? "
                "ORDER BY created_at DESC LIMIT 5", (cid, cid),
            ) as c2:
                deals = await c2.fetchall()
                if deals:
                    for d in deals:
                        print(f"  deal: {d[0][:12]}.. | {d[1]} | "
                              f"{d[2]}->{d[3]} | cust={d[4]} carr={d[5]} "
                              f"margin={d[6]} | {d[7]}")

            # Messages (last 5)
            async with db.execute(
                "SELECT direction, substr(text,1,120) as txt, deal_id, "
                "created_at FROM messages WHERE contact_id=? "
                "ORDER BY created_at DESC LIMIT 5", (cid,),
            ) as c2:
                msgs = await c2.fetchall()
                if msgs:
                    print("  messages:")
                    for m in msgs:
                        deal = f" [deal:{m[2][:8]}]" if m[2] else ""
                        print(f"    {m[0]:3s} | {m[3]} | {m[1]}{deal}")

        # --- Global state ---
        print(f"\n{'='*60}")
        print("GLOBAL STATE")

        async with db.execute("SELECT count(*) FROM cargo_offers WHERE status='open'") as c:
            print(f"  cargo_offers (open): {(await c.fetchone())[0]}")
        async with db.execute("SELECT count(*) FROM cargo_offers") as c:
            print(f"  cargo_offers (total): {(await c.fetchone())[0]}")
        async with db.execute("SELECT count(*) FROM deals") as c:
            print(f"  deals: {(await c.fetchone())[0]}")
        async with db.execute("SELECT count(*) FROM messages") as c:
            print(f"  messages: {(await c.fetchone())[0]}")
        async with db.execute("SELECT count(*) FROM price_records") as c:
            print(f"  price_records: {(await c.fetchone())[0]}")
        async with db.execute("SELECT count(*) FROM unprocessed_messages WHERE processed=0") as c:
            print(f"  unprocessed_queue: {(await c.fetchone())[0]}")
        async with db.execute("SELECT currency, rate_uah, date FROM exchange_rates") as c:
            for r in await c.fetchall():
                print(f"  exchange: {r[0]} = {r[1]} UAH ({r[2]})")

    # --- Filtered logs ---
    if log_path.exists():
        lines = log_path.read_text(encoding="utf-8").splitlines()
        meaningful = [
            l for l in lines
            if "getUpdates" not in l
            and "telethon.crypto" not in l
            and "deleteWebhook" not in l
        ]
        print(f"\n{'='*60}")
        print(f"LOGS (last 25, filtered)")
        for l in meaningful[-25:]:
            print(l)


if __name__ == "__main__":
    asyncio.run(main())
