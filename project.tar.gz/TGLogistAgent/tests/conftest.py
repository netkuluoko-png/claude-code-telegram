"""Shared test fixtures."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import AsyncGenerator

import aiosqlite
import pytest
import pytest_asyncio

from src.db.database import init_db
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.config_repo import ConfigRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository

TEST_DB = ":memory:"


@pytest_asyncio.fixture
async def db() -> AsyncGenerator[aiosqlite.Connection, None]:
    """In-memory test database with schema initialized."""
    conn = await init_db(TEST_DB)
    try:
        yield conn
    finally:
        await conn.close()


@pytest_asyncio.fixture
async def contact_repo(db: aiosqlite.Connection) -> ContactRepository:
    return ContactRepository(db)


@pytest_asyncio.fixture
async def cargo_repo(db: aiosqlite.Connection) -> CargoRepository:
    return CargoRepository(db)


@pytest_asyncio.fixture
async def deal_repo(db: aiosqlite.Connection) -> DealRepository:
    return DealRepository(db)


@pytest_asyncio.fixture
async def message_repo(db: aiosqlite.Connection) -> MessageRepository:
    return MessageRepository(db)


@pytest_asyncio.fixture
async def config_repo(db: aiosqlite.Connection) -> ConfigRepository:
    return ConfigRepository(db)
