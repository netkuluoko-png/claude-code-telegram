"""Tests for ContactBriefingService."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from src.agent.codex import PromptLoader
from src.agent.context import ContextAssembler
from src.bot.contact_briefing import ContactBriefingService
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository
from src.models.ai_outputs import ContactBriefingOutput
from src.services.claude_client import ClaudeClient


@pytest.fixture
def mock_claude() -> ClaudeClient:
    client = ClaudeClient.__new__(ClaudeClient)
    client._client = AsyncMock()
    client._model = "test"
    return client


@pytest.fixture
def briefing_service(
    mock_claude: ClaudeClient,
    contact_repo: ContactRepository,
    deal_repo: DealRepository,
    cargo_repo: CargoRepository,
    message_repo: MessageRepository,
) -> ContactBriefingService:
    assembler = ContextAssembler(
        contact_repo, deal_repo, cargo_repo, message_repo,
    )
    return ContactBriefingService(
        mock_claude, PromptLoader(), assembler,
    )


class TestContactBriefing:
    async def test_generate_briefing(
        self,
        briefing_service: ContactBriefingService,
        mock_claude: ClaudeClient,
        contact_repo: ContactRepository,
    ) -> None:
        contact = await contact_repo.create(tg_id=8001, first_name="Василь")

        expected = ContactBriefingOutput(
            briefing_text="📋 БРИФІНГ: Василь\nТип: unknown",
            likely_intent="Новий контакт без активних угод",
            urgency="low",
            suggested_talking_points=["Познайомитись"],
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await briefing_service.generate_briefing(contact.id)
        assert result.briefing_text.startswith("📋")
        assert result.urgency == "low"
        assert len(result.suggested_talking_points) == 1

    def test_format_context(
        self, briefing_service: ContactBriefingService
    ) -> None:
        ctx = {
            "contact": {"name": "Тест", "type": "carrier"},
            "active_deals": [],
            "recent_deal_events": [],
            "recent_messages": [
                {"from": "contact", "text": "Привіт", "date": "2026-03-30"},
            ],
            "our_open_cargos": [],
            "current_date": "2026-03-30",
        }
        text = briefing_service._format_context(ctx)
        assert "ПРОФІЛЬ КОНТАКТУ" in text
        assert "ОСТАННІ ПОВІДОМЛЕННЯ" in text
        assert "2026-03-30" in text
