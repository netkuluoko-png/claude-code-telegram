"""Tests for ApplicationTemplate."""

from __future__ import annotations

from datetime import date

import pytest

from src.deals.templates import ApplicationTemplate
from src.models.contact import Contact
from src.models.deal import Deal


@pytest.fixture
def template() -> ApplicationTemplate:
    return ApplicationTemplate()


@pytest.fixture
def deal() -> Deal:
    return Deal(
        id="d-test-12345678",
        route_from="Гданськ",
        route_to="Київ",
        container_type="40HC",
        departure_date=date(2026, 4, 1),
        customer_price=1800.0,
        customer_currency="EUR",
        carrier_price=1500.0,
        carrier_currency="EUR",
    )


@pytest.fixture
def customer() -> Contact:
    return Contact(
        id="c-customer", tg_id=1000,
        first_name="Олег", last_name="Шевченко",
        tg_username="oleg_customer",
    )


@pytest.fixture
def carrier() -> Contact:
    return Contact(
        id="c-carrier", tg_id=2000,
        first_name="Василь",
        tg_username="vasyl_carrier",
    )


class TestApplicationTemplate:
    def test_customer_application_has_customer_price(
        self, template: ApplicationTemplate, deal: Deal,
        customer: Contact, carrier: Contact,
    ) -> None:
        text = template.generate_for_customer(deal, customer, carrier)
        assert "1800" in text
        assert "1500" not in text  # Ціна перевізника НЕ видна замовнику
        assert "Гданськ" in text
        assert "Київ" in text

    def test_carrier_application_has_carrier_price(
        self, template: ApplicationTemplate, deal: Deal,
        customer: Contact, carrier: Contact,
    ) -> None:
        text = template.generate_for_carrier(deal, customer, carrier)
        assert "1500" in text
        assert "1800" not in text  # Ціна замовника НЕ видна перевізнику
        assert "Гданськ" in text

    def test_different_prices_for_parties(
        self, template: ApplicationTemplate, deal: Deal,
        customer: Contact, carrier: Contact,
    ) -> None:
        """Critical test: each party sees ONLY their own price."""
        customer_app = template.generate_for_customer(deal, customer, carrier)
        carrier_app = template.generate_for_carrier(deal, customer, carrier)
        assert customer_app != carrier_app

    def test_contact_formatting(
        self, template: ApplicationTemplate, deal: Deal,
        customer: Contact, carrier: Contact,
    ) -> None:
        text = template.generate_for_customer(deal, customer, carrier)
        assert "Олег Шевченко (@oleg_customer)" in text
        assert "Василь (@vasyl_carrier)" in text

    def test_deal_id_in_header(
        self, template: ApplicationTemplate, deal: Deal,
        customer: Contact, carrier: Contact,
    ) -> None:
        text = template.generate_for_customer(deal, customer, carrier)
        assert "d-test-12345" in text
