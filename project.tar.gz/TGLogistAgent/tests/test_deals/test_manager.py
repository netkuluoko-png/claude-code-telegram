"""Tests for DealManager."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from src.config import AgentConfig
from src.db.repositories.base import new_id
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository
from src.deals.manager import DealManager
from src.exceptions import DealNotFoundError, InvalidDealTransitionError
from src.models.ai_outputs import MatcherCandidate
from src.models.cargo import CargoOffer
from src.models.deal import Deal
from src.notifications.notifier import Notifier


@pytest.fixture
def mock_notifier() -> Notifier:
    n = Notifier(bot_token="", admin_tg_id=0)
    n._bot = AsyncMock()
    n.send = AsyncMock()
    n.send_escalation = AsyncMock()
    n.send_new_match = AsyncMock()
    n.send_deal_confirmed = AsyncMock()
    return n


@pytest.fixture
def mock_client() -> MagicMock:
    client = MagicMock()
    client.send_message = AsyncMock()
    return client


@pytest.fixture
def agent_config() -> AgentConfig:
    config = AgentConfig()
    config._data = {
        "max_carriers_to_contact": "3",
        "response_wait_hours": "2",
    }
    return config


@pytest.fixture
def manager(
    deal_repo: DealRepository,
    cargo_repo: CargoRepository,
    contact_repo: ContactRepository,
    message_repo: MessageRepository,
    mock_notifier: Notifier,
    mock_client: MagicMock,
    agent_config: AgentConfig,
) -> DealManager:
    return DealManager(
        deal_repo=deal_repo,
        cargo_repo=cargo_repo,
        contact_repo=contact_repo,
        message_repo=message_repo,
        notifier=mock_notifier,
        client=mock_client,
        agent_config=agent_config,
    )


class TestCreateDeal:
    async def test_create_from_match(
        self,
        manager: DealManager,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        cargo_repo: CargoRepository,
    ) -> None:
        customer = await contact_repo.create(tg_id=4001, first_name="Олег")
        offer = CargoOffer(
            id=new_id(), type="cargo",
            direction_from="Гданськ", direction_to="Київ",
            raw_text="test", price=1800,
            sender_contact_id=customer.id,
        )
        await cargo_repo.create_offer(offer)

        deal = await manager.create_deal_from_match(offer)
        assert deal.status == "prospecting"
        assert deal.customer_contact_id == customer.id
        assert deal.route_from == "Гданськ"

        # Перевірити event
        events = await deal_repo.get_events(deal.id)
        assert len(events) == 1
        assert events[0].new_value == "prospecting"


class TestTransitions:
    async def test_valid_transition(
        self,
        manager: DealManager,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
    ) -> None:
        customer = await contact_repo.create(tg_id=4002)
        deal = Deal(
            id=new_id(), customer_contact_id=customer.id,
            route_from="А", route_to="Б", status="prospecting",
        )
        await deal_repo.create(deal)

        await manager.transition_status(deal.id, "negotiating")
        updated = await deal_repo.get_by_id(deal.id)
        assert updated is not None
        assert updated.status == "negotiating"

    async def test_invalid_transition(
        self,
        manager: DealManager,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
    ) -> None:
        customer = await contact_repo.create(tg_id=4003)
        deal = Deal(
            id=new_id(), customer_contact_id=customer.id,
            route_from="А", route_to="Б", status="prospecting",
        )
        await deal_repo.create(deal)

        with pytest.raises(InvalidDealTransitionError):
            await manager.transition_status(deal.id, "completed")

    async def test_transition_nonexistent_deal(self, manager: DealManager) -> None:
        with pytest.raises(DealNotFoundError):
            await manager.transition_status("nonexistent", "negotiating")


class TestCarrierSearch:
    async def test_initiate_search(
        self,
        manager: DealManager,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        mock_client: MagicMock,
    ) -> None:
        customer = await contact_repo.create(tg_id=4010)
        carrier = await contact_repo.create(tg_id=4011, first_name="Перевізник")

        deal = Deal(
            id=new_id(), customer_contact_id=customer.id,
            route_from="Гданськ", route_to="Київ", status="prospecting",
        )
        await deal_repo.create(deal)

        candidates = [
            MatcherCandidate(
                contact_id=carrier.id, name="Перевізник",
                reliability=85, priority=1,
                message_draft="Гданськ→Київ, 40HC, 01.04. Вільні?",
            ),
        ]

        sent = await manager.initiate_carrier_search(deal, candidates)
        assert sent == 1
        mock_client.send_message.assert_called_once()

        # Статус змінився на negotiating
        updated = await deal_repo.get_by_id(deal.id)
        assert updated is not None
        assert updated.status == "negotiating"

    async def test_skip_carrier_with_active_deal(
        self,
        manager: DealManager,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        mock_client: MagicMock,
    ) -> None:
        customer = await contact_repo.create(tg_id=4020)
        carrier = await contact_repo.create(tg_id=4021)

        # Створити активну угоду з перевізником
        existing = Deal(
            id=new_id(), carrier_contact_id=carrier.id,
            route_from="А", route_to="Б", status="negotiating",
        )
        await deal_repo.create(existing)

        # Нова угода
        deal = Deal(
            id=new_id(), customer_contact_id=customer.id,
            route_from="Гданськ", route_to="Київ", status="prospecting",
        )
        await deal_repo.create(deal)

        candidates = [
            MatcherCandidate(
                contact_id=carrier.id, name="Busy",
                reliability=85, priority=1,
                message_draft="test",
            ),
        ]

        sent = await manager.initiate_carrier_search(deal, candidates)
        assert sent == 0  # Пропущений через активну угоду


class TestEscalation:
    async def test_escalate_deal(
        self,
        manager: DealManager,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        mock_notifier: Notifier,
    ) -> None:
        customer = await contact_repo.create(tg_id=4030, first_name="Олег")
        deal = Deal(
            id=new_id(), customer_contact_id=customer.id,
            route_from="А", route_to="Б", status="negotiating",
        )
        await deal_repo.create(deal)

        await manager.escalate(deal.id, "конфлікт")

        updated = await deal_repo.get_by_id(deal.id)
        assert updated is not None
        assert updated.escalated is True
        mock_notifier.send_escalation.assert_called_once()

    async def test_cancel_deal(
        self,
        manager: DealManager,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
    ) -> None:
        customer = await contact_repo.create(tg_id=4040)
        deal = Deal(
            id=new_id(), customer_contact_id=customer.id,
            route_from="А", route_to="Б", status="negotiating",
        )
        await deal_repo.create(deal)

        await manager.cancel_deal(deal.id, "не актуально", "operator")
        updated = await deal_repo.get_by_id(deal.id)
        assert updated is not None
        assert updated.status == "cancelled"
