"""Tests for Responder with mocked Claude client."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from src.agent.codex import PromptLoader
from src.agent.responder import Responder
from src.models.ai_outputs import ResponderAction, ResponderOutput
from src.services.claude_client import ClaudeClient


@pytest.fixture
def mock_claude() -> ClaudeClient:
    client = ClaudeClient.__new__(ClaudeClient)
    client._client = AsyncMock()
    client._model = "test"
    return client


@pytest.fixture
def responder(mock_claude: ClaudeClient) -> Responder:
    return Responder(mock_claude, PromptLoader())


class TestResponder:
    async def test_generate_deal_response(
        self, responder: Responder, mock_claude: ClaudeClient
    ) -> None:
        expected = ResponderOutput(
            context_type="deal_response",
            deal_id="d-123",
            response_text="1500€, Гданськ→Київ.",
            actions=[ResponderAction(type="none")],
            confidence=0.95,
            internal_note="Price inquiry for existing deal",
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        ctx = {
            "contact": {"name": "Василь", "type": "carrier"},
            "active_deals": [{"deal_id": "d-123", "route": "Гданськ→Київ"}],
            "recent_messages": [],
            "new_message": "Яка ціна?",
        }
        result = await responder.generate_response(ctx)

        assert result.context_type == "deal_response"
        assert result.response_text == "1500€, Гданськ→Київ."
        assert result.confidence == 0.95

    async def test_generate_escalation_action(
        self, responder: Responder, mock_claude: ClaudeClient
    ) -> None:
        expected = ResponderOutput(
            context_type="complaint",
            response_text="Очікуйте, уточнюю.",
            actions=[ResponderAction(type="escalate", reason="конфлікт")],
            confidence=0.6,
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        ctx = {
            "contact": {"name": "Тест"},
            "active_deals": [],
            "recent_messages": [],
            "new_message": "Ви мене обманули!",
        }
        result = await responder.generate_response(ctx)

        assert result.confidence == 0.6
        assert any(a.type == "escalate" for a in result.actions)

    def test_format_context(self, responder: Responder) -> None:
        ctx = {
            "contact": {"name": "Олег", "type": "customer"},
            "active_deals": [{"deal_id": "d1", "route": "А→Б"}],
            "recent_messages": [
                {"from": "contact", "text": "Привіт", "date": "2026-03-30"},
            ],
            "new_message": "Яка ціна?",
        }
        text = responder._format_context_as_user_message(ctx)
        assert "ПРОФІЛЬ КОНТАКТУ" in text
        assert "АКТИВНІ УГОДИ" in text
        assert "НОВЕ ПОВІДОМЛЕННЯ" in text
        assert "Яка ціна?" in text
