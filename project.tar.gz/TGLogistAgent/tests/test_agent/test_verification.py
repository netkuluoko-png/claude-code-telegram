"""Tests for VerificationAgent."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from src.agent.codex import PromptLoader
from src.agent.context import ContextAssembler
from src.agent.verification import VerificationAgent
from src.db.repositories.base import new_id
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository
from src.models.ai_outputs import VerificationEvidence, VerificationOutput
from src.models.deal import Deal, DriverContact
from src.services.claude_client import ClaudeClient


@pytest.fixture
def mock_claude() -> ClaudeClient:
    client = ClaudeClient.__new__(ClaudeClient)
    client._client = AsyncMock()
    client._model = "test"
    return client


@pytest.fixture
def agent(
    mock_claude: ClaudeClient,
    contact_repo: ContactRepository,
    deal_repo: DealRepository,
    cargo_repo: CargoRepository,
    message_repo: MessageRepository,
) -> VerificationAgent:
    assembler = ContextAssembler(contact_repo, deal_repo, cargo_repo, message_repo)
    return VerificationAgent(mock_claude, PromptLoader(), assembler, deal_repo)


class TestVerification:
    async def test_verified_driver(
        self,
        agent: VerificationAgent,
        mock_claude: ClaudeClient,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
    ) -> None:
        carrier = await contact_repo.create(tg_id=6001)
        deal = Deal(
            id=new_id(), carrier_contact_id=carrier.id,
            route_from="А", route_to="Б", status="agreed",
        )
        await deal_repo.create(deal)

        driver = DriverContact(
            id=new_id(), deal_id=deal.id,
            carrier_contact_id=carrier.id,
            driver_name="Петро",
            driver_phone="+380991112233",
            driver_tg_id=6099,
        )
        await deal_repo.add_driver(driver)

        expected = VerificationOutput(
            verdict="verified_driver",
            confidence=0.95,
            reason="Phone matches",
            evidence=VerificationEvidence(phone_match=True),
            recommended_action="grant_limited_access",
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await agent.verify(claimer_tg_id=6099)
        assert result.verdict == "verified_driver"

    async def test_suspicious_duplicate(
        self,
        agent: VerificationAgent,
        mock_claude: ClaudeClient,
    ) -> None:
        expected = VerificationOutput(
            verdict="suspicious",
            confidence=0.5,
            reason="Name match but no phone",
            evidence=VerificationEvidence(name_match=True, shared_groups_count=2),
            recommended_action="escalate_to_operator",
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await agent.verify(claimer_tg_id=6200)
        assert result.verdict == "suspicious"
        assert result.recommended_action == "escalate_to_operator"

    async def test_unverified(
        self,
        agent: VerificationAgent,
        mock_claude: ClaudeClient,
    ) -> None:
        expected = VerificationOutput(
            verdict="unverified",
            confidence=0.1,
            reason="No matches",
            recommended_action="deny_and_suggest_main_account",
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await agent.verify(claimer_tg_id=6300)
        assert result.verdict == "unverified"

    async def test_check_driver_quick_by_phone(
        self,
        agent: VerificationAgent,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
    ) -> None:
        carrier = await contact_repo.create(tg_id=6401)
        deal = Deal(
            id=new_id(), carrier_contact_id=carrier.id,
            route_from="А", route_to="Б",
        )
        await deal_repo.create(deal)

        driver = DriverContact(
            id=new_id(), deal_id=deal.id,
            carrier_contact_id=carrier.id,
            driver_name="Іван",
            driver_phone="+380667778899",
        )
        await deal_repo.add_driver(driver)

        result = await agent.check_driver(tg_id=0, phone="0667778899")
        assert result.verdict == "verified_driver"
        assert result.confidence == 0.95
