"""Tests for Matcher with mocked Claude client."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from src.agent.codex import PromptLoader
from src.agent.context import ContextAssembler
from src.agent.matcher import Matcher
from src.config import AgentConfig
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository
from src.models.ai_outputs import MatcherCandidate, MatcherOutput
from src.models.cargo import CargoOffer
from src.db.repositories.base import new_id
from src.services.claude_client import ClaudeClient


@pytest.fixture
def mock_claude() -> ClaudeClient:
    client = ClaudeClient.__new__(ClaudeClient)
    client._client = AsyncMock()
    client._model = "test"
    return client


@pytest.fixture
def agent_config() -> AgentConfig:
    config = AgentConfig()
    config._data = {
        "margin_threshold_usd": "100",
        "max_carriers_to_contact": "3",
        "active_mode_enabled": "1",
        "min_reliability_for_active": "50",
    }
    return config


@pytest.fixture
def matcher(
    mock_claude: ClaudeClient,
    agent_config: AgentConfig,
    contact_repo: ContactRepository,
    deal_repo: DealRepository,
    cargo_repo: CargoRepository,
    message_repo: MessageRepository,
) -> Matcher:
    assembler = ContextAssembler(contact_repo, deal_repo, cargo_repo, message_repo)
    return Matcher(mock_claude, PromptLoader(), assembler, agent_config)


def _make_cargo(**kwargs) -> CargoOffer:  # type: ignore[no-untyped-def]
    defaults = {
        "id": new_id(),
        "type": "cargo",
        "direction_from": "Гданськ",
        "direction_to": "Київ",
        "raw_text": "test",
        "price": 1800,
        "price_currency": "EUR",
    }
    defaults.update(kwargs)
    return CargoOffer(**defaults)


class TestMatcher:
    async def test_evaluate_active(
        self, matcher: Matcher, mock_claude: ClaudeClient
    ) -> None:
        expected = MatcherOutput(
            action="active",
            reason="Маржа ~350€, є перевізники",
            estimated_margin=350.0,
            candidates=[
                MatcherCandidate(
                    contact_id="c1", name="Василь",
                    reliability=85, priority=1,
                    message_draft="Гданськ→Київ, 40HC, 22т, 01.04. Вільні?",
                ),
            ],
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await matcher.evaluate(_make_cargo())
        assert result.action == "active"
        assert result.estimated_margin == 350.0
        assert len(result.candidates) == 1

    async def test_evaluate_passive(
        self, matcher: Matcher, mock_claude: ClaudeClient
    ) -> None:
        expected = MatcherOutput(
            action="passive",
            reason="Ціна невідома",
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await matcher.evaluate(_make_cargo(price=None))
        assert result.action == "passive"

    async def test_evaluate_skip(
        self, matcher: Matcher, mock_claude: ClaudeClient
    ) -> None:
        expected = MatcherOutput(
            action="skip",
            reason="Немає перевізників",
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await matcher.evaluate(_make_cargo())
        assert result.action == "skip"

    async def test_active_mode_disabled(
        self, matcher: Matcher
    ) -> None:
        matcher._agent_config._data["active_mode_enabled"] = "0"
        result = await matcher.evaluate(_make_cargo())
        assert result.action == "passive"
        assert "disabled" in result.reason.lower()

    def test_system_prompt_has_margin(self, matcher: Matcher) -> None:
        prompt = matcher._build_system_prompt()
        assert "100" in prompt  # margin_threshold_usd
