"""Tests for ContextAssembler."""

from __future__ import annotations

import pytest

from src.agent.context import ContextAssembler
from src.db.repositories.base import new_id
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository
from src.models.cargo import CargoOffer
from src.models.deal import Deal


@pytest.fixture
def assembler(
    contact_repo: ContactRepository,
    deal_repo: DealRepository,
    cargo_repo: CargoRepository,
    message_repo: MessageRepository,
) -> ContextAssembler:
    return ContextAssembler(contact_repo, deal_repo, cargo_repo, message_repo)


class TestForResponder:
    async def test_basic_context(
        self, assembler: ContextAssembler, contact_repo: ContactRepository
    ) -> None:
        contact = await contact_repo.create(tg_id=9001, first_name="Тест")

        ctx = await assembler.for_responder(contact.id, "Привіт")
        assert ctx["new_message"] == "Привіт"
        assert "contact" in ctx
        assert ctx["contact"]["name"] == "Тест"
        assert ctx["active_deals"] == []
        assert ctx["recent_messages"] == []

    async def test_context_with_deals_and_messages(
        self,
        assembler: ContextAssembler,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        message_repo: MessageRepository,
    ) -> None:
        contact = await contact_repo.create(tg_id=9002, first_name="Олег")
        deal = Deal(
            id=new_id(), customer_contact_id=contact.id,
            route_from="Гданськ", route_to="Київ",
            customer_price=1800, status="negotiating",
        )
        await deal_repo.create(deal)
        await message_repo.save_message(
            contact_id=contact.id, source="dm",
            direction="in", text="Яка ціна?",
        )

        ctx = await assembler.for_responder(contact.id, "Вільні?")
        assert len(ctx["active_deals"]) == 1
        assert ctx["active_deals"][0]["route"] == "Гданськ→Київ"
        assert len(ctx["recent_messages"]) == 1
        assert ctx["recent_messages"][0]["text"] == "Яка ціна?"


class TestForMatcher:
    async def test_matcher_context(
        self,
        assembler: ContextAssembler,
        cargo_repo: CargoRepository,
    ) -> None:
        offer = CargoOffer(
            id=new_id(), type="cargo",
            direction_from="Гданськ", direction_to="Київ",
            raw_text="test", price=1800,
        )
        ctx = await assembler.for_matcher(offer)
        assert ctx["cargo"]["route_from"] == "Гданськ"
        assert ctx["cargo"]["price"] == 1800
        assert "usd_rate" in ctx
        assert "candidate_carriers" in ctx


class TestForContactBriefing:
    async def test_briefing_context(
        self,
        assembler: ContextAssembler,
        contact_repo: ContactRepository,
    ) -> None:
        contact = await contact_repo.create(tg_id=9003, first_name="Василь")
        await contact_repo.add_or_update_route(contact.id, "Гданськ", "Київ")

        ctx = await assembler.for_contact_briefing(contact.id)
        assert ctx["contact"]["name"] == "Василь"
        assert "active_deals" in ctx
        assert "recent_messages" in ctx
        assert "current_date" in ctx
