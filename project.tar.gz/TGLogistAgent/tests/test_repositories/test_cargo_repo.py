"""Tests for CargoRepository."""

from datetime import datetime, timedelta

import pytest

from src.db.repositories.base import new_id
from src.db.repositories.cargo_repo import CargoRepository
from src.models.cargo import CargoOffer


def _make_offer(**kwargs) -> CargoOffer:  # type: ignore[no-untyped-def]
    defaults = {
        "id": new_id(),
        "type": "cargo",
        "direction_from": "Гданськ",
        "direction_to": "Київ",
        "raw_text": "Гданськ→Київ 40HC 22т 01.04",
        "status": "open",
    }
    defaults.update(kwargs)
    return CargoOffer(**defaults)


class TestCargoOffers:
    async def test_create_and_get(self, cargo_repo: CargoRepository) -> None:
        offer = _make_offer()
        created_id = await cargo_repo.create_offer(offer)
        assert created_id == offer.id

        found = await cargo_repo.get_by_id(offer.id)
        assert found is not None
        assert found.direction_from == "Гданськ"
        assert found.type == "cargo"

    async def test_get_open_offers(self, cargo_repo: CargoRepository) -> None:
        await cargo_repo.create_offer(_make_offer())
        await cargo_repo.create_offer(_make_offer(type="transport", direction_from="Варшава"))
        await cargo_repo.create_offer(_make_offer(status="expired"))

        all_open = await cargo_repo.get_open_offers()
        assert len(all_open) == 2

        cargo_only = await cargo_repo.get_open_offers(cargo_type="cargo")
        assert len(cargo_only) == 1

        from_warsaw = await cargo_repo.get_open_offers(route_from="Варшава")
        assert len(from_warsaw) == 1

    async def test_update_status(self, cargo_repo: CargoRepository) -> None:
        offer = _make_offer()
        await cargo_repo.create_offer(offer)
        await cargo_repo.update_status(offer.id, "matched")
        updated = await cargo_repo.get_by_id(offer.id)
        assert updated is not None
        assert updated.status == "matched"

    async def test_expire_past_departure(self, cargo_repo: CargoRepository) -> None:
        # Вантаж з минулою датою
        offer = _make_offer(departure_date="2020-01-01")
        await cargo_repo.create_offer(offer)
        count = await cargo_repo.expire_past_departure()
        assert count == 1
        updated = await cargo_repo.get_by_id(offer.id)
        assert updated is not None
        assert updated.status == "expired"


class TestExchangeRates:
    async def test_update_and_get(self, cargo_repo: CargoRepository) -> None:
        await cargo_repo.update_exchange_rate("EUR", 45.5, "2026-03-30")
        rate = await cargo_repo.get_exchange_rate("EUR")
        assert rate == 45.5

    async def test_upsert(self, cargo_repo: CargoRepository) -> None:
        await cargo_repo.update_exchange_rate("USD", 41.0, "2026-03-29")
        await cargo_repo.update_exchange_rate("USD", 41.5, "2026-03-30")
        rate = await cargo_repo.get_exchange_rate("USD")
        assert rate == 41.5

    async def test_nonexistent_currency(self, cargo_repo: CargoRepository) -> None:
        rate = await cargo_repo.get_exchange_rate("GBP")
        assert rate is None
