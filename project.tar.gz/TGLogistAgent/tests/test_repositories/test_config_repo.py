"""Tests for ConfigRepository."""

import pytest

from src.db.repositories.config_repo import ConfigRepository


class TestConfigRepo:
    async def test_get_all_default_values(self, config_repo: ConfigRepository) -> None:
        """Schema seeds 10 default agent_config values."""
        all_cfg = await config_repo.get_all()
        assert "margin_threshold_usd" in all_cfg
        assert all_cfg["margin_threshold_usd"] == "100"
        assert "max_carriers_to_contact" in all_cfg
        assert len(all_cfg) >= 10

    async def test_get_single(self, config_repo: ConfigRepository) -> None:
        value = await config_repo.get("cargo_ttl_hours")
        assert value == "72"

    async def test_get_nonexistent(self, config_repo: ConfigRepository) -> None:
        value = await config_repo.get("nonexistent_key")
        assert value is None

    async def test_set_new_key(self, config_repo: ConfigRepository) -> None:
        await config_repo.set("test_key", "test_value")
        value = await config_repo.get("test_key")
        assert value == "test_value"

    async def test_set_overwrite(self, config_repo: ConfigRepository) -> None:
        await config_repo.set("margin_threshold_usd", "200")
        value = await config_repo.get("margin_threshold_usd")
        assert value == "200"
