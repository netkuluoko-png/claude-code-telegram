"""Tests for ContactRepository."""

import pytest

from src.db.repositories.base import new_id
from src.db.repositories.contact_repo import ContactRepository
from src.models.contact import PriceRecord


class TestContactCRUD:
    async def test_create_and_get_by_tg_id(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=12345, first_name="Олег")
        assert contact.tg_id == 12345
        assert contact.first_name == "Олег"
        assert contact.type == "unknown"

        found = await contact_repo.get_by_tg_id(12345)
        assert found is not None
        assert found.id == contact.id

    async def test_create_and_get_by_id(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=99999, first_name="Василь")
        found = await contact_repo.get_by_id(contact.id)
        assert found is not None
        assert found.first_name == "Василь"

    async def test_get_nonexistent(self, contact_repo: ContactRepository) -> None:
        assert await contact_repo.get_by_tg_id(0) is None
        assert await contact_repo.get_by_id("nonexistent") is None

    async def test_update_last_seen(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=111)
        old_seen = contact.last_seen
        await contact_repo.update_last_seen(contact.id)
        updated = await contact_repo.get_by_id(contact.id)
        assert updated is not None
        # last_seen оновлено (рядкове порівняння ISO)
        assert updated.last_seen >= old_seen

    async def test_increment_messages(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=222)
        assert contact.total_messages == 0
        await contact_repo.increment_messages(contact.id)
        await contact_repo.increment_messages(contact.id)
        updated = await contact_repo.get_by_id(contact.id)
        assert updated is not None
        assert updated.total_messages == 2

    async def test_update_type(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=333)
        assert contact.type == "unknown"
        await contact_repo.update_type(contact.id, "carrier")
        updated = await contact_repo.get_by_id(contact.id)
        assert updated is not None
        assert updated.type == "carrier"


class TestContactPhones:
    async def test_add_and_get_phones(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=444)
        await contact_repo.add_phone(contact.id, "+380631234567")
        await contact_repo.add_phone(contact.id, "+380509876543")
        phones = await contact_repo.get_phones(contact.id)
        assert len(phones) == 2
        assert "+380631234567" in phones

    async def test_duplicate_phone_ignored(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=445)
        await contact_repo.add_phone(contact.id, "+380631234567")
        await contact_repo.add_phone(contact.id, "+380631234567")
        phones = await contact_repo.get_phones(contact.id)
        assert len(phones) == 1

    async def test_search_by_phone(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=446, first_name="Тест")
        await contact_repo.add_phone(contact.id, "+380631234567")
        found = await contact_repo.search_by_phone("0631234567")
        assert found is not None
        assert found.id == contact.id


class TestContactRoutes:
    async def test_add_and_get_routes(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=555)
        await contact_repo.add_or_update_route(contact.id, "Гданськ", "Київ")
        routes = await contact_repo.get_routes(contact.id)
        assert len(routes) == 1
        assert routes[0] == ("Гданськ", "Київ")

    async def test_route_frequency_increment(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=556)
        await contact_repo.add_or_update_route(contact.id, "Гданськ", "Київ")
        await contact_repo.add_or_update_route(contact.id, "Гданськ", "Київ")
        routes = await contact_repo.get_routes(contact.id)
        assert len(routes) == 1  # Один маршрут, не два


class TestContactPsychologyReliability:
    async def test_psychology_initialized(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=666)
        psych = await contact_repo.get_psychology(contact.id)
        assert psych is not None
        assert psych.trust_level == "new"

    async def test_update_psychology(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=667)
        await contact_repo.update_psychology(contact.id, {
            "communication_style": "informal",
            "language": "ru",
        })
        psych = await contact_repo.get_psychology(contact.id)
        assert psych is not None
        assert psych.communication_style == "informal"
        assert psych.language == "ru"

    async def test_reliability_initialized(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=668)
        rel = await contact_repo.get_reliability(contact.id)
        assert rel is not None
        assert rel.overall_reliability == 50

    async def test_recalculate_reliability(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=669)
        await contact_repo.update_reliability(contact.id, {
            "deals_completed": 5,
            "deals_cancelled": 1,
            "communication_culture": 4,
        })
        score = await contact_repo.recalculate_reliability(contact.id)
        # base=50 + completed(5*5=25) - cancelled(1*15=15) + culture((4-3)*5=5) = 65
        assert score == 65


class TestContactSlice:
    async def test_get_contact_slice(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=777, first_name="Тест")
        await contact_repo.add_or_update_route(contact.id, "Гданськ", "Київ")
        await contact_repo.update_psychology(contact.id, {
            "communication_style": "blunt",
            "language": "uk",
        })

        slice_ = await contact_repo.get_contact_slice(contact.id)
        assert slice_ is not None
        assert slice_.name == "Тест"
        assert slice_.style == "blunt"
        assert "Гданськ→Київ" in slice_.active_routes

    async def test_get_full_profile(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=778, first_name="Повний")
        await contact_repo.add_phone(contact.id, "+380991111111")
        await contact_repo.add_or_update_route(contact.id, "Варшава", "Одеса")

        profile = await contact_repo.get_full_profile(contact.id)
        assert profile is not None
        assert profile.contact.first_name == "Повний"
        assert "+380991111111" in profile.phones
        assert ("Варшава", "Одеса") in profile.routes


class TestPriceRecords:
    async def test_add_and_get_price(self, contact_repo: ContactRepository) -> None:
        contact = await contact_repo.create(tg_id=888)
        record = PriceRecord(
            id=new_id(), contact_id=contact.id,
            route_from="Гданськ", route_to="Київ",
            price=1500.0, currency="EUR", date="2026-03-30",
        )
        await contact_repo.add_price_record(record)
        records = await contact_repo.get_price_records(contact.id)
        assert len(records) == 1
        assert records[0].price == 1500.0
