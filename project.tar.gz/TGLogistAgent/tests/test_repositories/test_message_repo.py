"""Tests for MessageRepository."""

import pytest

from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.message_repo import MessageRepository


class TestMessages:
    async def test_save_and_get_recent(
        self, message_repo: MessageRepository, contact_repo: ContactRepository
    ) -> None:
        contact = await contact_repo.create(tg_id=5001, first_name="Тест")
        msg_id = await message_repo.save_message(
            contact_id=contact.id, source="dm", direction="in", text="Привіт",
        )
        assert msg_id

        messages = await message_repo.get_recent_messages(contact.id)
        assert len(messages) == 1
        assert messages[0]["text"] == "Привіт"
        assert messages[0]["direction"] == "in"

    async def test_recent_messages_order(
        self, message_repo: MessageRepository, contact_repo: ContactRepository
    ) -> None:
        contact = await contact_repo.create(tg_id=5002)
        await message_repo.save_message(
            contact_id=contact.id, source="dm", direction="in", text="Перше",
        )
        await message_repo.save_message(
            contact_id=contact.id, source="dm", direction="out", text="Друге",
        )
        messages = await message_repo.get_recent_messages(contact.id, limit=10)
        assert len(messages) == 2
        # Newest first
        assert messages[0]["text"] == "Друге"

    async def test_profiler_processing(
        self, message_repo: MessageRepository, contact_repo: ContactRepository
    ) -> None:
        contact = await contact_repo.create(tg_id=5003)
        await message_repo.save_message(
            contact_id=contact.id, source="dm", direction="in", text="Msg1",
        )
        await message_repo.save_message(
            contact_id=contact.id, source="dm", direction="in", text="Msg2",
        )

        unprocessed = await message_repo.get_unprocessed_for_profiler(contact.id)
        assert len(unprocessed) == 2

        ids = [m["id"] for m in unprocessed]
        await message_repo.mark_profiler_processed(ids)

        unprocessed_after = await message_repo.get_unprocessed_for_profiler(contact.id)
        assert len(unprocessed_after) == 0


class TestUnprocessedQueue:
    async def test_add_and_get(self, message_repo: MessageRepository) -> None:
        row_id = await message_repo.add_unprocessed(
            tg_msg_id=100, tg_user_id=200, chat_id=300,
            text="test", raw_data=None, reason="api_down",
        )
        assert row_id > 0

        queue = await message_repo.get_unprocessed()
        assert len(queue) == 1
        assert queue[0]["reason"] == "api_down"

    async def test_mark_processed(self, message_repo: MessageRepository) -> None:
        row_id = await message_repo.add_unprocessed(
            tg_msg_id=101, tg_user_id=201, chat_id=301,
            text="test2", raw_data=None, reason="parse_error",
        )
        await message_repo.mark_processed(row_id)

        queue = await message_repo.get_unprocessed()
        assert len(queue) == 0

    async def test_count(self, message_repo: MessageRepository) -> None:
        assert await message_repo.get_unprocessed_count() == 0
        await message_repo.add_unprocessed(
            tg_msg_id=102, tg_user_id=202, chat_id=302,
            text="t", raw_data=None, reason="unknown",
        )
        assert await message_repo.get_unprocessed_count() == 1
