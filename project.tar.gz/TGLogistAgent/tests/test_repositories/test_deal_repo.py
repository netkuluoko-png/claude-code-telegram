"""Tests for DealRepository."""

import pytest

from src.db.repositories.base import new_id
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.models.cargo import CargoOffer
from src.models.deal import Deal, DealEvent, DriverContact


class TestDealCRUD:
    async def test_create_and_get(
        self, deal_repo: DealRepository, contact_repo: ContactRepository
    ) -> None:
        customer = await contact_repo.create(tg_id=1001, first_name="Замовник")
        deal = Deal(
            id=new_id(),
            customer_contact_id=customer.id,
            route_from="Гданськ", route_to="Київ",
            status="prospecting",
        )
        created_id = await deal_repo.create(deal)
        found = await deal_repo.get_by_id(created_id)
        assert found is not None
        assert found.route_from == "Гданськ"
        assert found.status == "prospecting"

    async def test_get_active_deals_for_contact(
        self, deal_repo: DealRepository, contact_repo: ContactRepository
    ) -> None:
        customer = await contact_repo.create(tg_id=1002)
        carrier = await contact_repo.create(tg_id=1003)

        deal1 = Deal(id=new_id(), customer_contact_id=customer.id,
                      route_from="Гданськ", route_to="Київ", status="negotiating")
        deal2 = Deal(id=new_id(), carrier_contact_id=carrier.id,
                      route_from="Варшава", route_to="Одеса", status="completed")

        await deal_repo.create(deal1)
        await deal_repo.create(deal2)

        active = await deal_repo.get_active_deals_for_contact(customer.id)
        assert len(active) == 1
        assert active[0].id == deal1.id

        # Completed не має бути в active
        active_carrier = await deal_repo.get_active_deals_for_contact(carrier.id)
        assert len(active_carrier) == 0

    async def test_update_status(
        self, deal_repo: DealRepository, contact_repo: ContactRepository
    ) -> None:
        customer = await contact_repo.create(tg_id=1004)
        deal = Deal(id=new_id(), customer_contact_id=customer.id,
                     route_from="А", route_to="Б", status="prospecting")
        await deal_repo.create(deal)

        await deal_repo.update_status(deal.id, "negotiating", "carrier responded")
        updated = await deal_repo.get_by_id(deal.id)
        assert updated is not None
        assert updated.status == "negotiating"

        # Перевірити event
        events = await deal_repo.get_events(deal.id)
        assert len(events) == 1
        assert events[0].event_type == "status_change"
        assert events[0].old_value == "prospecting"
        assert events[0].new_value == "negotiating"

    async def test_update_prices(
        self, deal_repo: DealRepository, contact_repo: ContactRepository
    ) -> None:
        customer = await contact_repo.create(tg_id=1005)
        deal = Deal(id=new_id(), customer_contact_id=customer.id,
                     route_from="А", route_to="Б")
        await deal_repo.create(deal)

        await deal_repo.update_prices(deal.id, customer_price=1800, carrier_price=1500)
        updated = await deal_repo.get_by_id(deal.id)
        assert updated is not None
        assert updated.customer_price == 1800
        assert updated.carrier_price == 1500
        assert updated.margin == 300

    async def test_escalation(
        self, deal_repo: DealRepository, contact_repo: ContactRepository
    ) -> None:
        customer = await contact_repo.create(tg_id=1006)
        deal = Deal(id=new_id(), customer_contact_id=customer.id,
                     route_from="А", route_to="Б")
        await deal_repo.create(deal)

        await deal_repo.set_escalated(deal.id, "конфлікт з перевізником")
        updated = await deal_repo.get_by_id(deal.id)
        assert updated is not None
        assert updated.escalated is True

        await deal_repo.clear_escalation(deal.id)
        updated = await deal_repo.get_by_id(deal.id)
        assert updated is not None
        assert updated.escalated is False

    async def test_has_active_deal_with_carrier(
        self, deal_repo: DealRepository, contact_repo: ContactRepository
    ) -> None:
        carrier = await contact_repo.create(tg_id=1007)
        deal = Deal(id=new_id(), carrier_contact_id=carrier.id,
                     route_from="А", route_to="Б", status="negotiating")
        await deal_repo.create(deal)

        assert await deal_repo.has_active_deal_with_carrier(carrier.id) is True

        no_carrier = await contact_repo.create(tg_id=1008)
        assert await deal_repo.has_active_deal_with_carrier(no_carrier.id) is False


class TestDriverContacts:
    async def test_add_and_find_driver(
        self, deal_repo: DealRepository, contact_repo: ContactRepository
    ) -> None:
        carrier = await contact_repo.create(tg_id=2001)
        deal = Deal(id=new_id(), carrier_contact_id=carrier.id,
                     route_from="А", route_to="Б")
        await deal_repo.create(deal)

        driver = DriverContact(
            id=new_id(), deal_id=deal.id, carrier_contact_id=carrier.id,
            driver_name="Петро", driver_phone="+380991112233",
        )
        await deal_repo.add_driver(driver)

        found = await deal_repo.get_driver_by_phone("0991112233")
        assert found is not None
        assert found.driver_name == "Петро"

    async def test_verify_driver(
        self, deal_repo: DealRepository, contact_repo: ContactRepository
    ) -> None:
        carrier = await contact_repo.create(tg_id=2002)
        deal = Deal(id=new_id(), carrier_contact_id=carrier.id,
                     route_from="А", route_to="Б")
        await deal_repo.create(deal)

        driver = DriverContact(
            id=new_id(), deal_id=deal.id, carrier_contact_id=carrier.id,
            driver_name="Іван",
        )
        await deal_repo.add_driver(driver)
        assert driver.verified is False

        await deal_repo.verify_driver(driver.id)
        found = await deal_repo.get_driver_by_tg_id(0)  # Не знайде (tg_id not set)
        # Але по ID знайде
        row = await deal_repo._fetch_one(
            "SELECT verified FROM driver_contacts WHERE id = ?", (driver.id,)
        )
        assert row is not None
        assert row["verified"] == 1


class TestDealSummaries:
    async def test_summaries_for_contact(
        self, deal_repo: DealRepository, contact_repo: ContactRepository
    ) -> None:
        customer = await contact_repo.create(tg_id=3001)
        deal = Deal(
            id=new_id(), customer_contact_id=customer.id,
            route_from="Гданськ", route_to="Київ",
            customer_price=1800, status="negotiating",
        )
        await deal_repo.create(deal)

        summaries = await deal_repo.get_deal_summaries_for_contact(customer.id)
        assert len(summaries) == 1
        assert summaries[0].route == "Гданськ→Київ"
        assert summaries[0].my_price == 1800
