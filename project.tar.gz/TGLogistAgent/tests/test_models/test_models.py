"""Tests for Pydantic model validation and serialization."""

import json

import pytest
from pydantic import ValidationError

from src.models.ai_outputs import (
    ContactBriefingOutput,
    MatcherCandidate,
    MatcherOutput,
    ParserDetails,
    ParserOutput,
    ProfilerOutput,
    PsychologyUpdates,
    ResponderAction,
    ResponderOutput,
    VerificationEvidence,
    VerificationOutput,
)
from src.models.cargo import CargoDetails, CargoOffer
from src.models.contact import Contact, ContactSlice, PriceRecord
from src.models.deal import Deal, DealEvent, DealSummary, DriverContact


class TestCargoModels:
    def test_cargo_details_minimal(self) -> None:
        details = CargoDetails(route_from="Гданськ")
        assert details.route_from == "Гданськ"
        assert details.route_to is None
        assert details.price is None

    def test_cargo_details_full(self) -> None:
        details = CargoDetails(
            route_from="Гданськ", route_to="Київ",
            container_type="40HC", weight_tons=22.0,
            price=1800.0, price_currency="EUR",
        )
        assert details.container_type == "40HC"

    def test_cargo_offer_serialization(self) -> None:
        offer = CargoOffer(
            id="test-id", type="cargo",
            direction_from="Гданськ", direction_to="Київ",
            raw_text="test raw text",
        )
        data = offer.model_dump()
        assert data["type"] == "cargo"
        assert data["status"] == "open"
        restored = CargoOffer(**data)
        assert restored.id == offer.id


class TestContactModels:
    def test_contact_defaults(self) -> None:
        contact = Contact(id="c1", tg_id=12345)
        assert contact.type == "unknown"
        assert contact.total_messages == 0

    def test_contact_slice(self) -> None:
        slice_ = ContactSlice(
            id="c-uuid-1", name="Василь", type="carrier", reliability=78,
            active_routes=["Гданськ→Київ"],
        )
        assert slice_.trust_level == "new"

    def test_price_record(self) -> None:
        record = PriceRecord(
            id="pr1", contact_id="c1",
            route_from="Гданськ", route_to="Київ",
            price=1500.0, date="2026-03-30",
        )
        assert record.currency == "EUR"


class TestDealModels:
    def test_deal_defaults(self) -> None:
        deal = Deal(id="d1", route_from="А", route_to="Б")
        assert deal.status == "prospecting"
        assert deal.escalated is False

    def test_deal_summary(self) -> None:
        summary = DealSummary(
            deal_id="d1", route="Гданськ→Київ",
            status="negotiating", my_price=1800.0,
        )
        data = summary.model_dump()
        assert data["status"] == "negotiating"


class TestAIOutputModels:
    def test_parser_output_no_match(self) -> None:
        output = ParserOutput(match=False, reason="Не контейнер")
        assert output.type is None
        assert output.details is None

    def test_parser_output_match(self) -> None:
        output = ParserOutput(
            match=True, type="cargo", reason="Контейнер Гданськ→Київ",
            details=ParserDetails(route_from="Гданськ", route_to="Київ"),
        )
        assert output.details is not None
        assert output.details.route_from == "Гданськ"

    def test_responder_output(self) -> None:
        output = ResponderOutput(
            context_type="deal_response",
            deal_id="d1",
            response_text="Уточню.",
            actions=[ResponderAction(type="ask_clarification")],
            confidence=0.85,
        )
        assert len(output.actions) == 1
        assert output.actions[0].type == "ask_clarification"

    def test_matcher_output(self) -> None:
        output = MatcherOutput(
            action="active", reason="маржа ~350€",
            estimated_margin=350.0,
            candidates=[
                MatcherCandidate(
                    contact_id="c1", name="Василь",
                    reliability=85, priority=1,
                    message_draft="Гданськ→Київ, 40HC, 22т, 30.03. Вільні?",
                ),
            ],
        )
        assert len(output.candidates) == 1

    def test_profiler_output(self) -> None:
        output = ProfilerOutput(
            psychology_updates=PsychologyUpdates(language="ru"),
            notes="Став відкритішим",
        )
        assert output.psychology_updates.language == "ru"

    def test_verification_output(self) -> None:
        output = VerificationOutput(
            verdict="verified_driver", confidence=0.95,
            reason="Phone matches", recommended_action="grant_limited_access",
        )
        assert output.verdict == "verified_driver"

    def test_contact_briefing_output(self) -> None:
        output = ContactBriefingOutput(
            briefing_text="Брифінг...", likely_intent="Ціна",
            urgency="medium", suggested_talking_points=["Ціна"],
        )
        assert output.urgency == "medium"

    def test_responder_output_json_roundtrip(self) -> None:
        output = ResponderOutput(
            context_type="new_offer",
            response_text="Гданськ→Київ, 40HC. Вільні?",
            actions=[
                ResponderAction(type="create_deal", cargo_offer_id="co1"),
                ResponderAction(type="notify_operator", text="Новий матч"),
            ],
            confidence=0.92,
            internal_note="Перший контакт з цим перевізником",
        )
        json_str = output.model_dump_json()
        restored = ResponderOutput.model_validate_json(json_str)
        assert restored.context_type == "new_offer"
        assert len(restored.actions) == 2
