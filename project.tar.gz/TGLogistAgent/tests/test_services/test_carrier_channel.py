"""Tests for CarrierChannelService."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock

import pytest

from src.services.carrier_channel import CarrierChannelService


@pytest.fixture
def mock_client() -> MagicMock:
    client = MagicMock()
    msg = MagicMock()
    msg.id = 42
    client.send_message = AsyncMock(return_value=msg)
    return client


@pytest.fixture
def service(mock_client: MagicMock) -> CarrierChannelService:
    return CarrierChannelService(client=mock_client, channel_id=-1001234)


class TestCarrierChannel:
    async def test_publish_cargo(
        self, service: CarrierChannelService, mock_client: MagicMock
    ) -> None:
        msg_id = await service.publish_cargo(
            route="Гданськ→Київ",
            container_type="40HC",
            weight=22.0,
            departure_date="01.04",
        )
        assert msg_id == 42
        mock_client.send_message.assert_called_once()
        text = mock_client.send_message.call_args[0][1]
        assert "Гданськ→Київ" in text
        assert "40HC" in text
        assert "Хто вільний?" in text

    async def test_skip_duplicate_within_hour(
        self, service: CarrierChannelService
    ) -> None:
        await service.publish_cargo("Гданськ→Київ", "40HC", 22.0, "01.04")
        msg_id = await service.publish_cargo("Гданськ→Київ", "40HC", 22.0, "01.04")
        assert msg_id is None  # Пропущено — вже публікували

    async def test_allow_different_routes(
        self, service: CarrierChannelService
    ) -> None:
        await service.publish_cargo("Гданськ→Київ", "40HC", 22.0, "01.04")
        msg_id = await service.publish_cargo("Варшава→Одеса", "40", 20.0, "02.04")
        assert msg_id == 42  # Інший маршрут — дозволено

    def test_recently_published_check(
        self, service: CarrierChannelService
    ) -> None:
        assert not service.is_recently_published("Гданськ→Київ")

        service._recent_publications["Гданськ→Київ"] = datetime.now(tz=UTC)
        assert service.is_recently_published("Гданськ→Київ")

        # Стара публікація (>1 годину)
        service._recent_publications["Варшава→Одеса"] = (
            datetime.now(tz=UTC) - timedelta(hours=2)
        )
        assert not service.is_recently_published("Варшава→Одеса")

    async def test_no_channel_configured(self, mock_client: MagicMock) -> None:
        service = CarrierChannelService(client=mock_client, channel_id=0)
        msg_id = await service.publish_cargo("test", None, None, None)
        assert msg_id is None
