"""Tests for NBURatesService with mocked httpx."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src.db.repositories.cargo_repo import CargoRepository
from src.services.nbu_rates import NBURatesService


class TestNBURates:
    @pytest.fixture
    def service(self, cargo_repo: CargoRepository) -> NBURatesService:
        return NBURatesService(cargo_repo)

    async def test_fetch_and_update(
        self, service: NBURatesService, cargo_repo: CargoRepository
    ) -> None:
        mock_data = [
            {"cc": "EUR", "rate": 45.5, "txt": "Євро"},
            {"cc": "USD", "rate": 41.2, "txt": "Долар США"},
            {"cc": "GBP", "rate": 52.0, "txt": "Фунт"},
        ]
        mock_resp = MagicMock()
        mock_resp.json.return_value = mock_data
        mock_resp.raise_for_status = MagicMock()

        with patch("src.services.nbu_rates.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.get.return_value = mock_resp
            MockClient.return_value.__aenter__ = AsyncMock(return_value=mock_client)
            MockClient.return_value.__aexit__ = AsyncMock(return_value=False)

            rates = await service.fetch_and_update()

        assert "EUR" in rates
        assert "USD" in rates
        assert rates["EUR"] == 45.5
        assert rates["USD"] == 41.2
        # GBP не має бути (не в target currencies)
        assert "GBP" not in rates

        # Перевірка що записано в БД
        eur_rate = await cargo_repo.get_exchange_rate("EUR")
        assert eur_rate == 45.5
        usd_rate = await cargo_repo.get_exchange_rate("USD")
        assert usd_rate == 41.2

    async def test_convert_to_usd_same_currency(
        self, service: NBURatesService
    ) -> None:
        result = await service.convert_to_usd(100.0, "USD")
        assert result == 100.0

    async def test_convert_to_usd_from_eur(
        self, service: NBURatesService, cargo_repo: CargoRepository
    ) -> None:
        await cargo_repo.update_exchange_rate("EUR", 45.0, "2026-03-30")
        await cargo_repo.update_exchange_rate("USD", 41.0, "2026-03-30")

        result = await service.convert_to_usd(100.0, "EUR")
        # 100 EUR * 45 UAH/EUR / 41 UAH/USD ≈ 109.76 USD
        assert abs(result - 109.76) < 0.1

    async def test_convert_to_usd_from_uah(
        self, service: NBURatesService, cargo_repo: CargoRepository
    ) -> None:
        await cargo_repo.update_exchange_rate("USD", 41.0, "2026-03-30")

        result = await service.convert_to_usd(4100.0, "UAH")
        assert abs(result - 100.0) < 0.01

    async def test_convert_between_currencies(
        self, service: NBURatesService, cargo_repo: CargoRepository
    ) -> None:
        await cargo_repo.update_exchange_rate("EUR", 45.0, "2026-03-30")
        await cargo_repo.update_exchange_rate("USD", 41.0, "2026-03-30")

        result = await service.convert(100.0, "EUR", "USD")
        assert abs(result - 109.76) < 0.1

        # Зворотній напрямок
        result_back = await service.convert(result, "USD", "EUR")
        assert abs(result_back - 100.0) < 0.1
