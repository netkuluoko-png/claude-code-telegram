"""Tests for ClaudeClient with mocked Anthropic API."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from pydantic import BaseModel

from src.exceptions import ClaudeAPIError
from src.services.claude_client import ClaudeClient


class SampleOutput(BaseModel):
    name: str
    value: int


class TestClaudeClientCall:
    @pytest.fixture
    def client(self) -> ClaudeClient:
        return ClaudeClient(api_key="test-key", model="test-model")

    async def test_successful_call(self, client: ClaudeClient) -> None:
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="Hello world")]
        mock_response.usage = MagicMock(input_tokens=10, output_tokens=5)

        with patch.object(client._client.messages, "create", new_callable=AsyncMock, return_value=mock_response):
            result = await client.call(
                system_prompt="test",
                user_message="test",
            )
            assert result == "Hello world"

    async def test_call_json_valid(self, client: ClaudeClient) -> None:
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text='{"name": "test", "value": 42}')]
        mock_response.usage = MagicMock(input_tokens=10, output_tokens=5)

        with patch.object(client._client.messages, "create", new_callable=AsyncMock, return_value=mock_response):
            result = await client.call_json(
                system_prompt="test",
                user_message="test",
                response_model=SampleOutput,
            )
            assert result.name == "test"
            assert result.value == 42

    async def test_call_json_with_markdown_wrapper(self, client: ClaudeClient) -> None:
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text='```json\n{"name": "wrapped", "value": 1}\n```')]
        mock_response.usage = MagicMock(input_tokens=10, output_tokens=5)

        with patch.object(client._client.messages, "create", new_callable=AsyncMock, return_value=mock_response):
            result = await client.call_json(
                system_prompt="test",
                user_message="test",
                response_model=SampleOutput,
            )
            assert result.name == "wrapped"

    async def test_call_json_invalid_json(self, client: ClaudeClient) -> None:
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="not json at all")]
        mock_response.usage = MagicMock(input_tokens=10, output_tokens=5)

        with patch.object(client._client.messages, "create", new_callable=AsyncMock, return_value=mock_response):
            with pytest.raises(ClaudeAPIError, match="Invalid JSON"):
                await client.call_json(
                    system_prompt="test",
                    user_message="test",
                    response_model=SampleOutput,
                )

    async def test_call_json_validation_error(self, client: ClaudeClient) -> None:
        mock_response = MagicMock()
        # missing required field 'value'
        mock_response.content = [MagicMock(text='{"name": "test"}')]
        mock_response.usage = MagicMock(input_tokens=10, output_tokens=5)

        with patch.object(client._client.messages, "create", new_callable=AsyncMock, return_value=mock_response):
            with pytest.raises(ClaudeAPIError, match="validation failed"):
                await client.call_json(
                    system_prompt="test",
                    user_message="test",
                    response_model=SampleOutput,
                )
