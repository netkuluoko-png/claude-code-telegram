"""Tests for Profiler."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from src.agent.codex import PromptLoader
from src.agent.context import ContextAssembler
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository
from src.models.ai_outputs import (
    ProfilerOutput,
    PriceUpdate,
    PsychologyUpdates,
    ReliabilityUpdates,
)
from src.profiler.profiler import Profiler
from src.services.claude_client import ClaudeClient


@pytest.fixture
def mock_claude() -> ClaudeClient:
    client = ClaudeClient.__new__(ClaudeClient)
    client._client = AsyncMock()
    client._model = "test"
    return client


@pytest.fixture
def profiler(
    mock_claude: ClaudeClient,
    contact_repo: ContactRepository,
    deal_repo: DealRepository,
    cargo_repo: CargoRepository,
    message_repo: MessageRepository,
) -> Profiler:
    assembler = ContextAssembler(contact_repo, deal_repo, cargo_repo, message_repo)
    return Profiler(
        mock_claude, PromptLoader(), assembler,
        contact_repo, message_repo,
    )


class TestProfiler:
    async def test_no_unprocessed_messages(
        self,
        profiler: Profiler,
        contact_repo: ContactRepository,
    ) -> None:
        contact = await contact_repo.create(tg_id=7001)
        result = await profiler.update_profile(contact.id)
        assert result is None  # Нічого обробляти

    async def test_psychology_update(
        self,
        profiler: Profiler,
        mock_claude: ClaudeClient,
        contact_repo: ContactRepository,
        message_repo: MessageRepository,
    ) -> None:
        contact = await contact_repo.create(tg_id=7002)
        # Додати повідомлення
        await message_repo.save_message(
            contact_id=contact.id, source="dm", direction="in", text="Привіт",
        )
        await message_repo.save_message(
            contact_id=contact.id, source="dm", direction="in", text="Яка ціна?",
        )

        expected = ProfilerOutput(
            psychology_updates=PsychologyUpdates(
                communication_style="informal",
                language="uk",
            ),
            notes="Контакт спілкується неформально",
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await profiler.update_profile(contact.id)
        assert result is not None
        assert result.psychology_updates.communication_style == "informal"

        # Перевірити що psychology оновлено в БД
        psych = await contact_repo.get_psychology(contact.id)
        assert psych is not None
        assert psych.communication_style == "informal"
        assert psych.language == "uk"

        # Повідомлення позначені як оброблені
        unprocessed = await message_repo.get_unprocessed_for_profiler(contact.id)
        assert len(unprocessed) == 0

    async def test_price_update(
        self,
        profiler: Profiler,
        mock_claude: ClaudeClient,
        contact_repo: ContactRepository,
        message_repo: MessageRepository,
    ) -> None:
        contact = await contact_repo.create(tg_id=7003)
        await message_repo.save_message(
            contact_id=contact.id, source="dm", direction="in", text="1500€",
        )

        expected = ProfilerOutput(
            price_updates=[
                PriceUpdate(
                    route="Гданськ→Київ", price=1500.0,
                    currency="EUR", container_type="40HC",
                ),
            ],
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await profiler.update_profile(contact.id)
        assert result is not None
        assert len(result.price_updates) == 1

        # Перевірити price_record
        records = await contact_repo.get_price_records(contact.id)
        assert len(records) == 1
        assert records[0].price == 1500.0

    async def test_reliability_recalculation(
        self,
        profiler: Profiler,
        mock_claude: ClaudeClient,
        contact_repo: ContactRepository,
        message_repo: MessageRepository,
    ) -> None:
        contact = await contact_repo.create(tg_id=7004)
        await message_repo.save_message(
            contact_id=contact.id, source="dm", direction="in", text="test",
        )

        expected = ProfilerOutput(
            reliability_updates=ReliabilityUpdates(
                communication_culture=5,
            ),
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await profiler.update_profile(contact.id)
        assert result is not None

        # Перевірити reliability перераховано
        rel = await contact_repo.get_reliability(contact.id)
        assert rel is not None
        # base=50 + (culture 5-3)*5 = 60
        assert rel.overall_reliability == 60
