"""Tests for Notifier with mocked Telegram bot."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src.notifications.notifier import Notifier


class TestNotifier:
    def test_unconfigured_notifier(self) -> None:
        """Notifier without token should not crash."""
        notifier = Notifier(bot_token="", admin_tg_id=0)
        assert notifier._bot is None

    async def test_send_message(self) -> None:
        notifier = Notifier(bot_token="fake-token", admin_tg_id=12345)
        notifier._bot = AsyncMock()

        await notifier.send("Test message")
        notifier._bot.send_message.assert_called_once()
        call_kwargs = notifier._bot.send_message.call_args
        assert call_kwargs[1]["chat_id"] == 12345
        assert "Test message" in call_kwargs[1]["text"]

    async def test_send_escalation(self) -> None:
        notifier = Notifier(bot_token="fake-token", admin_tg_id=12345)
        notifier._bot = AsyncMock()

        await notifier.send_escalation(
            contact_name="Василь",
            deal_id="d-123-456-789",
            reason="конфлікт",
            context="Контакт грубить",
        )
        notifier._bot.send_message.assert_called_once()
        text = notifier._bot.send_message.call_args[1]["text"]
        assert "ЕСКАЛАЦІЯ" in text
        assert "Василь" in text
        assert "конфлікт" in text

    async def test_send_new_match(self) -> None:
        notifier = Notifier(bot_token="fake-token", admin_tg_id=12345)
        notifier._bot = AsyncMock()

        await notifier.send_new_match(
            route="Гданськ→Київ",
            customer_name="Олег",
            estimated_margin=350.0,
        )
        text = notifier._bot.send_message.call_args[1]["text"]
        assert "НОВИЙ МАТЧ" in text
        assert "350" in text

    async def test_send_deal_confirmed(self) -> None:
        notifier = Notifier(bot_token="fake-token", admin_tg_id=12345)
        notifier._bot = AsyncMock()

        await notifier.send_deal_confirmed(
            deal_id="d-test-123",
            route="Гданськ→Київ",
            customer_price=1800,
            carrier_price=1500,
            margin=300,
        )
        text = notifier._bot.send_message.call_args[1]["text"]
        assert "УГОДА ПІДТВЕРДЖЕНА" in text
        assert "300" in text
