"""Tests for GroupMonitor with mocked Telethon and Claude."""

from __future__ import annotations

from datetime import date
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src.config import Settings
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.message_repo import MessageRepository
from src.models.ai_outputs import ParserDetails, ParserOutput
from src.models.cargo import CargoOffer
from src.parser.group_monitor import GroupMonitor
from src.parser.message_analyzer import MessageAnalyzer


def _make_event(text: str, sender_tg_id: int = 12345, msg_id: int = 1) -> MagicMock:
    """Create a mock Telethon NewMessage event."""
    event = MagicMock()
    event.message = MagicMock()
    event.message.message = text
    event.message.id = msg_id

    sender = MagicMock()
    sender.id = sender_tg_id
    sender.first_name = "Тест"
    sender.username = "test_user"
    event.get_sender = AsyncMock(return_value=sender)

    chat = MagicMock()
    chat.title = "Turbo-ИМПОРТ"
    chat.id = -1001234
    event.get_chat = AsyncMock(return_value=chat)

    return event


@pytest.fixture
def mock_analyzer() -> MessageAnalyzer:
    analyzer = MagicMock(spec=MessageAnalyzer)
    return analyzer


@pytest.fixture
def mock_client() -> MagicMock:
    return MagicMock()


@pytest.fixture
def config() -> Settings:
    return Settings()


@pytest.fixture
def monitor(
    mock_client: MagicMock,
    mock_analyzer: MessageAnalyzer,
    contact_repo: ContactRepository,
    cargo_repo: CargoRepository,
    message_repo: MessageRepository,
    config: Settings,
) -> GroupMonitor:
    on_new_cargo = AsyncMock()
    return GroupMonitor(
        client=mock_client,
        analyzer=mock_analyzer,
        contact_repo=contact_repo,
        cargo_repo=cargo_repo,
        message_repo=message_repo,
        config=config,
        on_new_cargo=on_new_cargo,
    )


class TestGroupMonitor:
    async def test_handle_cargo_match(
        self,
        monitor: GroupMonitor,
        mock_analyzer: MagicMock,
        contact_repo: ContactRepository,
        cargo_repo: CargoRepository,
    ) -> None:
        """WF-1: message → match=true → cargo_offer created."""
        mock_analyzer.analyze = AsyncMock(return_value=ParserOutput(
            match=True,
            type="cargo",
            reason="Контейнер Гданськ→Київ",
            details=ParserDetails(
                route_from="Гданськ",
                route_to="Київ",
                container_type="40HC",
                weight_tons=22.0,
                price=1800.0,
                price_currency="EUR",
            ),
        ))

        event = _make_event("Гданськ→Київ, 40HC, 22т, 01.04, 1800€")
        await monitor._handle_new_message(event)

        # Контакт створений
        contact = await contact_repo.get_by_tg_id(12345)
        assert contact is not None
        assert contact.total_messages == 1

        # cargo_offer створений
        offers = await cargo_repo.get_open_offers()
        assert len(offers) == 1
        assert offers[0].direction_from == "Гданськ"
        assert offers[0].direction_to == "Київ"
        assert offers[0].price == 1800.0

        # Callback викликаний
        assert monitor._on_new_cargo.called

    async def test_handle_no_match(
        self,
        monitor: GroupMonitor,
        mock_analyzer: MagicMock,
        cargo_repo: CargoRepository,
    ) -> None:
        """WF-1: message → match=false → no cargo_offer."""
        mock_analyzer.analyze = AsyncMock(return_value=ParserOutput(
            match=False,
            reason="Не контейнер",
        ))

        event = _make_event("Продам гараж в Києві")
        await monitor._handle_new_message(event)

        # Жодного cargo_offer
        offers = await cargo_repo.get_open_offers()
        assert len(offers) == 0

        # Callback НЕ викликаний
        assert not monitor._on_new_cargo.called

    async def test_short_message_skipped(
        self,
        monitor: GroupMonitor,
        mock_analyzer: MagicMock,
    ) -> None:
        """Short messages (<10 chars) should be skipped."""
        event = _make_event("Привіт")
        await monitor._handle_new_message(event)
        mock_analyzer.analyze.assert_not_called()

    async def test_contact_type_updated(
        self,
        monitor: GroupMonitor,
        mock_analyzer: MagicMock,
        contact_repo: ContactRepository,
    ) -> None:
        """Contact type updated from unknown → customer for cargo."""
        mock_analyzer.analyze = AsyncMock(return_value=ParserOutput(
            match=True,
            type="cargo",
            reason="test",
            details=ParserDetails(route_from="Гданськ", route_to="Київ"),
        ))

        event = _make_event("Гданськ→Київ 40HC test message")
        await monitor._handle_new_message(event)

        contact = await contact_repo.get_by_tg_id(12345)
        assert contact is not None
        assert contact.type == "customer"

    async def test_route_added(
        self,
        monitor: GroupMonitor,
        mock_analyzer: MagicMock,
        contact_repo: ContactRepository,
    ) -> None:
        """Route added to contact on match."""
        mock_analyzer.analyze = AsyncMock(return_value=ParserOutput(
            match=True,
            type="transport",
            reason="test",
            details=ParserDetails(route_from="Варшава", route_to="Одеса"),
        ))

        event = _make_event("Варшава→Одеса вільний контейнеровоз")
        await monitor._handle_new_message(event)

        contact = await contact_repo.get_by_tg_id(12345)
        assert contact is not None
        routes = await contact_repo.get_routes(contact.id)
        assert ("Варшава", "Одеса") in routes

    async def test_api_error_goes_to_unprocessed(
        self,
        monitor: GroupMonitor,
        mock_analyzer: MagicMock,
        message_repo: MessageRepository,
    ) -> None:
        """Claude API error → message saved to unprocessed queue."""
        from src.exceptions import ClaudeAPIError
        mock_analyzer.analyze = AsyncMock(side_effect=ClaudeAPIError("API down"))

        event = _make_event("Гданськ→Київ контейнер")
        await monitor._handle_new_message(event)

        queue = await message_repo.get_unprocessed()
        assert len(queue) == 1
        assert queue[0]["reason"] == "api_error"
