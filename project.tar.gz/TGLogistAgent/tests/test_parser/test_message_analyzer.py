"""Tests for MessageAnalyzer with mocked Claude client."""

from __future__ import annotations

from datetime import date
from unittest.mock import AsyncMock, patch

import pytest

from src.models.ai_outputs import ParserDetails, ParserOutput
from src.parser.message_analyzer import MessageAnalyzer
from src.services.claude_client import ClaudeClient


@pytest.fixture
def mock_claude() -> ClaudeClient:
    client = ClaudeClient.__new__(ClaudeClient)
    client._client = AsyncMock()
    client._model = "test"
    return client


@pytest.fixture
def analyzer(mock_claude: ClaudeClient) -> MessageAnalyzer:
    return MessageAnalyzer(mock_claude)


class TestMessageAnalyzer:
    async def test_cargo_match(self, analyzer: MessageAnalyzer, mock_claude: ClaudeClient) -> None:
        expected = ParserOutput(
            match=True,
            type="cargo",
            reason="Контейнер 40HC Гданськ→Київ",
            details=ParserDetails(
                route_from="Гданськ",
                route_to="Київ",
                container_type="40HC",
                weight_tons=22.0,
                departure_date="2026-04-01",
                price=1800.0,
                price_currency="EUR",
            ),
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await analyzer.analyze(
            raw_text="Гданськ→Київ, 40HC, 22т, 01.04, 1800€",
            sender_tg_id=12345,
            source_group="Turbo-ИМПОРТ",
            current_date=date(2026, 3, 30),
        )

        assert result.match is True
        assert result.type == "cargo"
        assert result.details is not None
        assert result.details.route_from == "Гданськ"
        assert result.details.price == 1800.0

    async def test_transport_match(self, analyzer: MessageAnalyzer, mock_claude: ClaudeClient) -> None:
        expected = ParserOutput(
            match=True,
            type="transport",
            reason="Вільний контейнеровоз в Гданську",
            details=ParserDetails(route_from="Гданськ"),
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await analyzer.analyze(
            raw_text="Вільний контейнеровоз в Гданську, 40т",
            sender_tg_id=12345,
            source_group="Test Group",
            current_date=date(2026, 3, 30),
        )

        assert result.match is True
        assert result.type == "transport"

    async def test_no_match(self, analyzer: MessageAnalyzer, mock_claude: ClaudeClient) -> None:
        expected = ParserOutput(
            match=False,
            reason="Внутрішнє перевезення по Україні",
        )
        mock_claude.call_json = AsyncMock(return_value=expected)

        result = await analyzer.analyze(
            raw_text="Київ→Одеса, тент, 20т",
            sender_tg_id=12345,
            source_group="Test Group",
            current_date=date(2026, 3, 30),
        )

        assert result.match is False
        assert result.details is None

    def test_user_message_format(self, analyzer: MessageAnalyzer) -> None:
        msg = analyzer._build_user_message(
            raw_text="Test message",
            sender_tg_id=42,
            source_group="TestGroup",
            current_date=date(2026, 3, 30),
        )
        assert "TestGroup" in msg
        assert "42" in msg
        assert "2026-03-30" in msg
        assert "Test message" in msg

    def test_prompt_loaded(self, analyzer: MessageAnalyzer) -> None:
        assert "КРИТЕРІЇ МАТЧУ" in analyzer._system_prompt
        assert "JSON" in analyzer._system_prompt
