"""Enforce 500-line limit on all files in src/."""

from pathlib import Path

import pytest

MAX_LINES = 500
SRC_DIR = Path(__file__).parent.parent / "src"


def _get_python_files() -> list[Path]:
    return list(SRC_DIR.rglob("*.py"))


@pytest.mark.parametrize("filepath", _get_python_files(), ids=lambda p: str(p.relative_to(SRC_DIR)))
def test_file_under_500_lines(filepath: Path) -> None:
    lines = filepath.read_text(encoding="utf-8").splitlines()
    assert len(lines) <= MAX_LINES, (
        f"{filepath.relative_to(SRC_DIR)} has {len(lines)} lines (max {MAX_LINES})"
    )
