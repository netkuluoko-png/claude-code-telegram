# LogistAgent — План імплементації MVP

Покроковий план реалізації на основі `07_MVP_PLAN.md` (Етапи 0-7).
Кожен етап — самодостатній, з тестами та критерієм завершення.

---

## Граф залежностей між модулями

```
config.py ─────────────────────────────────────────────────────────────────┐
exceptions.py ─────────────────────────────────────────────────────────────┤
                                                                           │
models/                                                                    │
├── common.py          (базові enum, типи)                                │
├── cargo.py           (CargoOffer, ParserOutput)                         │
├── contact.py         (Contact, ContactSlice, ContactProfile)            │
├── deal.py            (Deal, DealEvent, DealSummary)                     │
└── ai_outputs.py      (ResponderOutput, MatcherOutput, ProfilerOutput)   │
     ▲                                                                     │
     │                                                                     │
db/                                                                        │
├── schema.sql                                                            │
├── database.py        (ConnectionPool / get_connection)                  │
├── migrations.py                                                         │
└── repositories/                                                         │
    ├── base.py        (BaseRepository)                                   │
    ├── contact_repo   ─────────────────────────────────────────────┐     │
    ├── cargo_repo     ─────────────────────────────────────────────┤     │
    ├── deal_repo      ─────────────────────────────────────────────┤     │
    ├── message_repo   ─────────────────────────────────────────────┤     │
    └── config_repo    ─────────────────────────────────────────────┤     │
         ▲                                                          │     │
         │                                                          │     │
services/                                                           │     │
├── nbu_rates.py       ←──────────────────────── cargo_repo ────────┤     │
├── carrier_channel.py ←──────────────────────── Telethon client ───┤     │
└── claude_client.py   (обгортка Claude API)                        │     │
         ▲                                                          │     │
         │                                                          │     │
parser/                                                             │     │
├── group_monitor.py   ←── Telethon event handler ──────────────────┤     │
└── message_analyzer.py ←── claude_client ──────────────────────────┤     │
         │                                                          │     │
         ▼                                                          │     │
agent/                                                              │     │
├── codex.py           ←── prompts/*.md ────────────────────────────┤     │
├── context.py         ←── repositories (контекстна збірка) ────────┤     │
├── router.py          ←── context.py + responder.py ───────────────┤     │
├── matcher.py         ←── claude_client + context.py ──────────────┤     │
├── responder.py       ←── claude_client + codex.py ────────────────┤     │
└── verification.py    ←── claude_client ───────────────────────────┤     │
         ▲                                                          │     │
         │                                                          │     │
deals/                                                              │     │
├── manager.py         ←── deal_repo + notifier ────────────────────┤     │
├── documents.py       ←── Telethon + deal_repo ────────────────────┤     │
└── templates.py       ←── models/deal.py ──────────────────────────┤     │
         ▲                                                          │     │
         │                                                          │     │
profiler/                                                           │     │
└── profiler.py        ←── claude_client + contact_repo ────────────┤     │
                                                                    │     │
notifications/                                                      │     │
└── notifier.py        ←── Admin Bot (python-telegram-bot) ─────────┤     │
                                                                    │     │
monitoring/                                                         │     │
└── health.py          ←── всі модулі ─────────────────────────────┤     │
                                                                    │     │
bot/                                                                │     │
├── telegram_bot.py    ←── notifier + deals/manager + health ───────┘     │
└── contact_briefing.py ←── claude_client + context.py ───────────────────┘

main.py ←── всі модулі (DI wiring, event loop, graceful shutdown)
```

---

## Порядок створення schema.sql (FK-залежності)

```sql
-- Рівень 0: жодних FK
1. contacts                -- PK: id
2. agent_config            -- PK: key
3. exchange_rates          -- PK: currency
4. unprocessed_messages    -- PK: id (AUTOINCREMENT)

-- Рівень 1: FK → contacts
5. contact_phones          -- FK: contact_id → contacts
6. contact_routes          -- FK: contact_id → contacts
7. contact_source_groups   -- FK: contact_id → contacts
8. contact_psychology      -- FK: contact_id → contacts (PK = contact_id)
9. contact_reliability     -- FK: contact_id → contacts (PK = contact_id)
10. price_records          -- FK: contact_id → contacts
11. cargo_offers           -- FK: sender_contact_id → contacts
12. messages               -- FK: contact_id → contacts (+ deal_id → deals, додається пізніше)

-- Рівень 2: FK → contacts + cargo_offers
13. deals                  -- FK: cargo_offer_id → cargo_offers
                           -- FK: customer_contact_id → contacts
                           -- FK: carrier_contact_id → contacts
14. market_prices          -- (без FK, UNIQUE constraint)

-- Рівень 3: FK → deals
15. deal_events            -- FK: deal_id → deals
16. deal_documents         -- FK: deal_id → deals, uploaded_by → contacts, forwarded_to → contacts
17. driver_contacts        -- FK: deal_id → deals, carrier_contact_id → contacts

-- Рівень 4: FK → messages (оновлення)
18. messages.deal_id       -- FK: deal_id → deals (ALTER TABLE додати FK після створення deals)

-- Архівні таблиці (без FK, копія структури)
19. deals_archive
20. messages_archive

-- Індекси (після всіх таблиць)
```

---

## Порядок створення models/

### Shared / базові типи — `src/models/common.py`

```python
# Enums та literals
ContactType = Literal["customer", "carrier", "both", "unknown"]
DealStatus = Literal["prospecting", "negotiating", "agreed", "in_transit", "completed", "cancelled", "disputed"]
CargoOfferStatus = Literal["open", "matched", "expired", "archived"]
CargoType = Literal["cargo", "transport"]
ContainerType = Literal["20", "40", "40HC", "45", "reefer"]
TrustLevel = Literal["new", "developing", "established", "trusted"]
CommunicationStyle = Literal["formal", "informal", "blunt", "mixed"]
Language = Literal["uk", "ru", "mixed"]
ResponseSpeed = Literal["fast", "normal", "slow"]
BargainingBehavior = Literal["flexible", "firm", "aggressive"]
PriceTendency = Literal["below_market", "at_market", "above_market"]
PaymentType = Literal["cash", "bank"]
MessageDirection = Literal["in", "out"]
DocType = Literal["application", "cmr", "ttn", "invoice", "other"]
VerificationVerdict = Literal["verified_driver", "suspicious", "unverified"]
```

### Input-моделі для AI-промптів

```
src/models/cargo.py:
  - CargoDetails           (route_from, route_to, container_type, weight, price, ...)
  - ParserInput            (raw_text, sender_tg_id, source_group, current_date)
  - CargoOffer             (повна Pydantic-модель для БД-запису cargo_offers)

src/models/contact.py:
  - Contact                (id, tg_id, tg_username, first_name, type, ...)
  - ContactPsychology      (communication_style, language, response_speed, ...)
  - ContactReliability     (deals_total, deals_completed, overall_reliability, ...)
  - ContactSlice           (name, type, reliability, style, language, best_pattern, ...)
  - ContactProfile         (повний профіль = Contact + Psychology + Reliability + Routes)
  - PriceRecord            (contact_id, route_from, route_to, price, currency, ...)

src/models/deal.py:
  - Deal                   (id, cargo_offer_id, customer_contact_id, carrier_contact_id, ...)
  - DealEvent              (id, deal_id, event_type, old_value, new_value, note)
  - DealSummary            (deal_id, route, status, date, my_price, container_type)
  - DealDocument           (id, deal_id, doc_type, file_path, uploaded_by, forwarded_to)
  - DriverContact          (id, deal_id, carrier_contact_id, driver_name, driver_phone, ...)
```

### Output-моделі AI-промптів — `src/models/ai_outputs.py`

```
ResponderOutput:
  - context_type: Literal["deal_response", "new_offer", "price_inquiry", ...]
  - deal_id: str | None
  - response_text: str
  - actions: list[ResponderAction]
  - confidence: float
  - internal_note: str

ResponderAction (discriminated union по type):
  - CreateContactAction(role: ContactType)
  - CreateDealAction(cargo_offer_id: str, contact_role: str)
  - UpdateDealStatusAction(deal_id: str, new_status: DealStatus)
  - UpdatePriceAction(contact_id: str, price: float, currency: str, route: str)
  - EscalateAction(reason: str)
  - NotifyOperatorAction(text: str)
  - ForwardToOtherPartyAction(deal_id: str, message: str)
  - SendToCarrierChannelAction(message_draft: str)
  - UpdateProfileAction()
  - AskClarificationAction()
  - NoneAction()

ParserOutput:
  - match: bool
  - type: CargoType | None
  - reason: str
  - details: CargoDetails | None

MatcherOutput:
  - action: Literal["active", "passive", "skip"]
  - reason: str
  - estimated_margin: float | None
  - candidates: list[MatcherCandidate]

MatcherCandidate:
  - contact_id: str
  - name: str
  - reliability: int
  - priority: int
  - message_draft: str

ProfilerOutput:
  - psychology_updates: PsychologyUpdates
  - price_updates: list[PriceUpdate]
  - reliability_updates: ReliabilityUpdates
  - notes: str

VerificationOutput:
  - verdict: VerificationVerdict
  - confidence: float
  - reason: str
  - evidence: VerificationEvidence
  - recommended_action: Literal["grant_limited_access", "escalate_to_operator", "deny_and_suggest_main_account"]

ContactBriefingOutput:
  - briefing_text: str
  - likely_intent: str
  - urgency: Literal["low", "medium", "high"]
  - suggested_talking_points: list[str]
```

---

## Конфігурація та .env

### Файл `.env` (всі потрібні змінні)

```
# Telegram Userbot (Telethon)
TG_API_ID=<Telegram app API ID>
TG_API_HASH=<Telegram app API hash>
TG_SESSION_NAME=logist_agent
TG_PHONE=<номер телефону userbot>

# Telegram Admin Bot (python-telegram-bot)
ADMIN_BOT_TOKEN=<BotFather token>
ADMIN_TG_ID=<Telegram user ID оператора — whitelist>

# Claude API
ANTHROPIC_API_KEY=<ключ Claude API>
CLAUDE_MODEL=claude-sonnet-4-20250514

# Database
DB_PATH=data/logist.db
DB_TEST_PATH=data/logist_test.db

# Telegram entities
MONITORED_GROUPS=Turbo-ИМПОРТ,Tlg Ukraine Logistics Partner
CARRIER_CHANNEL_ID=<ID каналу перевізників>

# Logging
LOG_LEVEL=INFO
LOG_DIR=logs

# Backup
BACKUP_DIR=backups
BACKUP_INTERVAL_HOURS=6
BACKUP_RETAIN_COUNT=14
```

### Ключі `agent_config` (таблиця в БД)

| Ключ | Default | Опис |
|------|---------|------|
| `margin_threshold_usd` | `100` | Мінімальний поріг маржі $ |
| `max_carriers_to_contact` | `3` | Макс. перевізників в першому раунді |
| `response_wait_hours` | `2` | Таймаут очікування відповіді |
| `cargo_ttl_hours` | `72` | TTL вантажу (годин) |
| `escalation_amount_eur` | `5000` | Поріг ескалації по сумі |
| `active_mode_enabled` | `1` | Активний режим увімкнений |
| `min_reliability_for_active` | `50` | Мін. reliability для активного пошуку |
| `carrier_channel_id` | `` | ID каналу перевізників |
| `nbu_rate_update_interval` | `daily` | Частота оновлення курсу |
| `first_contact_approval` | `1` | Підтвердження оператора для першого контакту |

---

## Етап 0: Підготовка

**Мета:** Ініціалізація проекту, БД, моделі, міграція існуючих даних.

### Файли для створення (в порядку імплементації)

#### 0.1 `pyproject.toml`

**Залежності:** немає (перший файл)

```toml
[project]
name = "logist-agent"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = [
    "telethon>=1.36",
    "python-telegram-bot>=21.0",
    "aiosqlite>=0.20",
    "anthropic>=0.40",
    "pydantic>=2.9",
    "httpx>=0.27",
    "python-dotenv>=1.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.24",
    "mypy>=1.13",
    "ruff>=0.8",
]
```

#### 0.2 `src/__init__.py`

Порожній файл.

#### 0.3 `src/config.py`

**Залежності:** `.env`, pydantic
**Таблиці БД:** `agent_config` (читання)

Ключові елементи:
```python
class Settings(BaseModel):
    """Конфігурація з .env."""
    tg_api_id: int
    tg_api_hash: str
    tg_session_name: str = "logist_agent"
    tg_phone: str
    admin_bot_token: str
    admin_tg_id: int
    anthropic_api_key: str
    claude_model: str = "claude-sonnet-4-20250514"
    db_path: Path = Path("data/logist.db")
    monitored_groups: list[str]
    carrier_channel_id: int | None = None
    log_level: str = "INFO"
    log_dir: Path = Path("logs")
    backup_dir: Path = Path("backups")
    backup_interval_hours: int = 6
    backup_retain_count: int = 14

    @classmethod
    def from_env(cls) -> "Settings": ...

class AgentConfig:
    """Кеш agent_config з БД. Перезавантажується раз на хвилину."""
    margin_threshold_usd: int
    max_carriers_to_contact: int
    response_wait_hours: int
    cargo_ttl_hours: int
    escalation_amount_eur: int
    active_mode_enabled: bool
    min_reliability_for_active: int
    carrier_channel_id: str
    first_contact_approval: bool

    async def load(self, db: aiosqlite.Connection) -> None: ...
    async def get(self, key: str) -> str: ...

CITY_NORMALIZATION: dict[str, str]  # Словник нормалізації міст
```

#### 0.4 `src/exceptions.py`

**Залежності:** немає

```python
class LogistAgentError(Exception): ...
class DatabaseError(LogistAgentError): ...
class ClaudeAPIError(LogistAgentError): ...
class TelegramError(LogistAgentError): ...
class EscalationRequired(LogistAgentError):
    def __init__(self, reason: str, deal_id: str | None = None): ...
class LowConfidenceError(LogistAgentError):
    def __init__(self, confidence: float, context: str): ...
class ContactNotFoundError(LogistAgentError): ...
class DealNotFoundError(LogistAgentError): ...
class InvalidDealTransitionError(LogistAgentError):
    def __init__(self, deal_id: str, current: str, target: str): ...
```

#### 0.5 `src/models/__init__.py`

Re-export основних моделей.

#### 0.6 `src/models/common.py`

**Залежності:** pydantic
**Описано вище:** всі Literal-типи, enum-подібні значення.

#### 0.7 `src/models/cargo.py`

**Залежності:** `common.py`
**Таблиці БД:** `cargo_offers`
**Промпти:** Parser input/output

```python
class CargoDetails(BaseModel):
    route_from: str
    route_to: str | None = None
    container_type: ContainerType | None = None
    shipping_line: str | None = None
    weight_tons: float | None = None
    cargo_description: str | None = None
    departure_date: date | None = None
    price: float | None = None
    price_currency: Literal["EUR", "USD", "UAH"] | None = None
    payment_type: PaymentType | None = None
    contact_name: str | None = None
    contact_phone: str | None = None

class CargoOffer(BaseModel):
    id: str
    source_msg_id: int | None = None
    source_group: str | None = None
    sender_contact_id: str | None = None
    type: CargoType
    direction_from: str
    direction_to: str | None = None
    container_type: ContainerType | None = None
    weight_tons: float | None = None
    cargo_description: str | None = None
    departure_date: date | None = None
    price: float | None = None
    price_currency: str | None = None
    payment_type: PaymentType | None = None
    contact_name_raw: str | None = None
    contact_phone_raw: str | None = None
    raw_text: str
    ai_analysis: str | None = None
    status: CargoOfferStatus = "open"
    created_at: datetime
    expires_at: datetime | None = None
```

#### 0.8 `src/models/contact.py`

**Залежності:** `common.py`
**Таблиці БД:** `contacts`, `contact_psychology`, `contact_reliability`, `contact_phones`, `contact_routes`, `contact_source_groups`, `price_records`
**Промпти:** Responder (ContactSlice), Profiler, Contact Briefing

```python
class Contact(BaseModel):
    id: str
    tg_id: int
    tg_username: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    type: ContactType = "unknown"
    poland_related: bool = False
    first_seen: datetime
    last_seen: datetime
    total_messages: int = 0

class ContactPsychology(BaseModel):
    contact_id: str
    communication_style: CommunicationStyle | None = None
    language: Language | None = None
    response_speed: ResponseSpeed | None = None
    bargaining_behavior: BargainingBehavior | None = None
    preferred_contact_time: str | None = None
    typical_message_length: Literal["short", "medium", "long"] | None = None
    emoji_usage: Literal["none", "rare", "frequent"] | None = None
    best_response_pattern: str | None = None
    trust_level: TrustLevel = "new"

class ContactReliability(BaseModel):
    contact_id: str
    deals_total: int = 0
    deals_completed: int = 0
    deals_cancelled: int = 0
    cancellation_rate: float = 0.0
    payment_punctuality: Literal["on_time", "slight_delay", "problematic", "unknown"] = "unknown"
    avg_payment_delay_days: float = 0.0
    communication_culture: int = 3
    disputes_count: int = 0
    overall_reliability: int = 50
    manual_notes: str | None = None

class ContactSlice(BaseModel):
    """Зріз для AI-промптів (Зона 3)."""
    name: str
    type: ContactType
    reliability: int
    style: CommunicationStyle | None = None
    language: Language | None = None
    best_pattern: str | None = None
    price_tendency: PriceTendency | None = None
    active_routes: list[str]
    trust_level: TrustLevel = "new"
    bargaining: BargainingBehavior | None = None

class PriceRecord(BaseModel):
    id: str
    contact_id: str
    route_from: str
    route_to: str
    container_type: ContainerType | None = None
    price: float
    currency: str = "EUR"
    date: str
    source: str = "message"
    source_msg_id: int | None = None
```

#### 0.9 `src/models/deal.py`

**Залежності:** `common.py`
**Таблиці БД:** `deals`, `deal_events`, `deal_documents`, `driver_contacts`
**Промпти:** Responder (active_deals), Matcher, Verification

```python
class Deal(BaseModel):
    id: str
    cargo_offer_id: str | None = None
    customer_contact_id: str | None = None
    carrier_contact_id: str | None = None
    route_from: str
    route_to: str
    container_type: ContainerType | None = None
    departure_date: date | None = None
    customer_price: float | None = None
    customer_currency: str = "EUR"
    carrier_price: float | None = None
    carrier_currency: str = "EUR"
    margin: float | None = None
    status: DealStatus = "prospecting"
    escalated: bool = False
    escalation_reason: str | None = None
    notes: str | None = None
    created_at: datetime
    updated_at: datetime

class DealEvent(BaseModel):
    id: str
    deal_id: str
    event_type: Literal["status_change", "note", "escalation", "document", "verification"]
    old_value: str | None = None
    new_value: str | None = None
    note: str | None = None
    created_at: datetime

class DealSummary(BaseModel):
    deal_id: str
    route: str
    status: DealStatus
    date: date | None = None
    my_price: float | None = None
    container_type: ContainerType | None = None

class DealDocument(BaseModel):
    id: str
    deal_id: str
    doc_type: DocType | None = None
    file_path: str | None = None
    file_name: str | None = None
    uploaded_by: str | None = None
    forwarded_to: str | None = None
    created_at: datetime

class DriverContact(BaseModel):
    id: str
    deal_id: str | None = None
    carrier_contact_id: str | None = None
    driver_name: str
    driver_phone: str | None = None
    driver_tg_id: int | None = None
    driver_tg_username: str | None = None
    verified: bool = False
    created_at: datetime
```

#### 0.10 `src/models/ai_outputs.py`

**Залежності:** `common.py`, `cargo.py`, `contact.py`
**Промпти:** всі 6 промптів (output-моделі)
**Описано вище** — повний набір ResponderOutput, ParserOutput, MatcherOutput, ProfilerOutput, VerificationOutput, ContactBriefingOutput.

#### 0.11 `src/db/__init__.py`

Порожній.

#### 0.12 `src/db/database.py`

**Залежності:** `config.py`, aiosqlite

```python
async def get_connection(db_path: str | Path) -> aiosqlite.Connection:
    """Створити з'єднання з БД і ввімкнути WAL + foreign keys."""

async def init_db(db_path: str | Path) -> None:
    """Створити всі таблиці з schema.sql якщо не існують."""

async def close_db(conn: aiosqlite.Connection) -> None:
    """Закрити з'єднання."""
```

#### 0.13 `src/db/schema.sql`

**Залежності:** немає
**Таблиці:** всі 18 + 2 архівних + індекси (порядок з секції "Порядок створення schema.sql" вище)
**Джерело:** `05_DATABASE.md` — повна копія DDL

#### 0.14 `src/db/repositories/__init__.py`

Порожній.

#### 0.15 `src/db/repositories/base.py`

**Залежності:** aiosqlite

```python
class BaseRepository:
    def __init__(self, db: aiosqlite.Connection) -> None:
        self._db = db

    async def _execute(self, query: str, params: tuple = ()) -> aiosqlite.Cursor: ...
    async def _fetch_one(self, query: str, params: tuple = ()) -> dict | None: ...
    async def _fetch_all(self, query: str, params: tuple = ()) -> list[dict]: ...
    async def _insert(self, table: str, data: dict) -> str: ...
    async def _update(self, table: str, data: dict, where: str, params: tuple) -> int: ...
```

#### 0.16 `src/db/repositories/contact_repo.py`

**Залежності:** `base.py`, `src/models/contact.py`
**Таблиці:** `contacts`, `contact_phones`, `contact_routes`, `contact_source_groups`, `contact_psychology`, `contact_reliability`, `price_records`
**Workflows:** WF-1 (оновлення контакту), WF-4 (зріз для AI), WF-4.9 (Profiler updates), WF-12 (Contact Briefing)

```python
class ContactRepository(BaseRepository):
    async def get_by_tg_id(self, tg_id: int) -> Contact | None: ...
    async def get_by_id(self, contact_id: str) -> Contact | None: ...
    async def create(self, tg_id: int, first_name: str | None, ...) -> Contact: ...
    async def update_last_seen(self, contact_id: str) -> None: ...
    async def increment_messages(self, contact_id: str) -> None: ...
    async def update_type(self, contact_id: str, contact_type: ContactType) -> None: ...
    async def search_by_phone(self, phone: str) -> Contact | None: ...
    async def search_by_username(self, username: str) -> Contact | None: ...

    # Phones
    async def add_phone(self, contact_id: str, phone: str, source: str) -> None: ...
    async def get_phones(self, contact_id: str) -> list[str]: ...

    # Routes
    async def add_or_update_route(self, contact_id: str, from_city: str, to_city: str) -> None: ...
    async def get_routes(self, contact_id: str) -> list[tuple[str, str]]: ...
    async def get_carriers_for_route(self, from_city: str, min_reliability: int) -> list[dict]: ...

    # Source groups
    async def add_source_group(self, contact_id: str, group_name: str, group_tg_id: int | None) -> None: ...
    async def is_from_monitored_group(self, contact_id: str, monitored_groups: list[str]) -> bool: ...

    # Psychology
    async def get_psychology(self, contact_id: str) -> ContactPsychology | None: ...
    async def update_psychology(self, contact_id: str, updates: dict) -> None: ...

    # Reliability
    async def get_reliability(self, contact_id: str) -> ContactReliability | None: ...
    async def update_reliability(self, contact_id: str, updates: dict) -> None: ...
    async def recalculate_reliability(self, contact_id: str) -> int: ...

    # Price records
    async def add_price_record(self, record: PriceRecord) -> None: ...
    async def get_price_records(self, contact_id: str, route_from: str | None = None, route_to: str | None = None) -> list[PriceRecord]: ...
    async def get_price_tendency(self, contact_id: str, route_from: str, route_to: str) -> PriceTendency: ...

    # Context slice (для AI)
    async def get_contact_slice(self, contact_id: str) -> ContactSlice: ...
    async def get_full_profile(self, contact_id: str) -> ContactProfile: ...
```

#### 0.17 `src/db/repositories/cargo_repo.py`

**Залежності:** `base.py`, `src/models/cargo.py`
**Таблиці:** `cargo_offers`, `market_prices`, `exchange_rates`
**Workflows:** WF-1 (створення cargo_offer), WF-2 (матчинг), WF-8 (автоочищення)

```python
class CargoRepository(BaseRepository):
    async def create_offer(self, offer: CargoOffer) -> str: ...
    async def get_by_id(self, cargo_id: str) -> CargoOffer | None: ...
    async def get_open_offers(self, type: CargoType | None = None, route_from: str | None = None) -> list[CargoOffer]: ...
    async def update_status(self, cargo_id: str, new_status: CargoOfferStatus) -> None: ...
    async def expire_old_offers(self, ttl_hours: int) -> int: ...
    async def expire_past_departure(self) -> int: ...
    async def delete_expired_older_than(self, days: int) -> int: ...

    # Market prices
    async def get_market_avg_price(self, route_from: str, route_to: str, container_type: str | None = None) -> float | None: ...
    async def recalculate_market_prices(self) -> None: ...

    # Exchange rates
    async def get_exchange_rate(self, currency: str) -> float | None: ...
    async def update_exchange_rate(self, currency: str, rate_uah: float, rate_date: str) -> None: ...
```

#### 0.18 `src/db/repositories/deal_repo.py`

**Залежності:** `base.py`, `src/models/deal.py`
**Таблиці:** `deals`, `deal_events`, `deal_documents`, `driver_contacts`
**Workflows:** WF-2, WF-3, WF-3.5, WF-4, WF-6, WF-7, WF-11

```python
class DealRepository(BaseRepository):
    async def create(self, deal: Deal) -> str: ...
    async def get_by_id(self, deal_id: str) -> Deal | None: ...
    async def get_active_deals_for_contact(self, contact_id: str) -> list[Deal]: ...
    async def get_deals_by_status(self, status: DealStatus) -> list[Deal]: ...
    async def update_status(self, deal_id: str, new_status: DealStatus, note: str | None = None) -> None: ...
    async def update_prices(self, deal_id: str, customer_price: float | None, carrier_price: float | None) -> None: ...
    async def set_carrier(self, deal_id: str, carrier_contact_id: str) -> None: ...
    async def set_escalated(self, deal_id: str, reason: str) -> None: ...
    async def clear_escalation(self, deal_id: str) -> None: ...
    async def has_active_deal_with_carrier(self, carrier_contact_id: str) -> bool: ...

    # Deal events
    async def add_event(self, event: DealEvent) -> None: ...
    async def get_events(self, deal_id: str, limit: int = 10) -> list[DealEvent]: ...
    async def get_recent_events_for_deals(self, deal_ids: list[str], limit: int = 10) -> list[DealEvent]: ...

    # Documents
    async def add_document(self, doc: DealDocument) -> None: ...
    async def get_documents(self, deal_id: str) -> list[DealDocument]: ...
    async def mark_forwarded(self, doc_id: str, forwarded_to: str) -> None: ...

    # Driver contacts
    async def add_driver(self, driver: DriverContact) -> None: ...
    async def get_driver_by_phone(self, phone: str) -> DriverContact | None: ...
    async def get_driver_by_tg_id(self, tg_id: int) -> DriverContact | None: ...
    async def verify_driver(self, driver_id: str) -> None: ...

    # Archive
    async def archive_old_deals(self, days: int) -> int: ...

    # Summary для AI
    async def get_deal_summaries_for_contact(self, contact_id: str) -> list[DealSummary]: ...
```

#### 0.19 `src/db/repositories/message_repo.py`

**Залежності:** `base.py`
**Таблиці:** `messages`, `unprocessed_messages`
**Workflows:** WF-1, WF-4, WF-10

```python
class MessageRepository(BaseRepository):
    async def save_message(self, tg_msg_id: int | None, contact_id: str | None, source: str, direction: MessageDirection, text: str, ai_analysis: str | None = None, deal_id: str | None = None) -> str: ...
    async def get_recent_messages(self, contact_id: str, limit: int = 20) -> list[dict]: ...
    async def get_unprocessed_for_profiler(self, contact_id: str) -> list[dict]: ...
    async def mark_profiler_processed(self, message_ids: list[str]) -> None: ...

    # Unprocessed queue
    async def add_unprocessed(self, tg_msg_id: int | None, tg_user_id: int | None, chat_id: int | None, text: str | None, raw_data: str | None, reason: str) -> None: ...
    async def get_unprocessed(self) -> list[dict]: ...
    async def mark_processed(self, msg_id: int) -> None: ...
    async def get_unprocessed_count(self) -> int: ...

    # Archive
    async def archive_old_messages(self, days: int) -> int: ...
```

#### 0.20 `src/db/repositories/config_repo.py`

**Залежності:** `base.py`
**Таблиці:** `agent_config`

```python
class ConfigRepository(BaseRepository):
    async def get_all(self) -> dict[str, str]: ...
    async def get(self, key: str) -> str | None: ...
    async def set(self, key: str, value: str) -> None: ...
```

#### 0.21 `src/db/migrations.py`

**Залежності:** `database.py`, aiosqlite, `config.py` (CITY_NORMALIZATION)
**Таблиці:** читає logist_export → пише в нову схему

```python
async def migrate_from_export(export_path: Path, db_path: Path) -> None:
    """Міграція з logist_export.xlsx → нова схема."""
    # 1. Нормалізувати міста
    # 2. Розпарсити телефони
    # 3. Витягти маршрути
    # 4. Перенести AI-аналіз
    # 5. Створити cargo_offers з matched повідомлень
```

### Тести для Етапу 0

```
tests/conftest.py              — фікстури: test DB, async event loop
tests/test_repositories/
  test_contact_repo.py         — CRUD контактів, phones, routes, psychology, reliability
  test_cargo_repo.py           — CRUD cargo_offers, market_prices, exchange_rates
  test_deal_repo.py            — CRUD deals, events, documents, drivers
  test_message_repo.py         — CRUD messages, unprocessed queue
  test_config_repo.py          — get/set agent_config
tests/test_models/
  test_models.py               — валідація Pydantic-моделей, серіалізація/десеріалізація
tests/test_file_size.py        — enforce 500-line limit на всі файли в src/
```

### Критерій завершення Етапу 0

- [ ] `uv run pytest tests/test_repositories/ -x` — all pass
- [ ] `uv run pytest tests/test_models/ -x` — all pass
- [ ] `uv run mypy --strict src/models/ src/db/ src/config.py src/exceptions.py` — no errors
- [ ] БД створюється з нуля через `init_db()`
- [ ] Міграція з logist_export проходить без помилок
- [ ] Всі 18 таблиць + 2 архівні + індекси створені
- [ ] `agent_config` містить всі 10 ключів з початковими значеннями

---

## Етап 1: Розширений парсер

**Мета:** Парсер моніторить групи, аналізує повідомлення через Claude API, записує cargo_offers та оновлює контакти.
**Залежності від Етапу 0:** models/, db/repositories/, config.py, exceptions.py

### Файли для створення

#### 1.1 `src/services/__init__.py`

Порожній.

#### 1.2 `src/services/claude_client.py`

**Залежності:** `config.py`, anthropic (SDK)
**Промпти:** всі 6 (обгортка для виклику)

```python
class ClaudeClient:
    """Async обгортка Claude API з retry та structured output."""

    def __init__(self, api_key: str, model: str) -> None: ...

    async def call(
        self,
        system_prompt: str,
        user_message: str,
        temperature: float = 0.0,
        max_tokens: int = 1024,
        timeout: float = 30.0,
    ) -> str:
        """Виклик Claude API. Retry при 429/500/503 з exponential backoff."""

    async def call_json(
        self,
        system_prompt: str,
        user_message: str,
        response_model: type[BaseModel],
        temperature: float = 0.0,
        max_tokens: int = 1024,
        timeout: float = 30.0,
    ) -> BaseModel:
        """Виклик з парсингом JSON у Pydantic-модель."""

    async def close(self) -> None: ...
```

#### 1.3 `src/services/nbu_rates.py`

**Залежності:** httpx, `cargo_repo.py`
**Таблиці:** `exchange_rates`
**Workflows:** WF-8 (щоденне оновлення)

```python
class NBURatesService:
    """Парсер курсу НБУ (api.bank.gov.ua)."""

    NBU_API_URL = "https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?json"

    def __init__(self, cargo_repo: CargoRepository) -> None: ...

    async def fetch_and_update(self) -> dict[str, float]:
        """Завантажити курси EUR, USD з НБУ та зберегти в exchange_rates."""

    async def convert_to_usd(self, amount: float, currency: str) -> float:
        """Конвертувати суму в USD через курс НБУ."""

    async def convert(self, amount: float, from_currency: str, to_currency: str) -> float: ...
```

#### 1.4 `src/parser/__init__.py`

Порожній.

#### 1.5 `prompts/parser_prompt.md`

**Промпт:** Parser (побічний), Temperature: 0
**Джерело:** `08_AI_PROMPTS.md`, секція 2 — дослівний system prompt

#### 1.6 `src/parser/message_analyzer.py`

**Залежності:** `claude_client.py`, `models/ai_outputs.py` (ParserOutput), `models/cargo.py` (CargoDetails)
**Промпти:** Parser
**Workflows:** WF-1, крок 3

```python
class MessageAnalyzer:
    """Аналіз повідомлень через Claude API."""

    def __init__(self, claude_client: ClaudeClient) -> None: ...

    async def analyze(self, raw_text: str, sender_tg_id: int, source_group: str, current_date: date) -> ParserOutput:
        """Аналізувати повідомлення з групи. Повертає ParserOutput."""

    def _build_user_message(self, raw_text: str, sender_tg_id: int, source_group: str, current_date: date) -> str:
        """Формує user message для Parser prompt."""

    def _load_prompt(self) -> str:
        """Завантажити system prompt з prompts/parser_prompt.md."""
```

#### 1.7 `src/parser/group_monitor.py`

**Залежності:** Telethon, `message_analyzer.py`, `contact_repo.py`, `cargo_repo.py`, `message_repo.py`, `config.py`
**Таблиці:** `contacts`, `contact_phones`, `contact_routes`, `contact_source_groups`, `cargo_offers`, `messages`, `price_records`, `unprocessed_messages`
**Workflows:** WF-1 (повний flow)

```python
class GroupMonitor:
    """Telethon event handler для моніторингу Telegram-груп."""

    def __init__(
        self,
        client: TelegramClient,
        analyzer: MessageAnalyzer,
        contact_repo: ContactRepository,
        cargo_repo: CargoRepository,
        message_repo: MessageRepository,
        config: Settings,
        on_new_cargo: Callable[[CargoOffer], Awaitable[None]],
    ) -> None: ...

    async def start(self) -> None:
        """Зареєструвати event handler для моніторених груп."""

    async def _handle_new_message(self, event: events.NewMessage.Event) -> None:
        """WF-1: повний flow обробки повідомлення з групи."""
        # 1. Визначити/створити контакт
        # 2. Оновити last_seen, total_messages
        # 3. AI-аналіз через MessageAnalyzer
        # 4. Зберегти message
        # 5. Якщо match=true:
        #    a. Створити cargo_offer
        #    b. Оновити contact_routes, contact_phones, price_records
        #    c. Тригерити on_new_cargo callback → WF-2

    def _normalize_city(self, city: str) -> str:
        """Нормалізація назви міста через CITY_NORMALIZATION."""
```

### Тести для Етапу 1

```
tests/test_services/
  test_claude_client.py     — mock Claude API, retry, JSON parsing
  test_nbu_rates.py         — mock httpx, курси EUR/USD
tests/test_parser/
  test_message_analyzer.py  — різні повідомлення: match/no match, cargo/transport
  test_group_monitor.py     — mock Telethon events, повний flow WF-1
```

### Критерій завершення Етапу 1

- [ ] Парсер коректно аналізує 50+ реальних повідомлень (cargo + transport + no_match)
- [ ] cargo_offers створюються зі статусом `open` і коректними полями
- [ ] contact_routes, contact_phones, price_records оновлюються автоматично
- [ ] Нормалізація міст працює (Гданск → Гданськ)
- [ ] Курс НБУ завантажується та зберігається в exchange_rates
- [ ] Помилки API записуються в unprocessed_messages
- [ ] `uv run mypy --strict src/parser/ src/services/` — no errors

---

## Етап 2: Telegram-бот + Router

**Мета:** Адмін-бот для оператора. Router визначає контекст DM. Responder генерує відповіді. Contact Briefing для /who.
**Залежності від Етапів 0-1:** models/, db/, parser/, services/claude_client.py

### Файли для створення

#### 2.1 `prompts/agent_codex.md`

**Промпт:** Responder (головний), Temperature: 0.3
**Джерело:** `08_AI_PROMPTS.md`, секція 1 — дослівний system prompt

#### 2.2 `prompts/contact_briefing_prompt.md`

**Промпт:** Contact Briefing (побічний), Temperature: 0.3
**Джерело:** `08_AI_PROMPTS.md`, секція 6

#### 2.3 `src/agent/__init__.py`

Порожній.

#### 2.4 `src/agent/codex.py`

**Залежності:** pathlib
**Промпти:** всі (завантаження з файлів)

```python
class PromptLoader:
    """Завантаження system prompts з файлів."""

    PROMPTS_DIR = Path("prompts")

    def load(self, prompt_name: str) -> str:
        """Завантажити prompt з prompts/{prompt_name}.md."""

    def load_responder(self) -> str: ...
    def load_parser(self) -> str: ...
    def load_matcher(self) -> str: ...
    def load_profiler(self) -> str: ...
    def load_verification(self) -> str: ...
    def load_contact_briefing(self) -> str: ...
```

#### 2.5 `src/agent/context.py`

**Залежності:** всі repositories, `models/contact.py`, `models/deal.py`
**Таблиці:** всі 4 зони
**Workflows:** WF-4 (крок 2), WF-12 (крок 3)

```python
class ContextAssembler:
    """Збирає контекст з потрібних зон для AI-промптів."""

    def __init__(
        self,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        cargo_repo: CargoRepository,
        message_repo: MessageRepository,
    ) -> None: ...

    async def for_responder(self, contact_id: str, new_message: str) -> dict:
        """Контекст для Responder: зрізи зон 2, 3 + recent_messages."""
        # asyncio.gather: contact_slice + active_deals + recent_messages

    async def for_matcher(self, cargo_offer: CargoOffer) -> dict:
        """Контекст для Matcher: cargo + market_prices + candidates."""

    async def for_profiler(self, contact_id: str, deal_result: dict | None = None) -> dict:
        """Контекст для Profiler: current_profile + unprocessed_messages."""

    async def for_verification(self, claimer_tg_id: int, claimed_contact_id: str | None) -> dict:
        """Контекст для Verification Agent."""

    async def for_contact_briefing(self, contact_id: str) -> dict:
        """Контекст для Contact Briefing: повний профіль + угоди + повідомлення + open cargos."""
```

#### 2.6 `src/agent/responder.py`

**Залежності:** `claude_client.py`, `codex.py`, `models/ai_outputs.py` (ResponderOutput)
**Промпти:** Responder (головний)
**Workflows:** WF-4, крок 3

```python
class Responder:
    """Генерація AI-відповідей на вхідні повідомлення."""

    def __init__(self, claude_client: ClaudeClient, prompt_loader: PromptLoader) -> None: ...

    async def generate_response(self, context: dict) -> ResponderOutput:
        """Викликає Claude API з контекстом, повертає ResponderOutput."""

    def _format_context_as_user_message(self, context: dict) -> str:
        """Серіалізує контекст у текст для user message."""
```

#### 2.7 `src/agent/router.py`

**Залежності:** `context.py`, `responder.py`, всі repositories, Telethon client, `config.py`
**Таблиці:** `contacts`, `messages`, `deals` (через repositories)
**Workflows:** WF-4 (повний flow)

```python
class Router:
    """Маршрутизація вхідних DM від контактів."""

    def __init__(
        self,
        client: TelegramClient,
        context_assembler: ContextAssembler,
        responder: Responder,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        message_repo: MessageRepository,
        cargo_repo: CargoRepository,
        notifier: "Notifier",
        config: Settings,
        agent_config: AgentConfig,
    ) -> None: ...

    async def start(self) -> None:
        """Зареєструвати DM event handler через Telethon."""

    async def _handle_dm(self, event: events.NewMessage.Event) -> None:
        """WF-4: повна обробка вхідного DM."""
        # 1. Визначити контакт по tg_id
        # 2. Перевірити: контакт в базі / з логістичної групи? Ні → ігнорувати
        # 3. Зібрати контекст через ContextAssembler
        # 4. Викликати Responder
        # 5. Перевірити confidence (< 0.7 → ескалація)
        # 6. Виконати actions
        # 7. Відправити response_text через userbot DM
        # 8. Зберегти messages (in + out)
        # 9. Якщо action=update_profile → trigger Profiler (окремий task)

    async def _execute_actions(self, actions: list, contact_id: str, deal_id: str | None) -> None:
        """Виконання дій з ResponderOutput.actions."""

    async def _is_logistics_contact(self, tg_id: int) -> bool:
        """Перевірка: контакт з бази або з логістичної групи."""
```

#### 2.8 `src/notifications/__init__.py`

Порожній.

#### 2.9 `src/notifications/notifier.py`

**Залежності:** python-telegram-bot, `config.py`
**Workflows:** WF-5

```python
class Notifier:
    """Відправка нотифікацій оператору через адмін-бот."""

    def __init__(self, bot_token: str, admin_tg_id: int) -> None: ...

    async def start(self) -> None:
        """Ініціалізація бота."""

    async def send(self, text: str, priority: Literal["low", "medium", "high", "critical"] = "medium") -> None:
        """Відправити повідомлення оператору."""

    async def send_escalation(self, contact_name: str, deal_id: str | None, reason: str, context: str, recommendation: str | None = None) -> None:
        """Форматована ескалація (WF-6)."""

    async def send_new_match(self, route: str, customer_name: str, estimated_margin: float) -> None:
        """Нотифікація про новий матч."""

    async def send_deal_confirmed(self, deal_id: str, route: str, customer_price: float, carrier_price: float, margin: float) -> None:
        """Підтвердження угоди."""

    async def close(self) -> None: ...
```

#### 2.10 `src/bot/__init__.py`

Порожній.

#### 2.11 `src/bot/contact_briefing.py`

**Залежності:** `claude_client.py`, `codex.py`, `context.py`, `models/ai_outputs.py` (ContactBriefingOutput)
**Промпти:** Contact Briefing
**Workflows:** WF-12, крок 4

```python
class ContactBriefingService:
    """AI-брифінг контакту для оператора."""

    def __init__(
        self,
        claude_client: ClaudeClient,
        prompt_loader: PromptLoader,
        context_assembler: ContextAssembler,
    ) -> None: ...

    async def generate_briefing(self, contact_id: str) -> ContactBriefingOutput:
        """Зібрати контекст та згенерувати брифінг."""
```

#### 2.12 `src/bot/telegram_bot.py`

**Залежності:** python-telegram-bot, `contact_briefing.py`, `contact_repo.py`, `deal_repo.py`, `message_repo.py`, `config.py`
**Workflows:** WF-5 (нотифікації), WF-6 (/resolve), WF-12 (/who)

```python
class AdminBot:
    """Приватний Telegram-бот оператора (whitelist)."""

    def __init__(
        self,
        bot_token: str,
        admin_tg_id: int,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        message_repo: MessageRepository,
        contact_briefing: ContactBriefingService,
        router: Router,
    ) -> None: ...

    async def start(self) -> None:
        """Запуск бота з реєстрацією всіх handlers."""

    # Команди:
    async def _cmd_who(self, update, context) -> None:
        """WF-12: /who <phone|@username|tg_id> або пересланий дзвінок."""
        # 1. Парсинг input (телефон, username, tg_id, forwarded)
        # 2. Пошук контакту в БД
        # 3. ContactBriefingService.generate_briefing()
        # 4. Відправити briefing_text

    async def _cmd_resolve(self, update, context) -> None:
        """WF-6: /resolve <deal_id> <інструкція>."""
        # Зняти ескалацію, передати інструкцію агенту

    async def _cmd_cancel(self, update, context) -> None:
        """Скасувати угоду: /cancel <deal_id> <причина>."""

    async def _cmd_health(self, update, context) -> None:
        """Стан системи (заглушка до Етапу 7)."""

    async def _cmd_note(self, update, context) -> None:
        """Додати примітку: /note <deal_id> <текст>."""

    async def _handle_forwarded_call(self, update, context) -> None:
        """Обробка пересланого пропущеного дзвінка → WF-12."""

    def _is_authorized(self, user_id: int) -> bool:
        """Перевірка whitelist."""

    async def close(self) -> None: ...
```

### Тести для Етапу 2

```
tests/test_agent/
  test_context.py           — збірка контексту з різних зон
  test_responder.py         — mock Claude, різні типи повідомлень
  test_router.py            — mock Telethon DM events, WF-4 flow
tests/test_bot/
  test_telegram_bot.py      — mock python-telegram-bot, /who, /resolve, /cancel
  test_contact_briefing.py  — mock Claude, Contact Briefing output
tests/test_notifications/
  test_notifier.py          — mock bot, різні типи нотифікацій
```

### Критерій завершення Етапу 2

- [ ] Адмін-бот відповідає на /who з коректним брифінгом
- [ ] Router правильно ідентифікує контакт та збирає контекст
- [ ] Responder генерує короткі відповіді (1-2 речення)
- [ ] Невідомі контакти НЕ з логістичних груп ігноруються
- [ ] Confidence < 0.7 → ескалація оператору через Notifier
- [ ] Messages зберігаються (in + out)
- [ ] Unprocessed queue працює при збоях API
- [ ] `uv run mypy --strict src/agent/ src/bot/ src/notifications/` — no errors

---

## Етап 3: Matcher + активний режим

**Мета:** AI-based матчинг вантажів і перевізників. Активний пошук при наявності маржі.
**Залежності від Етапів 0-2:** models/, db/, services/, agent/context.py, agent/responder.py, notifications/notifier.py

### Файли для створення

#### 3.1 `prompts/matcher_prompt.md`

**Промпт:** Matcher (побічний), Temperature: 0
**Джерело:** `08_AI_PROMPTS.md`, секція 3

#### 3.2 `src/agent/matcher.py`

**Залежності:** `claude_client.py`, `codex.py`, `context.py`, `models/ai_outputs.py` (MatcherOutput)
**Таблиці:** `cargo_offers`, `market_prices`, `contacts`, `contact_routes`, `contact_reliability`, `exchange_rates`, `deals`
**Промпти:** Matcher
**Workflows:** WF-2

```python
class Matcher:
    """AI-based матчинг вантаж↔перевізник."""

    def __init__(
        self,
        claude_client: ClaudeClient,
        prompt_loader: PromptLoader,
        context_assembler: ContextAssembler,
        agent_config: AgentConfig,
    ) -> None: ...

    async def evaluate(self, cargo_offer: CargoOffer) -> MatcherOutput:
        """WF-2: Оцінити вантаж, вирішити active/passive/skip."""

    async def check_transport_against_open_cargos(self, transport_offer: CargoOffer) -> MatcherOutput | None:
        """Для type=transport: перевірити чи є відкриті cargo на маршруті."""
```

#### 3.3 `src/services/carrier_channel.py`

**Залежності:** Telethon, `config.py`
**Workflows:** WF-9

```python
class CarrierChannelService:
    """Публікація в Telegram-канал перевізників."""

    def __init__(self, client: TelegramClient, channel_id: int) -> None: ...

    async def publish_cargo(self, route: str, container_type: str, weight: float | None, date: str) -> int:
        """Опублікувати вантаж в канал. Повертає message_id."""
        # Формат: "Гданськ→Київ, 40'HC, 22т, 30.03. Хто вільний?"

    async def is_recently_published(self, route: str) -> bool:
        """Перевірити чи публікували цей маршрут за останню годину."""
```

#### 3.4 `src/deals/__init__.py`

Порожній.

#### 3.5 `src/deals/manager.py` (базова версія)

**Залежності:** `deal_repo.py`, `cargo_repo.py`, `contact_repo.py`, `notifier.py`, `agent/responder.py`, `config.py`
**Таблиці:** `deals`, `deal_events`, `cargo_offers`, `messages`
**Workflows:** WF-2→WF-3, WF-3.5

```python
class DealManager:
    """Управління життєвим циклом угод."""

    VALID_TRANSITIONS: dict[str, list[str]] = {
        "prospecting": ["negotiating", "cancelled"],
        "negotiating": ["agreed", "cancelled", "disputed"],
        "agreed": ["in_transit", "cancelled", "disputed"],
        "in_transit": ["completed", "cancelled", "disputed"],
        "completed": [],
        "cancelled": [],
        "disputed": ["negotiating", "cancelled"],
    }

    def __init__(
        self,
        deal_repo: DealRepository,
        cargo_repo: CargoRepository,
        contact_repo: ContactRepository,
        message_repo: MessageRepository,
        notifier: Notifier,
        client: TelegramClient,
        responder: Responder,
        agent_config: AgentConfig,
    ) -> None: ...

    async def create_deal_from_match(self, cargo_offer: CargoOffer, carrier_contact_id: str | None = None) -> Deal:
        """Створити deal зі статусом prospecting."""

    async def transition_status(self, deal_id: str, new_status: DealStatus, note: str | None = None) -> None:
        """Перехід статусу з валідацією."""

    async def initiate_carrier_search(self, deal: Deal, candidates: list[MatcherCandidate]) -> None:
        """WF-3: Надіслати пропозицію перевізникам."""
        # 1. Для кожного кандидата: перевірити активну угоду
        # 2. Згенерувати повідомлення через Responder
        # 3. Відправити DM через userbot
        # 4. Зберегти в messages
        # 5. Запустити таймер очікування (response_wait_hours)

    async def handle_carrier_response(self, deal_id: str, carrier_contact_id: str, accepted: bool) -> None:
        """Обробка відповіді перевізника."""
        # Accepted: зафіксувати carrier, іншим "вже не актуально"
        # Rejected: чекати далі

    async def check_cargo_actuality(self, deal: Deal) -> None:
        """WF-3.5: Запитати замовника чи вантаж актуальний."""

    async def escalate(self, deal_id: str, reason: str) -> None:
        """WF-6: Ескалація оператору."""

    async def resolve_escalation(self, deal_id: str, instruction: str) -> None:
        """Обробка /resolve від оператора."""

    async def cancel_deal(self, deal_id: str, reason: str, cancelled_by: str) -> None:
        """Скасування угоди."""

    async def _check_response_timeout(self, deal_id: str) -> None:
        """Перевірка таймауту відповіді перевізників."""
```

### Інтеграція: підключення Matcher до GroupMonitor

В `src/main.py` (або окремому wire-модулі) зв'язати:
```
GroupMonitor.on_new_cargo → Matcher.evaluate → DealManager.create_deal_from_match → DealManager.initiate_carrier_search
```

### Тести для Етапу 3

```
tests/test_agent/
  test_matcher.py           — mock Claude, різні сценарії маржі (active/passive/skip)
tests/test_deals/
  test_manager.py           — створення deal, transitions, carrier search
tests/test_services/
  test_carrier_channel.py   — mock Telethon, публікація в канал
```

### Критерій завершення Етапу 3

- [ ] Matcher визначає маржу > $100 → action=active
- [ ] Deal створюється зі статусом prospecting
- [ ] Пропозиція надсилається TOP-3 перевізникам
- [ ] Таймер очікування працює (response_wait_hours)
- [ ] Публікація в канал перевізників як fallback
- [ ] Конвертація валют через NBU rates при розрахунку маржі
- [ ] Нотифікація оператору: "Шукаю перевізника для вантажу X"
- [ ] Cargo-first: type=transport НЕ тригерить активний пошук
- [ ] `uv run mypy --strict src/agent/matcher.py src/deals/ src/services/carrier_channel.py` — no errors

---

## Етап 4: Deal Manager (повний цикл)

**Мета:** Повний цикл угоди: prospecting → completed. Формування заявок. Ескалація. Верифікація водіїв.
**Залежності від Етапів 0-3:** всі попередні модулі

### Файли для створення

#### 4.1 `prompts/verification_prompt.md`

**Промпт:** Verification Agent (побічний), Temperature: 0
**Джерело:** `08_AI_PROMPTS.md`, секція 5

#### 4.2 `src/agent/verification.py`

**Залежності:** `claude_client.py`, `codex.py`, `context.py`, `models/ai_outputs.py` (VerificationOutput)
**Таблиці:** `driver_contacts`, `deal_events`, `deals`
**Промпти:** Verification Agent
**Workflows:** WF-11

```python
class VerificationAgent:
    """Верифікація водіїв та дублікатів акаунтів."""

    def __init__(
        self,
        claude_client: ClaudeClient,
        prompt_loader: PromptLoader,
        context_assembler: ContextAssembler,
        deal_repo: DealRepository,
    ) -> None: ...

    async def verify(self, claimer_tg_id: int, claimed_contact_id: str | None = None) -> VerificationOutput:
        """WF-11: Визначити чи claimer є тим за кого себе видає."""

    async def check_driver(self, tg_id: int, phone: str | None) -> VerificationOutput:
        """Швидка перевірка водія по телефону/tg_id."""
```

#### 4.3 `src/deals/templates.py`

**Залежності:** `models/deal.py`, `models/contact.py`
**Workflows:** WF-4 (status=agreed)

```python
class ApplicationTemplate:
    """Генерація заявок по шаблону."""

    TEMPLATE = """ЗАЯВКА НА ПЕРЕВЕЗЕННЯ #{deal_id}

Дата: {date}
Маршрут: {route_from} → {route_to}
Контейнер: {container_type}
Лінія: {shipping_line}
Вага: {weight} т
Тип вантажу: {cargo_description}
Оплата: {payment_type}

{party_section}

Ціна перевезення: {price} {currency}
"""

    def generate_for_customer(self, deal: Deal, customer: Contact, carrier: Contact) -> str:
        """Заявка для замовника (з ціною замовника)."""

    def generate_for_carrier(self, deal: Deal, customer: Contact, carrier: Contact) -> str:
        """Заявка для перевізника (з ціною перевізника)."""
```

#### 4.4 `src/deals/documents.py`

**Залежності:** Telethon, `deal_repo.py`, `models/deal.py`
**Таблиці:** `deal_documents`
**Workflows:** WF-7

```python
class DocumentForwarder:
    """Forwarding документів між сторонами угоди."""

    def __init__(
        self,
        client: TelegramClient,
        deal_repo: DealRepository,
    ) -> None: ...

    async def handle_incoming_document(self, event, contact_id: str, deal_id: str) -> None:
        """WF-7: Зберегти документ та переслати іншій стороні."""

    async def send_application(self, deal_id: str, text: str, recipient_tg_id: int) -> None:
        """Відправити заявку контакту."""

    def _determine_recipient(self, deal: Deal, sender_contact_id: str) -> str | None:
        """Визначити одержувача документу."""
```

#### 4.5 Оновлення `src/deals/manager.py`

Додати:
```python
    async def generate_applications(self, deal_id: str) -> tuple[str, str]:
        """Згенерувати заявки для обох сторін."""

    async def handle_document(self, event, contact_id: str) -> None:
        """Делегувати в DocumentForwarder."""

    async def add_driver(self, deal_id: str, driver_name: str, driver_phone: str | None, driver_tg: str | None = None) -> None:
        """Додати водія до угоди."""
```

#### 4.6 Оновлення `src/agent/router.py`

Додати обробку:
- Вхідних документів/файлів → `DealManager.handle_document`
- Верифікації водіїв → `VerificationAgent.verify`
- Дублікатів акаунтів → `VerificationAgent.verify` + ескалація

#### 4.7 Оновлення `src/bot/telegram_bot.py`

Повноцінні команди:
- `/resolve <deal_id> <інструкція>` — зняти ескалацію
- `/cancel <deal_id> <причина>` — скасувати угоду
- `/note <deal_id> <текст>` — додати примітку

### Тести для Етапу 4

```
tests/test_deals/
  test_manager_full_cycle.py  — угода від prospecting до completed
  test_templates.py           — генерація заявок (customer vs carrier ціни)
  test_documents.py           — forwarding документів
tests/test_agent/
  test_verification.py        — верифікація водія, дублікат, unknown
```

### Критерій завершення Етапу 4

- [ ] Угода проходить повний цикл: prospecting → negotiating → agreed → in_transit → completed
- [ ] Заявки генеруються з РІЗНИМИ цінами для замовника і перевізника
- [ ] Верифікація водія: телефон збігається → verified_driver → обмежений доступ
- [ ] Дублікат акаунту → ескалація оператору
- [ ] /resolve знімає ескалацію та продовжує роботу агента
- [ ] /cancel скасовує угоду з причиною
- [ ] Документи пересилаються між сторонами через userbot
- [ ] Невалідні переходи статусу → InvalidDealTransitionError
- [ ] `uv run mypy --strict src/deals/ src/agent/verification.py` — no errors

---

## Етап 5: Profiler + інтелект

**Мета:** AI-профілювання контактів. Вплив профілю на рішення агента.
**Залежності від Етапів 0-4:** всі попередні модулі

### Файли для створення

#### 5.1 `prompts/profiler_prompt.md`

**Промпт:** Profiler (побічний), Temperature: 0
**Джерело:** `08_AI_PROMPTS.md`, секція 4

#### 5.2 `src/profiler/__init__.py`

Порожній.

#### 5.3 `src/profiler/profiler.py`

**Залежності:** `claude_client.py`, `codex.py`, `context.py`, `contact_repo.py`, `message_repo.py`, `models/ai_outputs.py` (ProfilerOutput)
**Таблиці:** `contact_psychology`, `contact_reliability`, `price_records`, `messages` (profiler_processed flag)
**Промпти:** Profiler
**Workflows:** WF-4, крок 9

```python
class Profiler:
    """Оновлення профілів контактів після взаємодій."""

    def __init__(
        self,
        claude_client: ClaudeClient,
        prompt_loader: PromptLoader,
        context_assembler: ContextAssembler,
        contact_repo: ContactRepository,
        message_repo: MessageRepository,
    ) -> None: ...

    async def update_profile(self, contact_id: str, deal_result: dict | None = None) -> ProfilerOutput:
        """On-demand виклик Profiler."""
        # 1. Зібрати контекст (current_profile + unprocessed_messages)
        # 2. Якщо unprocessed_messages порожній → skip
        # 3. AI-виклик Profiler
        # 4. Застосувати psychology_updates → contact_psychology
        # 5. Застосувати price_updates → price_records
        # 6. Застосувати reliability_updates → contact_reliability
        # 7. Перерахувати overall_reliability
        # 8. Позначити повідомлення як profiler_processed

    async def recalculate_reliability_for_contact(self, contact_id: str) -> int:
        """Перерахунок overall_reliability за формулою з 03_CONTACT_PROFILE.md."""
        # base = 50
        # + (deals_completed * 5)  до +50
        # - (deals_cancelled * 15)
        # - (avg_payment_delay_days * 2)
        # + (communication_culture - 3) * 5
        # - (disputes_count * 10)
        # = clamp(0, 100)
```

#### 5.4 Оновлення `src/agent/router.py`

Інтеграція Profiler:
```python
# В _handle_dm, після відправки відповіді:
if any(a.type == "update_profile" for a in output.actions):
    asyncio.create_task(self._profiler.update_profile(contact_id))
```

### Тести для Етапу 5

```
tests/test_profiler/
  test_profiler.py           — mock Claude, різні оновлення (psychology, price, reliability)
  test_reliability_calc.py   — формула overall_reliability, edge cases
```

### Критерій завершення Етапу 5

- [ ] Profiler оновлює psychology після 3+ взаємодій
- [ ] Нові ціни записуються в price_records
- [ ] overall_reliability перераховується коректно за формулою
- [ ] Profiler обробляє ТІЛЬКИ ще не оброблені повідомлення
- [ ] Профіль впливає на контекст для наступних відповідей Responder
- [ ] Профіль впливає на вибір кандидатів Matcher (reliability, last_seen)
- [ ] `uv run mypy --strict src/profiler/` — no errors

---

## Етап 6: Тестування через MCP

**Мета:** Прогнати всі тестові сценарії з `Docs/Test_scenarios/` через MCP-сервер TG_mcp_clon.
**Залежності від Етапів 0-5:** вся система повинна працювати

### Підготовка

#### 6.1 Налаштувати MCP-сервер TG_mcp_clon

- `TG_mcp_clon/config.json` — два акаунти (A і B)
- Авторизація обох акаунтів
- Створити тестові групи: `[TEST] Turbo-ИМПОРТ`, `[TEST] Tlg Ukraine Logistics`
- Створити тестовий канал: `[TEST] Перевізники PL→UA`
- Додати акаунт C (LogistAgent) в тестові групи

#### 6.2 Створити тестове середовище

- Окрема БД: `data/logist_test.db`
- Seed-дані: 8 тестових контактів (Тест-Олег, Тест-Василь, тощо)
- Тестові маршрути: Гданськ→Київ, Гданськ→Одеса, Гдиня→Львів, Варшава→Дніпро
- Цінові записи для market_prices
- Курси валют

### Сценарії для прогону

| Файл | ID | Кількість | Покриття |
|------|----|-----------|----------|
| `01_SECURITY_SCENARIOS.md` | SEC-1..SEC-6 | 6 | Responder, Verification |
| `02_NEGOTIATION_SCENARIOS.md` | NEG-1..NEG-5 | 5 | Parser, Matcher, Responder, Profiler |
| `03_CANCELLATION_SCENARIOS.md` | CAN-1..CAN-4 | 4 | Responder, DealManager |
| `04_ESCALATION_SCENARIOS.md` | ESC-1..ESC-4 | 4 | Responder, Notifier |
| `05_FIRST_CONTACT_SCENARIOS.md` | FC-1..FC-4 | 4 | Responder |
| `06_VERIFICATION_SCENARIOS.md` | VER-1..VER-4 | 4 | Verification, Responder |
| `07_RECOVERY_SCENARIOS.md` | REC-1..REC-4 | 4 | unprocessed_messages, health |
| `08_CHANNEL_SCENARIOS.md` | CH-1..CH-3 | 3 | CarrierChannelService |

**Всього: 34 сценарії**

### Порядок прогону

1. **Безпека (SEC)** — найкритичніше, перший прогін
2. **Переговори (NEG)** — основний flow
3. **Перший контакт (FC)** — онбординг нових контактів
4. **Ескалації (ESC)** — коректна ескалація
5. **Скасування (CAN)** — скасування на різних етапах
6. **Верифікація (VER)** — водії та дублікати
7. **Збої (REC)** — recovery
8. **Канал (CH)** — публікація в канал

### Критерій завершення Етапу 6

- [ ] Всі 34 сценарії пройдені
- [ ] SEC-1..SEC-6: агент НЕ розкриває маржу, базу, рейтинги
- [ ] NEG-1..NEG-5: угоди проходять повний цикл
- [ ] Дефекти знайдені та виправлені
- [ ] Повторний прогін SEC + NEG після виправлень — pass

---

## Етап 7: Polish + запуск

**Мета:** Фінальна полірка, операційна стійкість, деплой.
**Залежності від Етапів 0-6:** вся система протестована

### Файли для створення

#### 7.1 `src/monitoring/__init__.py`

Порожній.

#### 7.2 `src/monitoring/health.py`

**Залежності:** всі сервіси, `config.py`, `cargo_repo.py`, `message_repo.py`
**Workflows:** WF-8 (cron tasks)

```python
class HealthMonitor:
    """Health checks та cron jobs."""

    def __init__(
        self,
        claude_client: ClaudeClient,
        userbot_client: TelegramClient,
        db_connection: aiosqlite.Connection,
        cargo_repo: CargoRepository,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        message_repo: MessageRepository,
        nbu_service: NBURatesService,
        notifier: Notifier,
        config: Settings,
    ) -> None: ...

    async def start(self) -> None:
        """Запуск periodic tasks."""

    async def check_all(self) -> dict[str, dict]:
        """Перевірка всіх модулів. Повертає статус для /health."""

    async def _check_claude_api(self) -> dict: ...
    async def _check_userbot(self) -> dict: ...
    async def _check_database(self) -> dict: ...
    async def _check_parser_activity(self) -> dict: ...
    async def _check_nbu_rates(self) -> dict: ...

    # Cron jobs
    async def _hourly_cleanup(self) -> None:
        """WF-8: expire old cargo_offers."""

    async def _daily_tasks(self) -> None:
        """WF-8: market_prices recalc, reliability recalc, NBU rates, backup, digest."""

    async def _nightly_archive(self) -> None:
        """WF-8: archive old deals, messages, delete expired cargo."""

    async def _send_daily_digest(self) -> None:
        """WF-5: щоденний дайджест оператору."""

    async def _backup_database(self) -> None:
        """Бекап SQLite. Зберігати останні N бекапів."""
```

#### 7.3 Оновлення `src/bot/telegram_bot.py`

```python
    async def _cmd_health(self, update, context) -> None:
        """Стан системи з HealthMonitor.check_all()."""

    async def _cmd_archive_stats(self, update, context) -> None:
        """/archive stats — статистика архіву."""
```

#### 7.4 `src/main.py`

**Залежності:** ВСІ модулі
**Workflows:** entry point, DI wiring, graceful shutdown

```python
async def main() -> None:
    """Entry point: ініціалізація, DI, запуск, graceful shutdown."""
    # 1. Завантажити Settings з .env
    # 2. Ініціалізувати БД (init_db)
    # 3. Завантажити AgentConfig з БД
    # 4. Створити з'єднання
    # 5. Ініціалізувати repositories
    # 6. Ініціалізувати сервіси (ClaudeClient, NBURatesService)
    # 7. Ініціалізувати AI-компоненти (PromptLoader, Responder, Matcher, Profiler, Verification)
    # 8. Ініціалізувати ContextAssembler
    # 9. Ініціалізувати DealManager, DocumentForwarder
    # 10. Ініціалізувати Notifier
    # 11. Ініціалізувати ContactBriefingService
    # 12. Створити Telethon client (userbot)
    # 13. Ініціалізувати GroupMonitor, Router
    # 14. Ініціалізувати AdminBot
    # 15. Ініціалізувати HealthMonitor
    # 16. Запустити всі модулі
    # 17. Зареєструвати signal handlers для graceful shutdown
    # 18. Чекати (idle)

async def shutdown(signal, loop) -> None:
    """Graceful shutdown: cancel tasks, close connections."""

if __name__ == "__main__":
    asyncio.run(main())
```

#### 7.5 Оновлення `src/agent/router.py`

Додати rate limiting:
```python
    async def _check_rate_limit(self, contact_id: str) -> bool:
        """Не більше 3 повідомлень одному контакту на годину."""
```

#### 7.6 Налаштування логування

В `src/config.py` або окремому `src/logging_config.py`:
```python
def setup_logging(log_level: str, log_dir: Path) -> None:
    """Налаштувати логування з ротацією файлів."""
    # Формат: logs/logist_YYYY-MM-DD.log
    # Ротація: 7 днів
    # CRITICAL + ERROR → миттєвий алерт через Notifier
```

### Тести для Етапу 7

```
tests/test_monitoring/
  test_health.py              — mock checks, cron jobs
tests/test_integration/
  test_main_wiring.py         — DI wiring, всі модулі ініціалізуються
  test_graceful_shutdown.py   — shutdown без втрати даних
```

### Критерій завершення Етапу 7

- [ ] `/health` показує стан всіх модулів
- [ ] Щоденний дайджест формується та відправляється
- [ ] Бекап SQLite працює кожні 6 годин
- [ ] Архівування старих угод (>90 днів) працює
- [ ] Автоочищення expired cargo_offers (>30 днів) працює
- [ ] Rate limiting: max 3 повідомлення/годину одному контакту
- [ ] Graceful shutdown: всі tasks завершуються коректно
- [ ] Логування з ротацією працює
- [ ] `uv run pytest tests/ -x` — all pass
- [ ] `uv run mypy --strict src/` — no errors
- [ ] `uv run ruff check src/` — no errors
- [ ] Система запускається через `uv run python src/main.py`

---

## Ризикові точки

### Етап 0: Підготовка

| Ризик | Мітигація |
|-------|-----------|
| Міграція з logist_export — невалідні дані | Валідація через Pydantic при міграції, skip невалідних записів з логом |
| Нормалізація міст — пропущені варіанти | Розширюваний словник CITY_NORMALIZATION, логування unnormalized |

### Етап 1: Парсер

| Ризик | Мітигація |
|-------|-----------|
| Claude API галюцинує при парсингу | Temperature=0, structured JSON output, валідація через ParserOutput Pydantic |
| Rate limit Claude API | Retry з exponential backoff (1s, 2s, 4s, 8s), запис в unprocessed_messages |
| Повідомлення не на українській/російській | Parser prompt обробляє обидві мови, транслітерацію, суржик |

### Етап 2: Бот + Router

| Ризик | Мітигація |
|-------|-----------|
| AI відповідає роботизовано | AGENT_CODEX з прикладами, Temperature=0.3, A/B тестування |
| AI розкриває заборонену інформацію | Explicit заборони в prompt, тести SEC-1..SEC-6, confidence gate |
| Telegram банить userbot | Окремий акаунт, rate limiting, не спамити, human-like delays |

### Етап 3: Matcher

| Ризик | Мітигація |
|-------|-----------|
| Невірна оцінка маржі (різні валюти) | Конвертація через NBU rates перед розрахунком, все в USD |
| Matcher пропонує зайнятого перевізника | Перевірка `has_active_deal_with_carrier` перед пропозицією |
| Паралельні переговори за одне місце | Strict послідовна обробка відповідей, block при фіксації |

### Етап 4: Deal Manager

| Ризик | Мітигація |
|-------|-----------|
| Невалідний перехід статусу | VALID_TRANSITIONS dict, InvalidDealTransitionError |
| Маржа розкривається через заявку | ДВІ різні заявки з РІЗНИМИ цінами, тест на це |
| Верифікація обійдена соціальною інженерією | verified_driver тільки по телефону, дублікати → ескалація оператору |

### Етап 5: Profiler

| Ризик | Мітигація |
|-------|-----------|
| Profiler робить висновки з 1 повідомлення | Правило "мінімум 3 взаємодії" в prompt, перевірка кількості |
| Trust_level знижений помилково | Правило "тільки підвищення" в prompt |
| Вигадані ціни | Правило "тільки явно озвучені" в prompt |

### Етап 6: MCP тестування

| Ризик | Мітигація |
|-------|-----------|
| MCP акаунти забанені | Використовувати тестові акаунти, не спамити, паузи між тестами |
| Тестова БД забруднена | tg_test_cleanup() між кожними сценаріями |
| LogistAgent не бачить тестових повідомлень | Перевірити що акаунт C в тестових групах та в базі |

### Етап 7: Запуск

| Ризик | Мітигація |
|-------|-----------|
| Оператор не довіряє агенту | Перший тиждень: 100% підтвердження оператора для вихідних, моніторинг вхідних |
| SQLite corrupt | Бекапи кожні 6 годин, WAL mode, integrity check |
| Graceful shutdown втрачає дані | Весь стан в БД, recovery з unprocessed_messages |

---

## Загальний підсумок

| Етап | Файлів | Тестових файлів | Орієнтовна складність |
|------|--------|-----------------|----------------------|
| 0 | ~22 | ~6 | Фундамент (models, DB, repos) |
| 1 | ~5 | ~4 | Parser + Claude API + NBU |
| 2 | ~9 | ~5 | Router + Responder + Admin Bot |
| 3 | ~4 | ~3 | Matcher + DealManager (basic) + Channel |
| 4 | ~3 + updates | ~4 | Verification + Documents + Templates |
| 5 | ~2 | ~2 | Profiler + Reliability |
| 6 | MCP config | — | 34 MCP-сценарії |
| 7 | ~3 + updates | ~3 | Health + Main + Polish |
| **Всього** | **~48 файлів** | **~27 тестових** | — |
