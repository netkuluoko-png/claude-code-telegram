# Pre-code documentation for AI agent projects: a practitioner's framework

**The most effective way to document an AI agent before coding is a layered, spec-driven approach**: start with a Product Requirements Document adapted for AI behavior, layer in Architecture Decision Records for non-obvious choices, define agent behavior via YAML configs and state machine diagrams, and structure everything so both humans and AI coding assistants can consume it. Teams building with CrewAI, LangGraph, and AutoGen have converged on remarkably similar patterns — declarative YAML for agent roles, JSON Schema for tool contracts, and Mermaid state diagrams for conversation flows. This report synthesizes these patterns into a practical framework you can encode directly into a Claude Code SKILL.md file.

The stakes are high: OX Security's analysis of 300 AI-assisted projects found **80-90% suffer from over-specification or under-specification** — AI agents either build features nobody asked for or guess wrong on architecture. Spec-driven development, formalized by GitHub's Spec Kit and Addy Osmani's framework in early 2026, solves this by making structured documentation the primary artifact that gates all code generation.

---

## The documentation stack: seven artifacts, one coherent system

The pre-code documentation for an AI agent project needs exactly **seven core documents**, each serving a distinct purpose. This stack emerged from synthesizing Microsoft's Multi-Agent Reference Architecture, Eugene Yan's ML Design Doc template, and the emerging AGENTS.md standard from the Agentic AI Foundation.

**1. PRD (Product Requirements Document)** defines *what* to build. Miqdad Jaffer, Product Lead at OpenAI (formerly Shopify), published the most battle-tested AI-specific PRD template in March 2025. It uses three pillars: Strategic Context (why build this), Product & Technical Excellence (what and how), and Go-to-Market (launch strategy). The AI-specific sections that traditional PRDs lack include: model selection rationale, accuracy/quality thresholds, hallucination mitigation strategy, cost per inference, human-in-the-loop requirements, and AI behavior specification with edge cases.

**2. Design Doc** defines *how* to build it technically. Eugene Yan's ML Design Doc template (650+ GitHub stars) is the most widely referenced. Its structure — Overview → Motivation → Success Metrics → Requirements → Methodology → Implementation → Appendix — maps cleanly to agent projects when extended with sections for prompt architecture, tool/function calling specs, and safety guardrails.

**3. Architecture Decision Records (ADRs)** capture *why* specific choices were made. The MADR (Markdown ADR) format works well, but AI agent projects need seven additional decision categories beyond standard software: model selection, prompt strategy, safety & guardrails, tool calling architecture, memory/context management, agent orchestration pattern, and evaluation strategy.

**4. C4 Architecture Diagrams** provide visual understanding at four zoom levels. For an AI chatbot, the Context diagram shows users, LLM providers, and external systems; the Container diagram separates the Chat UI, API Backend, Intent Classifier, LLM Connector, Domain Agent Router, Vector Database, and Conversation Store; the Component diagram details the internal orchestration flow within each container.

**5. Agent Behavior Specification** documents personality, states, and decision logic (detailed below).

**6. Data Schema Documentation** covers conversation state, user profiles, and message history using entity-relationship diagrams and access pattern definitions.

**7. Tool/API Contract Documentation** specifies every tool the agent can invoke, using JSON Schema (OpenAI function calling format) or MCP protocol definitions.

---

## Agent behavior: YAML configs, state machines, and guardrails

Three major frameworks have independently converged on similar documentation patterns for agent behavior, and each offers a distinct strength worth adopting.

**CrewAI's YAML-based role specification** is the cleanest pattern for documenting agent identity. Each agent gets three mandatory fields — `role`, `goal`, and `backstory` — plus operational parameters like `max_iter`, `max_execution_time`, `allow_delegation`, and `tools`. Tasks are separately defined in a `tasks.yaml` file with `description`, `expected_output`, and `agent` assignment. This separation of agent definition from task definition is a key architectural insight: agents are reusable, tasks are project-specific.

```yaml
# agents.yaml
negotiator:
  role: "Deal Negotiation Specialist"
  goal: "Negotiate optimal terms while maintaining relationship quality"
  backstory: "Experienced negotiator who balances assertiveness with empathy"
  tools: [search_contacts, check_calendar, send_proposal]
  max_iter: 15
  allow_delegation: true
```

**LangGraph's state machine approach** is best for documenting complex conversation flows. Agents are modeled as directed graphs where nodes represent computation units (LLM calls, tool calls, custom functions), edges can be direct or conditional, and a shared TypedDict state object flows through the graph. This maps perfectly to Telegram bot conversation handlers. Document these using **Mermaid `stateDiagram-v2`** diagrams with green edges for success paths and red edges for validation failures.

**Safety guardrails require their own documentation layer.** The OpenAI Agents SDK established a three-tier pattern: input guardrails (validate user input before agent processing), output guardrails (validate agent responses before delivery), and tool guardrails (gate specific tool invocations). LangChain extends this with middleware-based guardrails including content filters, PII redaction, and human-in-the-loop interrupts. An emerging specification called **ESCALATE.md** formalizes escalation protocols with triggers, approval channels, timeout policies, and audit logging requirements.

For prompt engineering specifications, document each prompt as a versioned artifact with: system role definition, task description, input/output format specification, validation criteria, version number, and last-updated timestamp. LangSmith treats prompts like Git commits — each saved update gets a commit hash, with human-readable tags for environment-specific deployment (production, staging, development).

Fallback behaviors should be documented as an **escalation hierarchy table**: Level 1 (low confidence → alternative model, <2s), Level 2 (system unavailable → backup agent, <10s), Level 3 (complex query → human transfer, <30s), Level 4 (system failure → emergency protocol, immediate). CrewAI operationalizes this with `max_iter`, `max_retry_limit`, `max_execution_time`, and `respect_context_window` parameters.

---

## Telegram bot documentation has its own essential patterns

Telegram bot architecture rests on two foundational design patterns that must be documented before coding: the **Chain of Responsibility** (handlers independently decide whether to process each update) and **Finite State Machines** (conversation flows as directed graphs with known transitions). The recommended approach combines both: process updates through the handler chain, where each handler receives the incoming update plus the current FSM state.

**The ConversationHandler specification** is the single most important pre-code document for a Telegram bot. It must define four collections: entry_points (handlers that start the conversation), states (dict mapping state names to handler lists), fallbacks (handlers for unrecognized input), and timeout behavior. Configuration options like `per_chat`, `per_user`, `per_message`, `conversation_timeout`, and `allow_reentry` fundamentally shape behavior and must be decided before coding.

A **Chat Type Behavior Matrix** is essential for bots that operate across private chats, groups, and channels. Key differences to document: bots receive all messages in private chats but only commands/@mentions in groups (privacy mode); ConversationHandler works fully in private chats but is limited in groups and non-functional in channels; bots can only initiate messages to users who have previously sent /start.

For **autonomous outreach** — the distinguishing feature of the user's project — document a Job Schedule Table covering: job name, trigger type (cron/timer/event), target audience, content template, frequency, eligibility conditions, and opt-in requirements. Critical constraint: Telegram limits bots to **30 messages/second globally** and **1 message/second per chat in groups**. The bot can only proactively message users who have initiated contact first, so chat_id persistence is a prerequisite.

**Handler priority and routing** should be documented as numbered groups (python-telegram-bot) or a Router tree (aiogram). In python-telegram-bot, handlers execute in priority groups (lower number = higher priority), with the first matching handler winning within each group. In aiogram v3, Routers can be nested for modular organization: Dispatcher (root) → admin_router → user_router → onboarding_router. For AI-enhanced bots adding NLP, document the intent classification → confidence threshold → handler routing → fallback strategy pipeline.

The **webhook vs. polling decision** deserves an ADR. Polling is simpler (no SSL, no public URL) but limited to a single process. Webhooks deliver real-time responses with **60-80% lower resource usage**, support load balancing and serverless deployments, but require HTTPS on ports 443, 80, 88, or 8443. Best practice: use environment-variable switching between polling (development) and webhooks (production).

---

## Documentation-driven development for AI coding assistants

The most significant shift in 2025-2026 is **spec-driven development (SDD)** — writing specifications as the primary artifact that AI coding assistants consume directly. Martin Fowler's ThoughtWorks taxonomy identifies three maturity levels: spec-first (write spec, use it, discard), spec-anchored (spec evolves as a living document), and spec-as-source (humans edit only specs, never code). For AI agent projects, spec-anchored is the practical sweet spot.

**The four-phase SDD workflow** formalized by GitHub's Spec Kit works as follows: (1) **Specify** — provide high-level description, AI generates detailed spec with user journeys and success criteria; (2) **Plan** — define tech stack, architecture, constraints; (3) **Tasks** — AI breaks plan into small, reviewable work units; (4) **Implement** — AI executes tasks one by one with human review gating.

**CLAUDE.md structure** should follow three sections — WHAT (tech stack, project structure, codebase map), WHY (project purpose, component responsibilities), HOW (build commands, test runners, verification steps). Critical insight from HumanLayer's research: **keep CLAUDE.md under 300 lines** (their own is under 60). Claude Code's system prompt already contains ~50 instructions, and frontier LLMs follow only 150-200 instructions with reasonable consistency. Use progressive disclosure — task-specific docs in separate files referenced from the main config.

**SKILL.md files** use YAML frontmatter plus Markdown body:

```markdown
---
name: ai-agent-documentation
description: Guides creation of pre-code documentation for AI agent projects
---
# AI Agent Documentation Skill

## Instructions
[Step-by-step workflow]

## Rules
[Constraints and patterns]

## Examples
[Concrete usage examples]
```

**What makes documentation AI-readable**: GitHub's analysis of 2,500+ agent configuration files found six essential areas — Commands (full executable commands with flags), Testing (framework, file locations, coverage expectations), Project Structure (explicit directory layout), Code Style (concrete examples over prose descriptions), Git Workflow (branch naming, commit format), and Boundaries (what the agent must never touch). The single most effective practice: **one concrete code example outperforms three paragraphs of description**.

For **Cursor rules**, the current best practice uses `.cursor/rules/*.mdc` files with metadata specifying description, glob patterns, and application mode (alwaysApply, auto-attached, agent-requested, or manual). Keep individual files under 6,000 characters and combined rules under 12,000 characters.

---

## Quality criteria and anti-patterns that derail AI projects

Documentation is "good enough to code from" when it passes a **completeness checklist across six dimensions**: commands are executable, testing strategy is specified, project structure is explicit, code style has concrete examples, git workflow is defined, and boundaries are stated. Microsoft's Engineering Fundamentals Playbook adds: design reviews for each major component documented with alternatives, clear non-functional requirements captured, and risks documented.

**Google's design doc review** focuses on whether "any decision that could provoke significant discussion in code review" is explained in the document. The key quality signal: a design doc should be comprehensible to any engineer at the company without additional context. **Amazon's 6-pager** enforces this through narrative-style prose (no bullet points in main sections), dense 10-point font across exactly 6 pages, and a process where the first 20 minutes of the review meeting are spent in silent reading.

The most damaging anti-patterns in AI agent project documentation:

- **Over-specification** (found in 80-90% of projects): AI agents implement hypothetical scenarios not in requirements, add OAuth when nobody asked for it, handle impossible error cases. The fix: explicit "do not build" lists and `🚫 Never` boundaries in specs
- **Under-specification**: "Build authentication" → AI guesses wrong patterns; components make 6-7x more API calls than necessary because architectural patterns weren't specified. The fix: constraint-based specs ("Create user service: <100 lines, 3 methods max, only bcrypt dependency")
- **Context blindness**: AI follows patterns in currently loaded files but won't maintain architectural consistency across context window limits, leading to the same rate limiter implemented 4 separate times. The fix: explicit cross-reference documentation
- **Instruction overload**: CLAUDE.md + skills + rules + user messages exceeds the LLM's instruction-following capacity, causing uniform degradation. The fix: minimal always-on config, progressive disclosure for task-specific guidance
- **Context soup**: mixing requirements, architecture, implementation, and debugging in one session. The fix: each phase gets its own focused context

---

## Practical template structure for a SKILL.md file

Based on all research findings, the SKILL.md for AI agent documentation should encode a **workflow that produces seven artifacts** in sequence, following the spec-driven development methodology. The recommended project documentation structure:

```
docs/
├── PRD.md                    # Product requirements (AI-specific)
├── DESIGN.md                 # Technical design document
├── adr/
│   ├── 001-model-selection.md
│   ├── 002-orchestration-pattern.md
│   └── 003-webhook-vs-polling.md
├── agents/
│   ├── agents.yaml           # Agent role/goal/backstory definitions
│   └── tasks.yaml            # Task specifications
├── behavior/
│   ├── state-machines.md     # Mermaid stateDiagram-v2 flows
│   ├── escalation.md         # Fallback hierarchy table
│   └── guardrails.md         # Safety constraints
├── prompts/
│   └── system-prompts.md     # Versioned prompt specifications
├── tools/
│   └── tool-contracts.md     # JSON Schema tool definitions
├── data/
│   └── schema.md             # ER diagrams, access patterns
└── telegram/
    ├── handlers.md           # Handler registry table
    ├── commands.md           # Command specification table
    └── chat-matrix.md        # Chat type behavior matrix
```

The SKILL.md itself should instruct Claude Code to produce these documents in dependency order: PRD first (establishes scope and boundaries), then Design Doc (technical approach), then ADRs (key decisions), then agent specs and behavior docs (implementation contracts), and finally data schemas and tool contracts. Each document should use the Ukrainian language for narrative content while preserving English for all technical terms, framework names, code examples, YAML keys, and JSON schemas — a pattern that maximizes readability for Ukrainian-speaking developers working with English-dominant tooling.

## Conclusion

The pre-code documentation landscape for AI agents has matured rapidly. Three convergent trends define the current best practice: **declarative YAML** for agent behavior (pioneered by CrewAI, adopted broadly), **JSON Schema** as the universal tool contract format (from OpenAI's function calling to MCP), and **spec-driven development** as the workflow connecting documentation to AI-assisted code generation. The most important insight is that documentation for AI agent projects serves a dual audience — human developers who review and reason about the design, and AI coding assistants that consume specs to generate implementation. Writing for both audiences simultaneously requires structured formats, concrete examples over prose descriptions, explicit boundaries, and progressive disclosure. The anti-pattern data is clear: the cost of under-specifying or over-specifying is 6-7x wasted effort. The sweet spot is constraint-based specifications that define what to build, what not to build, and exactly where the boundaries lie.