# Building the optimal Claude Code SKILL.md for AI agent documentation

**A well-structured documentation skill for Claude Code should use progressive disclosure across a ~200-line orchestrator SKILL.md backed by 10 template files and a YAML dependency manifest** — not a single monolithic file. Research across Anthropic's official skills repository, 10+ open-source examples, and practitioner guides reveals that the most effective documentation-generation skills follow a three-stage workflow (context gathering → generation → review) with explicit dependency graphs between documents and tiered review checklists. The user's existing 10-document structure is stronger than most open-source AI agent projects, but encoding it as a skill requires specific architectural decisions about template storage, cross-reference management, and change propagation.

Anthropic's own `doc-coauthoring` skill — the closest official analog — demonstrates that documentation skills work best when they define a collaborative workflow rather than dumping templates. The key insight: **Claude already knows how to write docs; the skill's job is to encode your project-specific patterns, quality standards, and interdependencies.**

---

## How Claude Code actually loads and uses skills

Understanding the loading mechanics is essential before designing the skill. Claude Code uses a **three-level progressive disclosure system** that directly shapes how to organize content.

**Level 1** loads only the YAML frontmatter `name` and `description` from every installed skill at startup — roughly **100 tokens per skill**. This metadata lives permanently in context. **Level 2** loads the full SKILL.md body only when Claude determines the skill is relevant (matching the description to the user's request). **Level 3** involves Claude reading additional files from `references/` or `templates/` directories on demand — consuming zero tokens until explicitly accessed.

The practical implication: the SKILL.md body should stay **under 500 lines** (Anthropic's official recommendation) or roughly **2,000 tokens** for best adherence. Everything else — templates, checklists, terminology tables — belongs in separate files that Claude reads only when a specific workflow step requires them. Anthropic's engineering blog confirms that bundled reference files are "effectively unbounded" since they don't enter context until read.

The required format is straightforward. Every skill lives in a directory under `.claude/skills/` with a mandatory `SKILL.md` file containing YAML frontmatter between `---` markers. The `name` field (max 64 chars, kebab-case only) and `description` field (max 1024 chars) are required. The description must specify both WHAT the skill does and WHEN to trigger it — Anthropic recommends including specific trigger phrases and negative triggers ("DO NOT TRIGGER when..."). Optional frontmatter fields include `context: fork` for isolated execution, `allowed-tools` to restrict Claude's tool access, and `model` to override which model runs the skill.

---

## Recommended architecture: orchestrator with template files

Based on patterns from Anthropic's `mcp-builder` skill, the `terraform-skill` (1.4k stars), and `levnikolaevich/claude-code-skills` documentation pipeline, the optimal structure for a 10-document documentation suite is:

```
.claude/skills/
  project-docs/
    SKILL.md                            # Orchestrator (~200 lines)
    references/
      document-manifest.yaml            # Dependency graph between all 10 docs
      review-checklist.md               # Tiered quality checklist
      style-conventions.md              # Ukrainian + English patterns, ASCII diagrams
      cross-reference-format.md         # How docs reference each other
    templates/
      01-project-spec.md                # Template for PROJECT_SPEC
      02-architecture.md                # Template for ARCHITECTURE
      03-contact-profile.md             # Template for CONTACT_PROFILE
      04-agent-codex.md                 # Template for AGENT_CODEX
      05-database.md                    # Template for DATABASE
      06-workflows.md                   # Template for WORKFLOWS
      07-mvp-plan.md                    # Template for MVP_PLAN
      08-ai-prompts.md                  # Template for AI_PROMPTS
      09-operations.md                  # Template for OPERATIONS
      10-contact-verification.md        # Template for CONTACT_VERIFICATION
```

The **SKILL.md orchestrator** should contain only the workflow steps, document dependency order, and references to where templates and checklists live. Each **template file** encodes the exact section structure, required fields, example content, and anti-patterns for that document type. The **manifest** defines which documents depend on which, enabling Claude to process them in topological order and propagate changes correctly.

This architecture mirrors Anthropic's own design philosophy. The `terraform-skill` uses a ~4,400-token core SKILL.md with 6 reference files totaling ~26,000 tokens — a ratio of roughly **1:6 between orchestrator and reference content**. For the user's 10-document suite, the orchestrator should be ~200 lines while templates can be 50-100 lines each.

---

## The dependency manifest solves cross-reference management

The single most important artifact for managing 10 interdependent documents is an explicit dependency graph. When Claude generates document 06 (Workflows), it needs to know that workflows reference components from 02 (Architecture), contact fields from 03 (Contact Profile), database tables from 05 (Database), and AI prompts from 08 (AI Prompts). Without this map, Claude generates documents in isolation and cross-references break.

The manifest should be a YAML file in `references/`:

```yaml
documents:
  - id: "01_PROJECT_SPEC"
    depends_on: []
    feeds_into: ["02_ARCHITECTURE", "07_MVP_PLAN"]
    key_exports: [project_name, business_model, phases, success_metrics]

  - id: "02_ARCHITECTURE"
    depends_on: ["01_PROJECT_SPEC"]
    feeds_into: ["03_CONTACT_PROFILE", "05_DATABASE", "06_WORKFLOWS", "08_AI_PROMPTS"]
    key_exports: [context_zones, components_list, data_flow, communication_principles]

  - id: "03_CONTACT_PROFILE"
    depends_on: ["02_ARCHITECTURE"]
    feeds_into: ["05_DATABASE", "06_WORKFLOWS", "08_AI_PROMPTS", "10_VERIFICATION"]
    key_exports: [profile_fields, scoring_formula, update_triggers, security_rules]

  - id: "05_DATABASE"
    depends_on: ["02_ARCHITECTURE", "03_CONTACT_PROFILE"]
    feeds_into: ["06_WORKFLOWS", "09_OPERATIONS"]
    key_exports: [table_schemas, indexes, constraints]
```

The generation order derived from this graph ensures no document references entities that haven't been defined yet. Claude reads this manifest at the start of any generation or review task, then processes documents in dependency order: **01 → 02 → 03/04 → 05 → 06 → 07/08 → 09 → 10**.

For change propagation — when the user updates architecture, which workflows need revision? — the manifest's `feeds_into` field provides the blast radius. A dedicated review step in the skill reads the manifest, identifies affected downstream documents, and reports what needs updating before making changes.

---

## Encoding the user's documentation style as conventions

The user's documentation has distinctive patterns that must be explicitly encoded so Claude reproduces them on new projects. These patterns go in `references/style-conventions.md`, not in SKILL.md itself:

**Language conventions**: Ukrainian prose with English technical terms kept in English (API, JSON, SQL, SQLite, Telethon, Claude API). Format for first occurrence of a concept: Ukrainian term with English in parentheses. The style file should include a terminology mapping table with 30-50 core terms.

**Structural conventions**: ASCII diagrams for data flow (not Mermaid — the user specifically uses ASCII art), tables for field definitions and risk matrices, code blocks for JSON schemas and database DDL, cross-references using the pattern "детальніше: див. XX_DOCUMENT.md", explicit anti-pattern sections ("Заборонено / What NOT to do"), and formulas written out with named variables.

**Content conventions**: Every AI component gets an explicit JSON output schema. Every workflow gets a numbered identifier (WF-1 through WF-N) with an ASCII flowchart. Reliability scoring uses explicit formulas with named coefficients. Risk tables always include mitigation strategies. Implementation plans use checkbox lists with budget calculations.

Encoding these as a reference file rather than inline in SKILL.md keeps the orchestrator lean while giving Claude access to the full style guide when generating any document.

---

## The three-stage workflow that drives the skill

Anthropic's `doc-coauthoring` skill — their official documentation generation skill — uses a three-stage process that maps well to this use case but needs adaptation for structured technical documentation:

**Stage 1: Project context gathering.** Before generating any document, Claude needs to understand the new project. The skill should prompt the user for: project name, business model, tech stack, target users, key constraints, existing code or prototypes, and deployment environment. This maps to the `doc-coauthoring` skill's "info dumping" phase where the user provides raw context. The skill should then ask **5-10 clarifying questions** focused on areas that determine document content — particularly context isolation zones, AI component responsibilities, and state machine transitions.

**Stage 2: Sequential document generation.** Following the dependency order from the manifest, Claude generates each document by: (1) reading the corresponding template from `templates/`, (2) reading the style conventions from `references/`, (3) checking previously generated documents for entities to cross-reference, (4) generating the document, and (5) validating cross-references resolve correctly. The user reviews each document before proceeding — the skill should explicitly pause for approval at natural checkpoints (after spec + architecture, after data model + database, after workflows + prompts).

**Stage 3: Cross-document review.** After all documents exist, Claude runs the review checklist from `references/review-checklist.md` across the full suite. This catches inconsistencies that emerge only when viewing documents together: a database field referenced in workflows but missing from the schema, a workflow that references an AI component not defined in prompts, or a contact field mentioned in profiling but absent from the database.

---

## Review checklists work best with severity tiers

The review capability should use a **three-tier severity system** (CRITICAL / MAJOR / MINOR) encoded in `references/review-checklist.md`. Research from multiple practitioner guides confirms that flat checklists produce information overload, while tiered checklists let Claude prioritize:

**CRITICAL items** (blocks further work): All 10 documents exist and are non-empty. No unresolved cross-references. Database schema tables match fields referenced in workflows. JSON output schemas in AI_PROMPTS match what workflows expect. Context zones in architecture match what each AI component actually receives.

**MAJOR items** (should fix before implementation): Each document follows its template structure with all required sections. Component names consistent across all documents. Scoring formulas in CONTACT_PROFILE match the fields available in DATABASE. MVP_PLAN phases align with the workflow dependency order. Anti-pattern sections present in documents that need them.

**MINOR items** (quality polish): Consistent heading hierarchy. ASCII diagrams present where data flow is described. Code examples are syntactically valid. Bilingual terms formatted consistently. Cross-reference format uses the standard pattern.

The skill should also support a **quick review mode** (structure only, ~2 minutes) and a **deep review mode** (content + cross-references + consistency, ~10 minutes) to match different user needs.

---

## What the user's documentation structure gets right — and what to add

Compared to documentation structures from major open-source AI agent projects (Agent Zero at 14.4k stars, MetaGPT at 50k+ stars, GitHub's Spec Kit), the user's 10-document structure is **more comprehensive than industry norm**. Most projects have 4-6 documents. The separation of AI prompts into their own file, explicit behavioral codex, and dedicated verification document are particularly strong.

However, research identifies three gaps worth encoding as optional documents in the skill. First, a **Decision Log** — the "past" pillar that tracks why specific design choices were made. This prevents re-litigating settled decisions and is especially valuable when Claude generates documentation for a project revision. Second, a **Context Isolation Map** — while the user's architecture document mentions 4 context zones, LangChain research shows that multi-component AI systems need an explicit matrix mapping each component to its allowed data access. Subagents with proper context isolation process **67% fewer tokens** than shared-context approaches. Third, an **Error/Failure Mode document** — what happens when Telegram API is down, when a message can't be parsed, when the profiler gives contradictory scores. For autonomous messaging agents, failure documentation is a safety requirement.

The skill should include templates for these three additional documents as optional items, bringing the total to 13 potential documents while keeping the core 10 as the standard suite.

---

## Practical design decisions for the SKILL.md

Several tactical decisions emerge from the research:

**Keep templates as separate files, not inline.** Anthropic's official guidance states: "Store the template as a reference file and instruct Claude to use it. Instead of describing the format in SKILL.md." With 10 templates at 50-100 lines each, inlining would blow past the 500-line limit immediately.

**Use imperative writing style in the skill.** Anthropic's skill development guide specifies: write "Read the manifest file" not "You should read the manifest file." This produces measurably better adherence.

**Include explicit TRIGGER and DO NOT TRIGGER in the description.** The `claude-api` skill demonstrates this pattern — it prevents false activation on generic "write docs" requests while ensuring activation on specific triggers like "create project documentation" or "review my docs for consistency."

**Set `context: fork` for review operations.** When reviewing existing documents, running in a forked context prevents the review findings from polluting the main conversation context — especially important when the review reads all 10 documents into context simultaneously.

**Don't try to encode everything the user knows.** Anthropic's core principle is "the context window is a public good." Claude already knows how to write technical documentation, create ASCII diagrams, and structure database schemas. The skill should encode only what's **project-specific**: the exact document types, their dependency order, the user's style conventions, cross-reference format, and quality criteria. Everything else is Claude's existing capability.

## Conclusion

The optimal SKILL.md for this use case is not a single massive file but a **~200-line orchestrator** backed by a dependency manifest, style conventions file, review checklist, and 10 template files using progressive disclosure. The orchestrator defines a three-stage workflow (context → generate → review) while templates encode the user's specific patterns — Ukrainian language conventions, ASCII diagrams, explicit JSON schemas, anti-pattern sections, and cross-reference format. The dependency manifest (`document-manifest.yaml`) is the critical innovation: it gives Claude a topological map of how documents relate, enabling correct generation order, change propagation analysis, and cross-document consistency validation. Templates should capture the skeleton and required sections of each document type, while leaving content generation to Claude's inherent capability — the skill adds structure and quality control, not verbosity.