# Structuring Python projects for Claude Code

**The single highest-leverage investment for AI-assisted Python development is not in the code itself — it's in the project metadata.** A well-crafted `CLAUDE.md` file, a clean `.claude/` configuration directory, and files kept under 500 lines will transform Claude Code from a generic assistant into a codebase-aware collaborator that understands your Telegram bot's architecture, follows your async patterns, and edits with precision. The practices below synthesize official Anthropic documentation, community research, and practitioner experience to give you a concrete blueprint for your TGLogistAgent project.

## CLAUDE.md is your most powerful lever

Claude Code reads `CLAUDE.md` at the start of every session and injects it directly into the system prompt. This file is the primary mechanism for giving Claude persistent project knowledge. The official documentation states that **files should target under 200 lines** — longer files consume context and reduce instruction adherence. Frontier LLMs can follow roughly **150–200 instructions consistently**, and Claude Code's own system prompt uses about 50 of that budget, leaving you approximately 100–150 custom instructions.

Claude Code walks up the directory tree from your working directory, loading every `CLAUDE.md` it finds. If you run it in `src/bot/handlers/`, it loads `src/bot/handlers/CLAUDE.md`, `src/bot/CLAUDE.md`, `src/CLAUDE.md`, and `./CLAUDE.md`. Subdirectory files load on-demand only when Claude works with files in those directories, making hierarchical `CLAUDE.md` files the key to scaling context in larger projects. After `/compact`, Claude re-reads all `CLAUDE.md` files fresh from disk — they fully survive compaction.

The most effective structure follows a **WHAT / WHY / HOW framework**. For your TGLogistAgent, a root `CLAUDE.md` might look like this:

```markdown
# TGLogistAgent
Autonomous Telegram logistics agent. Python 3.12, Telethon, aiosqlite, Claude API.

## Commands
uv run python src/main.py          # Start bot
uv run pytest tests/ -x            # Run tests (stop on first failure)
uv run mypy --strict src/          # Type check
uv run ruff check src/             # Lint

## Architecture
- src/bot/ — Telethon client, event handlers, message routing
- src/db/ — SQLite via aiosqlite, repository pattern, migrations
- src/api/ — Claude API client, external service integrations
- src/services/ — Business logic (routing, dispatch, tracking)
- src/models/ — Pydantic schemas and data models

## Conventions
- Async everywhere: async def for all I/O operations
- Type hints on ALL function signatures, mypy strict
- Google-style docstrings on all public functions
- Repository pattern: all DB access through src/db/repositories/
- Dependency injection via constructors
- Functions under 50 lines, files under 500 lines

## Never
- No raw SQL outside the repository layer
- No bare except clauses
- No blocking I/O in async handlers
- No global mutable state
- No type: ignore comments
```

Three priority tiers of `CLAUDE.md` exist: **`CLAUDE.local.md`** (personal, gitignored) overrides **`CLAUDE.md`** (project, committed), which overrides **`~/.claude/CLAUDE.md`** (global, all projects). The `@` import syntax lets you reference detailed docs without bloating the root file — `@docs/telethon-patterns.md` embeds that file's content at startup, while a plain markdown reference like "See docs/api-design.md" requires Claude to read it on-demand.

One widely recommended practice: **when Claude makes a mistake, tell it to update CLAUDE.md** so the error doesn't recur. Running `/init` generates a starter `CLAUDE.md` by analyzing your codebase, but practitioners unanimously advise hand-crafting this file rather than relying on auto-generation, since it is the highest-leverage configuration point.

## The .claude/ directory controls permissions, rules, and skills

The `.claude/` directory is Claude Code's project-level configuration hub. Here is the complete structure relevant to your project:

```
.claude/
├── settings.json              # Permissions and hooks (committed)
├── settings.local.json        # Personal overrides (auto-gitignored)
├── rules/                     # Modular instruction files
│   ├── code-style.md          # Loaded every session
│   ├── async-patterns.md      # Loaded every session
│   └── telegram-handlers.md   # Can be path-scoped
├── skills/                    # Auto-invoked workflows
│   └── project-navigator/
│       └── SKILL.md
├── commands/                  # Custom slash commands
│   └── deploy.md
└── agents/                    # Specialized subagent personas
    └── code-reviewer.md
```

The `settings.json` file controls tool permissions through `allow`, `deny`, and `ask` arrays. For a Python project, a practical configuration permits standard development tools while blocking dangerous operations:

```json
{
  "permissions": {
    "allow": [
      "Read", "Write", "Edit", "Glob", "Grep",
      "Bash(uv *)", "Bash(python -m pytest *)",
      "Bash(ruff *)", "Bash(mypy *)",
      "Bash(git status)", "Bash(git diff *)"
    ],
    "deny": [
      "Read(.env)", "Read(.env.*)",
      "Bash(rm -rf *)", "Bash(pip install *)"
    ]
  }
}
```

**Hooks** are particularly powerful for Python. A `PostToolUse` hook can auto-format every file Claude writes:

```json
{
  "hooks": {
    "PostToolUse": [{
      "matcher": "Write(*.py)|Edit(*.py)",
      "hooks": [{
        "type": "command",
        "command": "ruff format $CLAUDE_FILE_PATH && ruff check --fix $CLAUDE_FILE_PATH"
      }]
    }]
  }
}
```

The **`.claude/rules/`** directory solves the 200-line limit. When your root `CLAUDE.md` grows too large, split instructions into focused rule files. Rules without YAML `paths:` frontmatter load unconditionally every session. Path-scoped rules load only when Claude works with matching files:

```markdown
---
paths:
  - "src/bot/handlers/**/*.py"
---
# Telegram Handler Rules
- All handlers: parse input → call service → format response
- Never access database directly from handlers
- Use event.respond() for replies, not client.send_message()
```

## Skills give Claude reusable, auto-invoked workflows

The Claude Code skills system uses `SKILL.md` files with YAML frontmatter. Each skill lives in its own directory under `.claude/skills/`. At startup, Claude loads only the **name and description** (~100 tokens per skill) from all available skills. The full `SKILL.md` body loads on-demand when Claude determines relevance — a progressive disclosure architecture that keeps context lean.

A skill that serves as a **project navigator** is one of the most valuable patterns for a codebase like TGLogistAgent. Set `user-invocable: false` so Claude automatically loads it when navigating the codebase:

```markdown
---
name: project-navigator
description: Navigate and understand TGLogistAgent project structure. Provides 
  file locations, module purposes, and data flow. Use whenever exploring the 
  codebase, finding specific functionality, or when the user asks where something 
  is located or how components connect.
user-invocable: false
---

# TGLogistAgent Architecture Map

## Data flow
Telegram event → src/bot/handlers/ → src/services/ → src/db/repositories/ → SQLite

## Core directories
- `src/bot/client.py` — TelegramClient setup and lifecycle management
- `src/bot/handlers/` — Event handlers grouped by feature domain
- `src/services/dispatch_service.py` — Core logistics dispatch logic
- `src/services/tracking_service.py` — Shipment tracking and status updates
- `src/db/repositories/base.py` — BaseRepository with async CRUD operations
- `src/db/repositories/order_repo.py` — Order-specific database queries
- `src/api/claude_client.py` — Claude API integration for autonomous decisions
- `src/models/` — Pydantic schemas shared across all layers
- `src/config.py` — All configuration, environment variables, constants

## Common tasks reference
| Task | Where to look |
|------|---------------|
| Add Telegram command | src/bot/handlers/ + register in src/bot/client.py |
| Add database table | src/db/models.py + src/db/migrations/ + new repository |
| Add external API | Inherit from src/api/base_client.py |
| Add business logic | New service in src/services/ |
| Modify Claude prompts | src/api/claude_client.py |
```

Official best practices for SKILL.md authoring emphasize **making descriptions "pushy"** — Claude tends to under-trigger skills, so descriptions should explicitly list trigger scenarios. Keep SKILL.md **under 500 lines** and move detailed reference material to `references/` subdirectories. The skill directory can also contain templates, scripts, and example files that Claude loads only when needed.

Community tools like **Cartographer** (spawns parallel subagents to generate a `CODEBASE_MAP.md`) and **Codebase Explorer** (pure-markdown four-phase analysis) can auto-generate project maps, but for a focused project like TGLogistAgent, a hand-crafted navigator skill will be more accurate and token-efficient.

## File size and function length determine AI editing quality

Research consistently shows that **150–500 lines of code per file** is the sweet spot for AI editing accuracy. Within this range, Claude can hold the entire file context in working memory, produce accurate diffs, and avoid modifying the wrong function or creating duplicates. Functions should stay **under 50 lines**, and classes **under 200 lines**. These thresholds aren't arbitrary — they reflect the point at which LLM editing reliability drops measurably.

You can enforce this programmatically with a pytest test:

```python
# tests/test_file_size.py
from pathlib import Path

def test_python_files_under_500_lines():
    """Enforce AI-friendly file sizes."""
    violations = []
    for path in Path("src").rglob("*.py"):
        lines = len(path.read_text().splitlines())
        if lines > 500:
            violations.append(f"{path}: {lines} lines")
    assert not violations, f"Files exceeding 500 lines:\n" + "\n".join(violations)
```

When approaching 500 lines, look for natural split points: extract a class into its own module, break a service into focused sub-services, or separate utility functions. For your TGLogistAgent, this means each Telegram handler file covers one feature domain, each repository covers one entity, and each service encapsulates one business capability.

The monorepo approach — keeping all project components in one workspace — is strongly recommended because Claude Code works with what it can see in the working directory. If your bot's API client lives in a separate repository, Claude has no context about it. Everything in one root directory with hierarchical `CLAUDE.md` files gives Claude full cross-component visibility while keeping context loading efficient.

## Writing code that LLMs can reliably understand and modify

**Type hints are non-negotiable for AI-assisted development.** Running `mypy --strict` creates an automatic feedback loop — Claude iterates until code passes type checking, catching mistakes that would otherwise reach production. The most impactful pattern is using **Pydantic models instead of raw dictionaries**, because `dict` gives the AI infinite assumptions about structure while a Pydantic model gives exactly one interpretation:

```python
# This tells Claude nothing about the data shape
async def process_order(data: dict) -> dict: ...

# This tells Claude everything
class OrderRequest(BaseModel):
    user_id: int
    destination: str
    items: list[OrderItem]
    priority: Literal["standard", "express", "urgent"]

async def process_order(data: OrderRequest) -> OrderResponse: ...
```

**Dependency injection via constructors** makes code both testable and AI-readable. When Claude sees a service's constructor, it immediately understands all dependencies:

```python
class DispatchService:
    """Handles logistics dispatch decisions and routing."""
    
    def __init__(
        self,
        order_repo: OrderRepository,
        claude_client: ClaudeAPIClient,
        telegram_client: TelegramClient,
    ) -> None:
        self._orders = order_repo
        self._claude = claude_client
        self._telegram = telegram_client
```

**Google-style docstrings** serve a dual audience. Module-level docstrings help Claude understand file purpose during navigation. Function docstrings should document constraints, valid ranges, and exceptions — the "why" information that code alone doesn't convey. Comments that explain workarounds or intentional deviations prevent Claude from "fixing" things that aren't broken:

```python
# WORKAROUND: Telethon raises ValueError for deleted accounts in get_entity().
# We catch and skip rather than crash the entire handler loop.
```

**Feature-based code organization** (grouping by domain rather than by type) keeps related code co-located so Claude needs fewer files in context for any given change. For TGLogistAgent, this means `src/bot/handlers/dispatch_commands.py` lives near `src/services/dispatch_service.py` and `src/db/repositories/order_repo.py` — all the files Claude needs to implement a dispatch feature are conceptually adjacent.

## Recommended project structure for TGLogistAgent

Synthesizing all the research, here is the complete recommended structure:

```
TGLogistAgent/
├── CLAUDE.md                          # Root project context (<200 lines)
├── CLAUDE.local.md                    # Personal overrides (gitignored)
├── pyproject.toml                     # Dependencies managed by uv
├── .claude/
│   ├── settings.json                  # Permissions and hooks
│   ├── rules/
│   │   ├── async-patterns.md          # Async coding rules
│   │   └── telegram-handlers.md       # Path-scoped to src/bot/
│   └── skills/
│       └── project-navigator/
│           └── SKILL.md               # Codebase map skill
├── src/
│   ├── __init__.py
│   ├── main.py                        # Entry point, async event loop
│   ├── config.py                      # All config, env vars, constants
│   ├── bot/
│   │   ├── CLAUDE.md                  # Telethon-specific conventions
│   │   ├── client.py                  # TelegramClient setup
│   │   ├── middleware.py              # Rate limiting, auth checks
│   │   └── handlers/
│   │       ├── user_commands.py       # /start, /help, /status
│   │       ├── dispatch_commands.py   # /dispatch, /track, /cancel
│   │       └── admin_commands.py      # /stats, /config
│   ├── db/
│   │   ├── CLAUDE.md                  # Database conventions
│   │   ├── connection.py              # aiosqlite connection management
│   │   ├── models.py                  # Table definitions
│   │   ├── migrations/                # Schema migration scripts
│   │   └── repositories/
│   │       ├── base.py                # BaseRepository with async CRUD
│   │       ├── order_repo.py
│   │       └── user_repo.py
│   ├── api/
│   │   ├── base_client.py             # Base HTTP client with retry logic
│   │   └── claude_client.py           # Claude API integration
│   ├── services/
│   │   ├── base.py                    # BaseService pattern
│   │   ├── dispatch_service.py        # Core logistics logic
│   │   └── tracking_service.py        # Status tracking
│   └── models/
│       ├── order.py                   # Pydantic order schemas
│       └── user.py                    # Pydantic user schemas
├── tests/
│   ├── conftest.py                    # Shared fixtures
│   ├── test_services/
│   ├── test_repositories/
│   └── test_file_size.py              # Enforce 500-line limit
└── docs/
    ├── architecture.md                # Referenced via @docs/architecture.md
    └── telethon-patterns.md
```

## Conclusion

The practices that matter most for Claude Code are structural, not stylistic. **Three investments deliver outsized returns**: a hand-crafted `CLAUDE.md` under 200 lines with your project map, commands, and conventions; a `.claude/settings.json` with permissions and auto-formatting hooks; and a codebase where every file stays under 500 lines with typed function signatures throughout.

The skills system's progressive disclosure architecture — loading only metadata at startup and full content on demand — means you can create rich project navigation skills without bloating every session's context. A `project-navigator` skill with `user-invocable: false` gives Claude always-available architectural knowledge at minimal token cost.

For TGLogistAgent specifically, the async-everywhere stack (Telethon + aiosqlite + httpx) pairs naturally with the repository pattern and constructor-based dependency injection. These patterns are both AI-friendly and production-sound. The key discipline is maintaining the layered architecture (`handlers → services → repositories → database`) and enforcing it through your `CLAUDE.md` conventions and path-scoped rules, so Claude never introduces shortcuts that violate your data flow boundaries.