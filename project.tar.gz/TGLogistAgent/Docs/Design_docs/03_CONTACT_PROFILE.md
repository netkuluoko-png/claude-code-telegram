# Система профілювання контактів

## 1. Структура профілю

Кожен контакт в системі має багаторівневий профіль який накопичується автоматично з кожною взаємодією.

### Базові дані (contact_base)

```
contact_id          UUID
tg_id               Telegram user ID
tg_username         @username (може бути NULL)
first_name          Ім'я з Telegram
last_name           Прізвище
phones              Array<string> — всі відомі номери
type                customer | carrier | both | unknown
active_routes       Array<string> — нормалізовані маршрути
poland_related      bool — працює з Польщею
first_seen          Timestamp першого повідомлення
last_seen           Timestamp останнього повідомлення
total_messages      Кількість повідомлень
source_groups       Array<string> — в яких групах зустрічався
```

### Психологічний профіль (contact_psychology)

Накопичується агентом з кожної взаємодії. Оновлюється Profiler-компонентом на вимогу — коли Responder визначає що накопичено достатньо нової інформації для оновлення профілю. Profiler отримує тільки ще не оброблені ним повідомлення (програма відстежує які повідомлення вже аналізувались). Профіль НЕ модифікується під час активної відповіді контакту — тільки окремим асинхронним викликом.

```
communication_style     formal | informal | blunt | mixed
language                uk | ru | mixed
response_speed          fast (<30 хв) | normal (<2 год) | slow (>2 год)
bargaining_behavior     flexible | firm | aggressive
preferred_contact_time  Час коли зазвичай активний
typical_message_length  short | medium | long
emoji_usage             none | rare | frequent
trust_level             new | developing | established | trusted
```

**best_response_pattern** — текстовий опис як найкраще взаємодіяти з цим контактом:
```
Приклад: "Відповідає тільки на конкретні пропозиції з ціною. 
Не любить коли питають 'вільні?'. Краще одразу давати маршрут+ціну. 
Торгується завжди, початкова ціна зазвичай на 10-15% нижче фінальної."
```

**ОБМЕЖЕННЯ:** best_response_pattern НІКОЛИ не суперечить правилам AGENT_CODEX. Якщо контакт "любить довгі пояснення" — агент все одно відповідає коротко, бо це правило системи.

### Цінова розвідка (contact_price_intel)

```
price_history       Array<PriceRecord>
avg_price_tendency  below_market | at_market | above_market
price_flexibility   rigid | negotiable | very_flexible
```

**PriceRecord:**
```
record_id           UUID
route               from_city → to_city
container_type      20' / 40' / etc.
price               Number
currency            UAH | EUR | USD
date                Дата
source              message | deal | voice_note
market_avg_at_date  Середня ринкова ціна на цю дату (якщо відома)
deviation_pct       % відхилення від середньої
```

Логіка тенденції:
- Агент збирає ціни з повідомлень контакту по кожному маршруту
- Порівнює з середньою по ринку (зі всіх повідомлень по цьому маршруту за тиждень)
- Записує характеристику: "у цього замовника ціна зазвичай на 8% нижче ринку"
- Ця характеристика впливає на рішення чи писати цьому замовнику

**Правило активації:** якщо contact.avg_price_tendency == below_market І відхилення > 15%, агент НЕ ініціює контакт з цим замовником при активному пошуку. Тільки якщо замовник сам написав.

### Надійність (contact_reliability)

```
deals_total             Загальна кількість угод
deals_completed         Завершені успішно
deals_cancelled         Скасовані
cancellation_rate       deals_cancelled / deals_total (%)
who_cancelled           Array — хто ініціював скасування (ми / вони)

payment_punctuality     on_time | slight_delay | problematic
avg_payment_delay_days  Середня затримка оплати (якщо є)

communication_culture   1-5 (наскільки коректно спілкується)
disputes_count          Кількість конфліктів
last_dispute_date       Коли був останній
dispute_descriptions    Array<string> — короткий опис кожного конфлікту

overall_reliability     0-100 (авторозрахунок)
manual_notes            Ручні примітки оператора
```

**Формула overall_reliability:**
```
base = 50
+ (deals_completed * 5)                    // до +50 за успішні угоди
- (deals_cancelled * 15)                   // -15 за кожне скасування  
- (avg_payment_delay_days * 2)             // -2 за кожен день затримки
+ (communication_culture - 3) * 5          // ±10 за культуру
- (disputes_count * 10)                    // -10 за кожен конфлікт
= clamp(0, 100)
```

### Історія угод (contact_deals)

```
active_deals        Array<DealSummary> — поточні угоди з цим контактом
deal_archive        Array<DealSummary> — завершені угоди

DealSummary:
  deal_id           UUID
  role              customer | carrier (роль ЦЬОГО контакту в угоді)
  route             from → to
  price             Ціна
  status            Стан
  date              Дата
  margin            Маржа (видно тільки агенту, не контакту)
```

## 2. Оновлення профілю — коли і як

### Автоматично (з кожного повідомлення):
- last_seen, total_messages
- source_groups (якщо нова група)
- active_routes (якщо новий маршрут)
- price_history (якщо в повідомленні є ціна)
- language (визначається автоматично)

### Через Profiler (on-demand, коли Responder вирішить):
- communication_style, response_speed, bargaining_behavior
- best_response_pattern
- trust_level (підвищується з кожною успішною угодою)
- Profiler отримує тільки повідомлення які ще не були ним оброблені

### Через Deal Manager (після угоди):
- deals_total, deals_completed, deals_cancelled
- payment_punctuality
- overall_reliability (перерахунок)
- dispute_descriptions (якщо був конфлікт)

### Вручну (оператор):
- manual_notes
- communication_culture (оцінка)
- Перевизначення будь-якого поля

## 3. Контекстний зріз для AI (Context Slice)

Коли агент отримує повідомлення від контакту, він отримує НЕ повний профіль, а зріз:

```json
{
  "contact": {
    "name": "Василь",
    "type": "carrier",
    "reliability": 78,
    "style": "informal, blunt",
    "language": "ru",
    "best_pattern": "Коротко, з ціною одразу. Торгується завжди.",
    "price_tendency": "at_market",
    "active_routes": ["Гданськ→Київ", "Гданськ→Одеса"]
  },
  "active_deals": [
    {"deal_id": "...", "route": "Гданськ→Київ", "status": "in_transit", "date": "2026-03-25"}
  ],
  "recent_messages": [
    {"from": "contact", "text": "Коли оплата?", "date": "2026-03-26 14:30"},
    {"from": "agent", "text": "Сьогодні до кінця дня.", "date": "2026-03-26 14:31"}
  ]
}
```

Змінні контекстного зрізу описані в variable-registry.md (секція "Для головного промпту Responder").

## 4. Верифікація та дублікати

### Проблема дублікатів
Один контакт може мати кілька Telegram-акаунтів. В системі `tg_id` — унікальний ідентифікатор, тому другий акаунт = окремий контакт без історії.

### Поточний підхід (MVP)
- Дублікати не мерджаться автоматично
- Якщо контакт заявляє "це мій другий акаунт" → ескалація оператору
- Агент НЕ розкриває інформацію про угоди неверифікованим контактам

### Верифікація водіїв
- Перевізник надає дані водія (ім'я, телефон) на етапі `agreed`
- Водій верифікується по номеру телефону
- Верифікований водій бачить: маршрут, дату, адресу завантаження
- Водій НЕ бачить: ціну, умови оплати, замовника

Детальніше: див. 10_CONTACT_VERIFICATION.md

## 5. Безпека профілів

- Агент НІКОЛИ не повідомляє контакту його рейтинг чи оцінку
- Агент НІКОЛИ не повідомляє одному контакту інформацію з профілю іншого
- Агент НІКОЛИ не повідомляє ціну однієї сторони іншій (маржа — секрет)
- При запиті "з ким ще працюєте?" — агент відповідає ухильно: "Працюємо з перевізниками по цьому напрямку"
- Сервер приватний, доступ має тільки оператор (адмін). Захист на рівні серверу: ізольований сервер без публічного доступу, авторизація тільки для адміна, вся взаємодія — через програмний код та Telegram-повідомлення. БД захищена від стороннього доступу на рівні ОС та мережі

### Заборонено

- ❌ Повідомляти контакту його рейтинг (reliability) або оцінку
- ❌ Повідомляти одному контакту інформацію з профілю іншого
- ❌ Повідомляти ціну однієї сторони іншій (маржа — секрет)
- ❌ Розкривати базу контактів або кількість перевізників/замовників
- ❌ Модифікувати профіль під час активної розмови (тільки постфактум через Profiler)

Таблиці БД профілю: див. 05_DATABASE.md (contacts, contact_psychology, contact_reliability, price_records)
Промпт Profiler: див. 08_AI_PROMPTS.md, секція 4
