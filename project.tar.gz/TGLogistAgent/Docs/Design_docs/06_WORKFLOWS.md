# Робочі процеси (Workflows)

Кожен workflow має: тригер, ASCII-діаграму, точки виклику AI (з посиланням на промпт) та записи в БД.
Промпти описані в 08_AI_PROMPTS.md. Змінні — в variable-registry.md.

---

## WF-1: Обробка нового повідомлення з групи

**Тригер:** нове повідомлення в моніторену Telegram-групу (через userbot/Telethon)

```
Telegram група → нове повідомлення
        │
        ▼
    [Parser]
    1. Отримує текст + metadata (sender tg_id, group, msg_id)
    2. Перевіряє: чи є sender в contacts?
       → Ні: створити контакт (type=unknown)
       → Так: оновити last_seen, total_messages
        │
        ▼
    3. AI-виклик:
       → Промпт: Parser (побічний)
       → Вхід: raw_text, sender_tg_id, source_group, current_date
       → Вихід: {match, type, reason, details}
       → Детальніше: див. 08_AI_PROMPTS.md, секція 2
        │
        ▼
    4. → БД: messages (text, contact_id, source, ai_analysis)
        │
        ├── match = false → END (тільки запис в БД)
        │
        ▼
    5. match = true
       → БД: cargo_offers (direction_from/to, container_type, price, status='open')
        │
        ▼
    6. Оновлення контакту:
       → БД: contact_routes (from_city, to_city, frequency++) — якщо новий маршрут
       → БД: contact_phones (phone) — якщо є і новий
       → БД: contacts (type = customer/carrier) — якщо можна визначити
       → БД: price_records (price, currency, route) — якщо є ціна
        │
        ▼
    7. Тригерить WF-2 (Matcher)
```

### Заборонено

- ❌ Відповідати контакту в групі (парсер тільки спостерігає)
- ❌ Створювати cargo_offer якщо match=false

---

## WF-2: Матчинг та рішення про активацію

**Тригер:** новий cargo_offer (type=cargo) створений в WF-1

```
    Новий cargo_offer (type=cargo)
        │
        ▼
    [Matcher — AI-based]
    1. Збирає контекст:
       - cargo_offer деталі
       - market_prices по цьому маршруту (якщо є)
       - Список перевізників з contact_routes
         де from_city = cargo.direction_from
         + reliability > min_reliability_for_active
         + last_seen < 7 днів
        │
        ▼
    2. AI-виклик:
       → Промпт: Matcher (побічний)
       → Вхід: cargo.*, market_avg_price, candidate_carriers[], margin_threshold, usd_rate, eur_rate
       → Вихід: {action, reason, estimated_margin, candidates[]}
       → Детальніше: див. 08_AI_PROMPTS.md, секція 3
        │
        ▼
    3. Обробка рішення:
       ├── action = "skip" → END
       ├── action = "passive" → нотифікація оператору (WF-5): "Новий вантаж, маржа мала"
       │
       ▼
    4. action = "active"
       → БД: deals (status='prospecting', cargo_offer_id, customer_contact_id)
       → БД: deal_events (event_type='status_change', new_value='prospecting')
       → WF-3 (включає перевірку актуальності вантажу)
```

**Для type=transport (вільне авто):**

```
    Новий cargo_offer (type=transport, вільне авто)
        │
        ▼
    Matcher перевіряє чи є відкриті cargo_offers (type=cargo)
    з підходящим маршрутом.
    ├── Є і маржа ОК → створює deal (status=prospecting) → WF-4
    └── Немає → записує в базу як потенційного перевізника.
        НЕ шукає вантаж активно (cargo-first принцип).
```

### Заборонено

- ❌ Тригерити активний пошук для type=transport (cargo-first принцип)
- ❌ Створювати deal якщо action ≠ "active"

---

## WF-3: Активний пошук перевізника

**Тригер:** Matcher вирішив action="active" (WF-2, крок 4)

**Передумова:** Перед початком активного пошуку перевізника, агент повинен уточнити актуальність вантажу у замовника.

```
    Matcher вирішив: action = "active"
        │
        ▼
    [Deal Manager]
    1. Deal вже створено в WF-2
       customer = sender cargo_offer
       carrier = NULL (ще не знайшов)
        │
        ▼
    2. Бере TOP candidates з Matcher (до max_carriers_to_contact, початково 3)
        │
        ▼
    Пропозиція надсилається кільком перевізникам одночасно.
    Обробка відповідей — ПОСЛІДОВНА (одна за одною).

    3. Для кожного кандидата з TOP:
       a. Перевіряє: чи немає активної угоди з цим перевізником?
          → Є: пропустити
       b. AI-виклик:
          → Промпт: Responder (головний)
          → Вхід: contact.*, active_deals, message_draft з Matcher
          → Вихід: response_text (коротка пропозиція)
          → Детальніше: див. 08_AI_PROMPTS.md, секція 1
       c. Відправляє response_text перевізнику через userbot (Telethon DM)
       d. → БД: messages (direction='out', deal_id, text=response_text)
    (Повідомлення надсилаються всім кандидатам без очікування між ними)
        │
        ▼
    4. Ставить таймер: wait_response = response_wait_hours (з agent_config, початково 2 год)
       Чекає відповіді від перевізників
        │
        ├── Відповідь отримана → обробка через WF-4
        │   ├── Перевізник підтвердив → фіксуємо угоду
        │   │   → Іншим кандидатам (якщо ще не відповіли або теж підтвердили): "вже не актуально"
        │   │   → Якщо 2+ підтвердили одночасно → обираємо кращого по reliability
        │   └── Перевізник відмовив → чекаємо далі на інших
        │
        ▼
    5. Таймер спрацював, жоден не підтвердив:
       a. Розширити пошук до TOP-5 → повторити крок 3 для нових кандидатів
       b. Якщо і розширений пошук не дав результату І агент не впевнений в ціні
          → публікує оголошення в Telegram-канал перевізників (WF-9) як fallback
       c. Якщо і канал не дав результату → ескалація оператору (WF-6)
```

### Заборонено

- ❌ Обробляти дві позитивні відповіді паралельно (послідовна обробка, обирати кращого по reliability)
- ❌ Продовжувати переговори після фіксації угоди з одним перевізником (іншим: "вже не актуально")
- ❌ Писати перевізникам з reliability < `min_reliability_for_active`
- ❌ Писати особистим контактам оператора (тільки логістичним з бази)

---

## WF-3.5: Перевірка актуальності вантажу та підготовка до угоди

**Тригер:** перевізник підтвердив готовність (WF-3 → WF-4), угода переходить з prospecting → negotiating

```
    Перевізник підтвердив: готовий їхати
        │
        ▼
    [Deal Manager]
    1. Агент пише замовнику через userbot DM:
       "Маю авто на [маршрут], [дата]. Актуально?"
        │
        ▼
    2. Замовник відповідає:
       ├── "Так, актуально" → крок 3
       │
       ├── "Вже не актуально" →
       │     a. → БД: cargo_offers (status='archived')
       │     b. Повідомити перевізнику: "Вже не актуально"
       │     c. Запропонувати перевізнику інший відкритий вантаж по маршруту (якщо є)
       │     d. → БД: deals (status='cancelled', notes='cargo not actual')
       │     → END
       │
       └── Не відповідає → чекаємо, потім ескалація оператору (WF-6)
        │
        ▼
    3. Вантаж актуальний → переходимо до етапу підготовки документів (WF-7.5)
       → БД: deals (status='agreed')
       → БД: deal_events (event_type='status_change', new_value='agreed')
```

---

## WF-4: Обробка вхідного DM від контакту

**Тригер:** контакт пише в DM через userbot (Telethon)

```
    Контакт пише в DM (через userbot/Telethon)
        │
        ▼
    [Router]
    1. Визначає контакт по tg_id → contact_id
       → Не знайдено: створити контакт + запитати хто він
        │
        ▼
    2. Збирає контекст:
       - contact_profile (зріз зони 3). Детальніше: див. 03_CONTACT_PROFILE.md
       - active_deals з цим контактом (зона 2)
       - recent_messages з цим контактом (останні N)
        │
        ▼
    3. AI-виклик:
       → Промпт: Responder (головний)
       → Вхід: contact.*, active_deals[], recent_messages[], new_message
       → Вихід: {context_type, deal_id, response_text, actions[], confidence}
       → Детальніше: див. 08_AI_PROMPTS.md, секція 1
        │
        ▼
    4. Перевірка confidence:
       ├── confidence < 0.7 → ескалація оператору (WF-6)
       │
       ▼
    5. Виконує actions:
       - update_deal_status → БД: deals (status) + deal_events
       - update_price → БД: price_records (price, currency, route)
       - escalate → WF-6
       - notify_operator → WF-5
       - forward_to_other_party → WF-7
       - send_to_carrier_channel → WF-9
       - create_contact → БД: contacts
       - create_deal → БД: deals + deal_events
       - ask_clarification → нічого (чекає відповідь)
       - none → нічого
        │
        ▼
    6. Відправляє response_text контакту через userbot (Telethon DM)
    7. → БД: messages (direction='in', text=new_message)
       → БД: messages (direction='out', text=response_text, deal_id)
        │
        ▼
    9. Перевірка: чи Responder включив action "update_profile"?
       ├── Ні → END (профіль не оновлюється)
       │
       ▼
       Так → AI-виклик (on-demand Profiler):
       → Промпт: Profiler (побічний)
       → Вхід: current_profile, unprocessed_messages (тільки повідомлення які ще не аналізувались Profiler-ом), deal_result
       → Вихід: {psychology_updates, price_updates, reliability_updates}
       → Детальніше: див. 08_AI_PROMPTS.md, секція 4
       → БД: contact_psychology, price_records, contact_reliability (що змінилось)
       → Позначити оброблені повідомлення як проаналізовані Profiler-ом
```

### Заборонено

- ❌ Відповідати на повідомлення від невідомих контактів НЕ з логістичних груп/бази
- ❌ Відправляти відповідь якщо confidence < 0.7 (тільки ескалація)

---

## WF-5: Нотифікація оператора

**Тригер:** подія яка потребує повідомлення оператору

```
    Подія яка потребує повідомлення
        │
        ▼
    [Notifier → приватний Telegram-бот, whitelist]
    Типи нотифікацій:

    📦 НОВИЙ МАТЧ (пріоритет: високий)
    "Гданськ→Київ, 40'HC, 22т, 30.03
    Замовник: Олег (+380630640089), reliability: 85
    Очікувана маржа: ~300€
    Агент шукає перевізника."

    ✅ УГОДА ПІДТВЕРДЖЕНА (пріоритет: середній)
    "#D-042: Гданськ→Київ, 30.03
    Замовник: Олег, 1800€
    Перевізник: Василь, 1500€
    Маржа: 300€
    Заявки сформовані."

    ⚠️ ЕСКАЛАЦІЯ (пріоритет: критичний)
    → Повний контекст ситуації. Детальніше: див. 04_AGENT_CODEX.md

    📊 ЩОДЕННИЙ ДАЙДЖЕСТ (вечір)
    "Сьогодні:
    - Нових вантажів: 12, з них маржинальних: 3
    - Угод відкрито: 2, завершено: 1
    - Маржа за день: ~450€
    - Потребує уваги: 1 ескалація"
```

---

## WF-6: Ескалація

**Тригер:** confidence < 0.7 (WF-4), автоматична ескалація (04_AGENT_CODEX.md), ручний запит

```
    Тригер ескалації (WF-4 або автоматично)
        │
        ▼
    [Deal Manager]
    1. → БД: deals (escalated=1, escalation_reason)
    2. → БД: deal_events (event_type='escalation', note=reason)
    3. Формує повідомлення для оператора (повний контекст)
    4. Відправляє через Notifier (WF-5)
        │
        ▼
    5. Агент ЗУПИНЯЄ автономну комунікацію по цій угоді
       Якщо контакт пише → "Очікуйте, уточнюю."
        │
        ▼
    6. Оператор відповідає через бот:
       /resolve D-042 "Підтвердити зміну дати на 02.04"
       або
       /resolve D-042 "Відмовити, шукаємо іншого"
        │
        ▼
    7. Агент продовжує роботу за вказівкою оператора
       → БД: deals (escalated=0)
       → БД: deal_events (event_type='status_change', note='resolved by operator')
```

---

## WF-7: Передача документів

**Тригер:** контакт відправив файл/фото через userbot DM

```
    Контакт відправив файл/фото
        │
        ▼
    [Router]
    1. Визначає контакт та угоду
    2. → БД: deal_documents (deal_id, doc_type, file_path, uploaded_by)
        │
        ▼
    3. Визначає тип документу (AI або по розширенню)
    4. Визначає одержувача:
       - Якщо відправив перевізник → переслати замовнику
       - Якщо відправив замовник → переслати перевізнику
       - Не впевнений хто одержувач → ескалація (WF-6)
        │
        ▼
    5. Пересилає файл одержувачу через userbot (Telethon DM)
    6. → БД: deal_documents (forwarded_to = contact_id одержувача)
    7. Повідомляє відправника: "Передав."
       → БД: messages (direction='out', text="Передав.")
```

---

## WF-8: Автоочищення (Cron)

**Тригер:** системний cron-розклад

```
    Щогодини:
    1. cargo_offers WHERE status='open' AND expires_at < now()
       → БД: cargo_offers (status='expired')

    2. cargo_offers WHERE status='open' AND departure_date < today()
       → БД: cargo_offers (status='expired')

    Щодня:
    3. Перерахунок → БД: market_prices (агрегація price_records за тиждень)
    4. Перерахунок → БД: contact_reliability (overall_reliability для контактів з новими угодами)
    5. Формування щоденного дайджесту → WF-5
    6. Оновлення → БД: exchange_rates (курси НБУ з api.bank.gov.ua)
    7. Бекап SQLite (кожні 6 годин). Детальніше: див. 09_OPERATIONS.md

    Щодня (нічний час):
    8. Архівування expired cargo_offers старших за 30 днів → DELETE
    9. Архівування completed/cancelled deals > 90 днів → БД: deals_archive
    10. Архівування messages > 90 днів для завершених угод → БД: messages_archive
```

---

## WF-9: Публікація в Telegram-канал перевізників

**Тригер:** агент не впевнений в ціні / немає відповідей від перевізників (WF-3, крок 5b)

```
    Тригер: fallback з WF-3
        │
        ▼
    [Agent]
    1. Формує публікацію (коротко: маршрут, тип контейнера, дата, без ціни)
       Приклад: "Гданськ→Київ, 40'HC, 22т, 30.03. Хто вільний?"
    2. Публікує в Telegram-канал через userbot (carrier_channel_id з agent_config)
    3. Моніторить відповіді в каналі
    4. Якщо є відгук → переходить в DM з перевізником → WF-4
```

### Заборонено

- ❌ Публікувати ціну замовника в каналі (тільки маршрут, тип, дата)
- ❌ Публікувати частіше ніж раз на годину той самий вантаж

---

## WF-10: Обробка черги необроблених повідомлень

**Тригер:** система відновилась після збою / Claude API повернувся

```
    Тригер: recovery
        │
        ▼
    1. Вибрати всі unprocessed_messages WHERE processed = 0
       ORDER BY received_at ASC
        │
        ▼
    2. Для кожного повідомлення:
       a. Якщо received_at > 4 години тому → позначити stale, ескалація оператору (WF-6)
       b. Якщо received_at <= 4 години → обробити стандартно (WF-4)
        │
        ▼
    3. → БД: unprocessed_messages (processed=1, processed_at=now())
    4. Нотифікація оператору (WF-5): "Оброблено N повідомлень з черги"
```

Детальніше: див. 09_OPERATIONS.md

---

## WF-11: Верифікація водія / дублікату акаунту

**Тригер:** перевізник надає дані водія (після статусу agreed), або невідомий акаунт стверджує що він існуючий контакт

```
    Тригер: нові дані водія АБО claim "це мій другий акаунт"
        │
        ├── Дані водія від перевізника:
        │     → БД: driver_contacts (deal_id, carrier_contact_id, driver_name, driver_phone)
        │
        ├── Невідомий контакт пише з номером який може бути в driver_contacts:
        │
        ▼
    2. AI-виклик:
       → Промпт: Verification Agent (побічний)
       → Вхід: claimer_tg_id, claimed_contact_name, claimed_contact_id,
               active_deals_with_claimed, driver_contacts_match, shared_groups
       → Вихід: {verdict, confidence, reason, evidence, recommended_action}
       → Детальніше: див. 08_AI_PROMPTS.md, секція 5
        │
        ▼
    3. Обробка вердикту:
       ├── verified_driver
       │   → БД: driver_contacts (verified=1)
       │   → Responder надає обмежену інформацію: маршрут, дата, адреса
       │   → БЕЗ ціни, замовника, маржі
       │
       ├── suspicious
       │   → Ескалація оператору (WF-6) з повним контекстом
       │   → Responder: "Для безпеки зв'яжіться з основного акаунту"
       │
       └── unverified
           → Responder: "Для безпеки зв'яжіться з основного акаунту або зателефонуйте"
           → Жодної інформації про угоди
```

Детальніше: див. 10_CONTACT_VERIFICATION.md

---

## WF-12: Пошук контакту за дзвінком (Contact Lookup)

**Тригер:** оператор надсилає команду `/who` в приватний адмін-бот

**Мета:** Ввести оператора в актуальний контекст з контактом перед тим як передзвонити або відповісти голосом.

**Сценарій використання:**
Оператору надходить дзвінок (телефон або Telegram). Оператор не бере трубку від невідомих номерів. Замість цього — заходить в адмін-бот, вводить номер / username / пересилає пропущений Telegram-дзвінок. Бот шукає контакт в базі, збирає контекст, викликає AI для формування брифінгу. Оператор отримує стислу довідку: хто це, що від нього хоче, які угоди активні, на якому етапі, що було останнім обговоренням.

```
    Оператор відправляє в адмін-бот одне з:
    - /who +380631234567        (номер телефону)
    - /who @username            (Telegram username)
    - /who 123456789            (Telegram user ID)
    - [пересилає пропущений Telegram-дзвінок]
        │
        ▼
    [Bot → Contact Resolver]
    1. Парсинг вхідних даних:
       ├── Телефон → SELECT contact_id FROM contact_phones WHERE phone LIKE '%...%'
       ├── @username → SELECT id FROM contacts WHERE tg_username = '...'
       ├── tg_id → SELECT id FROM contacts WHERE tg_id = ...
       └── Forwarded call → витягти tg_id з metadata переслання
        │
        ▼
    2. Контакт знайдено?
       ├── Ні → Відповідь: "❌ Контакт не знайдено в базі."
       │         Додатково: перевірити unprocessed_messages на збіг
       │         → END
       │
       ▼
    3. Збирання контексту:
       a. contact_profile:
          - contacts (ім'я, тип, tg_username, phones)
          - contact_psychology (стиль, мова, trust_level, best_response_pattern)
          - contact_reliability (reliability, deals_total, deals_completed, disputes)
          - contact_routes (активні маршрути)
       b. active_deals:
          - deals WHERE (customer_contact_id = ? OR carrier_contact_id = ?)
            AND status IN ('prospecting','negotiating','agreed','in_transit')
          - Для кожної угоди: останні 3 deal_events
       c. recent_messages:
          - messages WHERE contact_id = ? ORDER BY created_at DESC LIMIT 20
       d. our_open_cargos:
          - cargo_offers WHERE status = 'open'
            AND direction_from IN (маршрути контакту)
            (тільки якщо контакт — перевізник/both)
          - cargo_offers WHERE sender_contact_id = ?
            (тільки якщо контакт — замовник/both)
        │
        ▼
    4. AI-виклик:
       → Промпт: Contact Briefing (побічний)
       → Вхід: contact_profile, active_deals, deal_events,
               recent_messages, our_open_cargos
       → Вихід: {briefing_text, likely_intent, urgency, suggested_talking_points}
       → Детальніше: див. 08_AI_PROMPTS.md, секція 6
        │
        ▼
    5. Відправляє briefing_text оператору через адмін-бот
       → END
```

**Приклад відповіді бота:**

```
📋 БРИФІНГ: Василь (@vasyl_carrier)
Тип: перевізник | Надійність: 78/100 | trust: established
Маршрути: Гданськ→Київ, Гданськ→Одеса
Мова: рус | Стиль: неформальний, прямий

📦 АКТИВНІ УГОДИ:
1. #D-2026-0042 | Гданськ→Київ, 40'HC, 30.03
   Статус: in_transit | Ціна перевізника: 1500€
   Останнє: водій на завантаженні (вчора 14:00)

2. #D-2026-0051 | Гданськ→Одеса, 40', 02.04
   Статус: negotiating | Ціна: обговорюють
   Останнє: Василь запитав "яка ціна?" (сьогодні 10:15)

💬 ОСТАННІЙ КОНТЕКСТ:
Василь запитав ціну на Гданськ→Одеса. Агент відповів "Уточню".
Ще не відповіли з ціною.

🎯 ЙМОВІРНО ХОЧЕ:
Дізнатись ціну на рейс Гданськ→Одеса (угода #D-2026-0051).

💡 РЕКОМЕНДАЦІЯ:
- Назвати ціну на Гданськ→Одеса (ринкова ~1400€)
- Уточнити чи все ОК з рейсом #D-2026-0042 (in_transit)
```

### Заборонено

- ❌ Показувати маржу або ціну іншої сторони в брифінгу (оператор бачить СВОЮ ціну по стороні контакту)
- ❌ Виконувати будь-які дії в БД (WF-12 — read-only)
- ❌ Відповідати контакту через бот (бот тільки для оператора)
