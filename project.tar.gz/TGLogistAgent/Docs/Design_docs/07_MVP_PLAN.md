# План реалізації MVP

## 1. Технологічний стек (Фаза 1)

```
Runtime:        Python 3.11+ (швидкий старт, Telethon/Pyrogram)
Package mgr:    uv + pyproject.toml
БД:             SQLite (один файл, portability)
AI:             Claude API (claude-sonnet-4-20250514)
Telegram:       Telethon (userbot для моніторингу груп + DM з контактами)
                + python-telegram-bot (приватний бот для оператора, whitelist)
Type check:     mypy --strict
Lint/Format:    ruff
Деплой:         Oracle Cloud free tier / локально
Конфігурація:   .env + agent_config таблиця
```

## 2. Етапи

### Етап 0: Підготовка (1 день)

- [ ] Ініціалізувати проект (`uv init`, `pyproject.toml`)
- [ ] Структура проекту:
```
TGLogistAgent/
├── CLAUDE.md                          # Контекст для Claude Code (<200 рядків)
├── pyproject.toml                     # Залежності (uv)
├── .claude/
│   ├── settings.json                  # Дозволи та hooks (ruff auto-format)
│   ├── rules/                         # Правила кодування
│   │   ├── code-style.md              # Python конвенції, типізація, розміри
│   │   ├── async-patterns.md          # Async patterns (Telethon, aiosqlite, httpx)
│   │   └── telegram-handlers.md       # Path-scoped до src/bot/, src/parser/
│   └── skills/
│       ├── project-docs/              # Скіл документації (вже є)
│       └── project-navigator/         # Карта кодової бази (auto-invoked)
├── Docs/                              # Проектна документація
│   ├── Design_docs/                   # 01..11_*.md
│   └── Test_scenarios/                # 01..08_*.md
├── src/
│   ├── __init__.py
│   ├── main.py                        # Entry point, async event loop
│   ├── config.py                      # Конфігурація, env, константи
│   ├── exceptions.py                  # Custom exceptions
│   ├── models/                        # Pydantic-схеми (shared across layers)
│   │   ├── __init__.py
│   │   ├── cargo.py                   # CargoOffer, CargoDetails, ParserOutput
│   │   ├── contact.py                 # Contact, ContactProfile, ContactSlice
│   │   ├── deal.py                    # Deal, DealEvent, DealSummary
│   │   └── common.py                  # MatcherOutput, ResponderOutput, тощо
│   ├── db/                            # SQLite через aiosqlite, repository pattern
│   │   ├── __init__.py
│   │   ├── schema.sql                 # Створення таблиць (18 таблиць)
│   │   ├── migrations.py              # Міграція з існуючої бази
│   │   └── repositories/              # Весь доступ до БД — тільки через репозиторії
│   │       ├── __init__.py
│   │       ├── base.py                # BaseRepository з async CRUD
│   │       ├── contact_repo.py        # Контакти, психологія, надійність, маршрути
│   │       ├── deal_repo.py           # Угоди, events, documents, drivers
│   │       ├── cargo_repo.py          # Вантажі, market_prices, exchange_rates
│   │       └── message_repo.py        # Повідомлення, unprocessed queue
│   ├── parser/                        # Моніторинг Telegram-груп (WF-1)
│   │   ├── __init__.py
│   │   ├── group_monitor.py           # Telethon event handler
│   │   └── message_analyzer.py        # Claude API — аналіз повідомлень
│   ├── agent/                         # Ядро AI-агента
│   │   ├── __init__.py
│   │   ├── codex.py                   # Завантаження system prompt
│   │   ├── router.py                  # Визначення контексту повідомлення (WF-4)
│   │   ├── matcher.py                 # AI-based матчинг (WF-2)
│   │   ├── context.py                 # Context Assembly по 4 зонам
│   │   ├── responder.py               # Генерація відповідей (головний промпт)
│   │   └── verification.py            # Верифікація водіїв/дублікатів (WF-11)
│   ├── deals/                         # Управління угодами
│   │   ├── __init__.py
│   │   ├── manager.py                 # Створення/оновлення угод, статуси
│   │   ├── documents.py               # Forwarding документів між сторонами
│   │   └── templates.py               # Шаблони заявок
│   ├── services/                      # Зовнішні сервіси
│   │   ├── __init__.py
│   │   ├── nbu_rates.py               # Парсер курсу НБУ (api.bank.gov.ua)
│   │   └── carrier_channel.py         # Публікація в Telegram-канал перевізників
│   ├── profiler/                      # Оновлення профілів після взаємодій
│   │   ├── __init__.py
│   │   └── profiler.py
│   ├── monitoring/                    # Health checks (кожні 5-10 хв)
│   │   ├── __init__.py
│   │   └── health.py
│   ├── notifications/                 # Алерти оператору
│   │   ├── __init__.py
│   │   └── notifier.py
│   └── bot/                           # Приватний Telegram-бот оператора (whitelist)
│       ├── __init__.py
│       ├── telegram_bot.py            # Команди: /resolve, /cancel, /health, /who
│       └── contact_briefing.py        # AI-брифінг контакту для оператора (WF-12)
├── tests/                             # pytest тести
│   ├── conftest.py                    # Shared fixtures (test DB, mock clients)
│   ├── test_repositories/             # Тести репозиторіїв
│   ├── test_services/                 # Тести сервісів
│   ├── test_agent/                    # Тести AI-компонентів
│   └── test_file_size.py              # Enforce 500-line limit
├── prompts/                           # AI-промпти (окремі файли)
│   ├── agent_codex.md                 # Responder system prompt (v1)
│   ├── parser_prompt.md               # Parser prompt (v1)
│   ├── matcher_prompt.md              # Matcher prompt (v1)
│   ├── profiler_prompt.md             # Profiler prompt (v1)
│   ├── verification_prompt.md         # Verification Agent prompt (v1)
│   └── contact_briefing_prompt.md     # Contact Briefing prompt (v1)
├── data/
│   └── logist.db                      # SQLite база (gitignored)
├── .env                               # Secrets (gitignored)
└── TG_mcp_clon/                       # MCP-сервер для тестування (вже є)
```
- [ ] Міграція існуючої бази (logist_export) → нова схема
- [ ] Налаштувати Telegram-канал перевізників
- [ ] Налаштувати Telegram-папку "Логістика" для розділення контактів
- [ ] Програмно імпортувати контакти з моніторених груп в папку
- [ ] Тести: всі контакти мігрували коректно

### Етап 1: Розширений парсер (2-3 дні)

**Ціль:** Парсер працює, записує в нову БД, витягує ціни.

- [ ] Адаптувати існуючий парсер під нову схему БД
- [ ] Розширити AI-аналіз: витягувати ціну, тип контейнера, лінію
- [ ] Додати парсинг пропозицій транспорту (type=transport)
- [ ] Автоматичне оновлення contact_routes при кожному повідомленні
- [ ] Автоматичне витягування та запис цін в price_records
- [ ] Нормалізація міст (словник)
- [ ] TTL та автоочищення cargo_offers
- [ ] Парсер курсу НБУ (api.bank.gov.ua) для конвертації валют
- [ ] Тести: парсер коректно записує 50+ повідомлень

### Етап 2: Telegram-бот + Router (2-3 дні)

**Ціль:** Приватний бот для оператора (whitelist). Комунікація з контактами — через userbot (Telethon DM).

- [ ] Створити приватний Telegram-бот (whitelist: тільки оператор)
- [ ] Router: визначає контакт по tg_id
- [ ] Router: підтягує контекст (профіль + угоди + останні повідомлення)
- [ ] Базова AI-відповідь (Claude API + AGENT_CODEX як system prompt)
- [ ] Збереження повідомлень в messages таблицю
- [ ] DM з контактами через Telethon userbot
- [ ] Нотифікація оператора про нових контактів
- [ ] Фільтрація вхідних повідомлень: тільки контакти з логістичної папки / бази
- [ ] Черга unprocessed_messages для повідомлень при збоях API
- [ ] Contact Lookup (WF-12): команда `/who` в адмін-боті
  - [ ] Парсинг вхідних даних: телефон, @username, tg_id, пересланий дзвінок
  - [ ] Пошук контакту по contact_phones, contacts.tg_username, contacts.tg_id
  - [ ] Збірка контексту: профіль + угоди + повідомлення + deal_events + open cargos
  - [ ] AI-промпт Contact Briefing: формування брифінгу для оператора
  - [ ] Обробка пересланого пропущеного Telegram-дзвінка (витяг tg_id)
- [ ] Тести: бот відповідає коротко, по справі, визначає контекст

### Етап 3: Matcher + активний режим (2-3 дні)

**Ціль:** Агент сам визначає маржинальні вантажі і контактує перевізників.

- [ ] Matcher: при новому cargo_offer (type=cargo) аналізує маржу
- [ ] Агрегація market_prices (тижневі середні)
- [ ] Логіка active/passive/skip рішення
- [ ] Автоматична відправка повідомлень перевізникам
- [ ] Таймер очікування відповіді
- [ ] Публікація в Telegram-канал перевізників як fallback
- [ ] Конвертація валют через NBU rates при розрахунку маржі
- [ ] Нотифікація оператора: "Шукаю перевізника для вантажу X"
- [ ] Тести: агент знаходить маржу > порогу і пише правильним перевізникам

### Етап 4: Deal Manager (2-3 дні)

**Ціль:** Повний цикл угоди від prospecting до completed.

- [ ] Створення deal при матчі
- [ ] Переходи статусів з валідацією
- [ ] Deal events (логування всіх змін)
- [ ] Формування заявок по шаблону
- [ ] Ескалація: автоматичне визначення + повідомлення оператора
- [ ] Команди оператора: /resolve, /cancel, /note
- [ ] Верифікація водіїв (driver_contacts)
- [ ] Підтвердження документів оператором перед відправкою
- [ ] Тести: угода проходить повний цикл

### Етап 5: Profiler + інтелект (1-2 дні)

**Ціль:** Контакти отримують профілі, агент стає розумнішим.

- [ ] Profiler: після взаємодії оновлює psychology
- [ ] Profiler: накопичує best_response_pattern
- [ ] Розрахунок reliability після угод
- [ ] Вплив профілю на рішення матчера
- [ ] Вплив best_response_pattern на стиль відповідей
- [ ] Тести: профіль збагачується після 5+ взаємодій

### Етап 6: Тестування через MCP (2-3 дні)

**Ціль:** Прогнати всі тестові сценарії через MCP-сервер TG_mcp_clon перед запуском.

- [ ] Налаштувати MCP-сервер TG_mcp_clon (config.json, авторизація)
- [ ] Створити тестове середовище (тестові групи, канал, контакти в БД)
- [ ] Прогнати сценарії безпеки (01_SECURITY_SCENARIOS.md) — 6 тестів
- [ ] Прогнати сценарії переговорів (02_NEGOTIATION_SCENARIOS.md) — 5 тестів
- [ ] Прогнати сценарії скасувань (03_CANCELLATION_SCENARIOS.md) — 4 тести
- [ ] Прогнати сценарії ескалацій (04_ESCALATION_SCENARIOS.md) — 4 тести
- [ ] Прогнати сценарії першого контакту (05_FIRST_CONTACT_SCENARIOS.md) — 4 тести
- [ ] Прогнати сценарії верифікації (06_VERIFICATION_SCENARIOS.md) — 4 тести
- [ ] Прогнати сценарії збоїв (07_RECOVERY_SCENARIOS.md) — 4 тести
- [ ] Прогнати сценарії каналу (08_CHANNEL_SCENARIOS.md) — 3 тести
- [ ] Виправити дефекти знайдені при тестуванні
- [ ] Повторний прогін критичних сценаріїв (безпека + переговори)

Детальніше: див. 11_TESTING.md та Docs/Test_scenarios/

### Етап 7: Polish + запуск (1-2 дні)

- [ ] Щоденний дайджест для оператора
- [ ] Обробка документів (forwarding файлів)
- [ ] Graceful handling помилок API
- [ ] Логування всіх AI-запитів (для дебагу)
- [ ] Обмеження rate: не більше 3 повідомлень одному контакту на годину
- [ ] Health monitoring для всіх модулів
- [ ] Команда /health в боті оператора
- [ ] Автоматичні бекапи SQLite (кожні 6 годин)
- [ ] Архівування старих угод та повідомлень
- [ ] Деплой на сервер
- [ ] Тестування з оператором на реальних даних (1 тиждень в ручному режимі):
   - Перші вихідні повідомлення новим контактам — 100% підтвердження оператора
   - Вхідні повідомлення — агент може відповідати самостійно (з моніторингом)
   - Фінальне рішення по автономності — за результатами тестування

---

## 3. Бюджет API

Оцінка витрат Claude API на місяць:

```
Парсер: ~500 повідомлень/день × 30 = 15,000 запитів
  - input: ~200 токенів (повідомлення + system prompt)
  - output: ~100 токенів (JSON)
  - Sonnet: $3/M input + $15/M output
  - Вартість: ~$9 + ~$22.5 = ~$31.5/міс

Matcher: ~50 матчів/день × 30 = 1,500 запитів
  - input: ~1000 токенів (вантаж + кандидати + ціни)
  - output: ~200 токенів
  - Вартість: ~$4.5 + ~$4.5 = ~$9/міс

Responder: ~100 повідомлень/день × 30 = 3,000 запитів  
  - input: ~2000 токенів (codex + контекст + переписка)
  - output: ~50 токенів (коротка відповідь)
  - Вартість: ~$18 + ~$2.25 = ~$20.25/міс

Profiler: ~50 оновлень/день × 30 = 1,500 запитів
  - input: ~500 токенів
  - output: ~200 токенів
  - Вартість: ~$2.25 + ~$4.5 = ~$6.75/міс

Contact Briefing: ~10 запитів/день × 30 = 300 запитів
  - input: ~3000 токенів (профіль + угоди + переписка + cargo)
  - output: ~500 токенів (форматований брифінг)
  - Вартість: ~$2.7 + ~$2.25 = ~$4.95/міс

ЗАГАЛОМ: ~$72.5/міс (Sonnet)
```

Якщо маржа від агента — навіть 500€/міс, ROI = 7x+

---

## 4. Ризики та мітигація

| Ризик | Мітигація |
|-------|-----------|
| AI галюцинує, пише чушню контакту | Structured output + confidence score + ескалація при < 0.7 |
| Контакт розуміє що це бот | Стиль AGENT_CODEX — короткий, людський. Немає шаблонних фраз |
| Telegram банить userbot | Використовувати окремий акаунт. Не спамити. Rate limiting |
| Телеграм банить бота за масову розсилку | Не масова: MAX 3 контакти за раз, пауза 5+ хвилин |
| Конфліктна ситуація, агент загострює | Автоматична ескалація при будь-якому конфлікті |
| Дані витікають між сторонами | Контекстна ізоляція + тести безпеки |
| Оператор не довіряє агенту | Перший місяць — напівавтономний режим. Агент готує, оператор підтверджує |
| Курс валют різко змінився | Автооновлення курсу НБУ щоденно. Маржа рахується в USD. |
