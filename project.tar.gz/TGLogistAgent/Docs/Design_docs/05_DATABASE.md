# Схема бази даних

## 1. Загальне

Фаза 1 (MVP): SQLite — один файл, простота, вже є досвід.
Фаза 2: Міграція на PostgreSQL коли з'явиться потреба в конкурентних запитах.

---

## 2. Таблиці

### contacts

Головна таблиця контактів. Джерело: парсер (автоматично) + ручне введення.

```sql
CREATE TABLE contacts (
    id              TEXT PRIMARY KEY,               -- UUID
    tg_id           INTEGER UNIQUE NOT NULL,        -- Telegram user ID
    tg_username     TEXT,                            -- @username
    first_name      TEXT,
    last_name       TEXT,
    type            TEXT CHECK(type IN ('customer','carrier','both','unknown')) DEFAULT 'unknown',
    poland_related  INTEGER DEFAULT 0,              -- bool
    first_seen      TEXT NOT NULL,                   -- ISO timestamp
    last_seen       TEXT NOT NULL,
    total_messages  INTEGER DEFAULT 0,
    created_at      TEXT DEFAULT (datetime('now')),
    updated_at      TEXT DEFAULT (datetime('now'))
);
```

### contact_phones

Один контакт може мати кілька телефонів.

```sql
CREATE TABLE contact_phones (
    id          TEXT PRIMARY KEY,
    contact_id  TEXT NOT NULL REFERENCES contacts(id),
    phone       TEXT NOT NULL,
    source      TEXT,                               -- звідки отримано: message / deal / manual
    created_at  TEXT DEFAULT (datetime('now')),
    UNIQUE(contact_id, phone)
);
```

### contact_routes

Відомі маршрути контакту (нормалізовані).

```sql
CREATE TABLE contact_routes (
    id          TEXT PRIMARY KEY,
    contact_id  TEXT NOT NULL REFERENCES contacts(id),
    from_city   TEXT NOT NULL,                      -- нормалізоване
    to_city     TEXT NOT NULL,                      -- нормалізоване
    direction   TEXT,                               -- import / export / internal
    frequency   INTEGER DEFAULT 1,                  -- скільки разів зустрічався цей маршрут
    last_seen   TEXT,
    UNIQUE(contact_id, from_city, to_city)
);
```

### contact_source_groups

В яких Telegram-групах зустрічався контакт.

```sql
CREATE TABLE contact_source_groups (
    id          TEXT PRIMARY KEY,
    contact_id  TEXT NOT NULL REFERENCES contacts(id),
    group_name  TEXT NOT NULL,                      -- назва групи
    group_tg_id INTEGER,                            -- Telegram ID групи
    first_seen  TEXT,                               -- коли вперше зустрівся в цій групі
    last_seen   TEXT,                               -- коли востаннє
    UNIQUE(contact_id, group_name)
);
```

### contact_psychology

Психологічний профіль. Оновлюється Profiler-ом після взаємодій.

```sql
CREATE TABLE contact_psychology (
    contact_id              TEXT PRIMARY KEY REFERENCES contacts(id),
    communication_style     TEXT,                   -- formal / informal / blunt / mixed
    language                TEXT,                   -- uk / ru / mixed
    response_speed          TEXT,                   -- fast / normal / slow
    bargaining_behavior     TEXT,                   -- flexible / firm / aggressive
    preferred_contact_time  TEXT,                   -- e.g. "09:00-18:00"
    typical_message_length  TEXT,                   -- short / medium / long
    emoji_usage             TEXT,                   -- none / rare / frequent
    best_response_pattern   TEXT,                   -- вільний текст, опис як спілкуватись
    trust_level             TEXT DEFAULT 'new',     -- new / developing / established / trusted
    updated_at              TEXT
);
```

### contact_reliability

Метрики надійності. Оновлюється Deal Manager-ом після кожної угоди.

```sql
CREATE TABLE contact_reliability (
    contact_id              TEXT PRIMARY KEY REFERENCES contacts(id),
    deals_total             INTEGER DEFAULT 0,
    deals_completed         INTEGER DEFAULT 0,
    deals_cancelled         INTEGER DEFAULT 0,
    cancellation_rate       REAL DEFAULT 0,         -- 0.0 - 1.0
    payment_punctuality     TEXT DEFAULT 'unknown',  -- on_time / slight_delay / problematic / unknown
    avg_payment_delay_days  REAL DEFAULT 0,
    communication_culture   INTEGER DEFAULT 3,       -- 1-5
    disputes_count          INTEGER DEFAULT 0,
    who_cancelled           TEXT,                     -- JSON array: хто ініціював скасування ["us","them","them"]
    last_dispute_date       TEXT,                     -- ISO timestamp останнього конфлікту
    dispute_descriptions    TEXT,                     -- JSON array: описи конфліктів
    overall_reliability     INTEGER DEFAULT 50,      -- 0-100
    manual_notes            TEXT,                     -- Ручні примітки оператора
    updated_at              TEXT
);
```

### price_records

Історія цін конкретного контакту по маршрутах.

```sql
CREATE TABLE price_records (
    id              TEXT PRIMARY KEY,
    contact_id      TEXT NOT NULL REFERENCES contacts(id),
    route_from      TEXT NOT NULL,
    route_to        TEXT NOT NULL,
    container_type  TEXT,                            -- 20 / 40 / 40HC / 45 / reefer
    price           REAL NOT NULL,
    currency        TEXT DEFAULT 'EUR',              -- EUR / USD / UAH
    date            TEXT NOT NULL,                   -- дата коли ціна була актуальна
    source          TEXT DEFAULT 'message',          -- message / deal / voice / manual
    source_msg_id   INTEGER,                         -- Telegram message ID якщо є
    created_at      TEXT DEFAULT (datetime('now'))
);

CREATE INDEX idx_price_route ON price_records(route_from, route_to, date);
CREATE INDEX idx_price_contact ON price_records(contact_id, date);
```

### market_prices

Агреговані ринкові ціни по маршрутах (розраховується щоденно/щотижнево).

```sql
CREATE TABLE market_prices (
    id              TEXT PRIMARY KEY,
    route_from      TEXT NOT NULL,
    route_to        TEXT NOT NULL,
    container_type  TEXT,
    period          TEXT NOT NULL,                   -- 'week' / 'month'
    period_start    TEXT NOT NULL,                   -- початок періоду
    avg_customer_price  REAL,                        -- середня ціна замовників
    avg_carrier_price   REAL,                        -- середня ціна перевізників
    avg_spread          REAL,                        -- avg_customer - avg_carrier
    sample_count        INTEGER,                     -- кількість спостережень
    currency            TEXT DEFAULT 'EUR',
    created_at          TEXT DEFAULT (datetime('now')),
    UNIQUE(route_from, route_to, container_type, period, period_start)
);
```

### exchange_rates

Кеш курсів валют від НБУ (api.bank.gov.ua). Оновлюється щоденно.

```sql
CREATE TABLE exchange_rates (
    currency    TEXT PRIMARY KEY,              -- EUR / USD
    rate_uah    REAL NOT NULL,                 -- курс до UAH
    date        TEXT NOT NULL,                 -- дата курсу
    updated_at  TEXT DEFAULT (datetime('now'))
);
```

### cargo_offers

Зона 1 — актуальні вантажі та пропозиції транспорту.

```sql
CREATE TABLE cargo_offers (
    id                  TEXT PRIMARY KEY,            -- UUID
    source_msg_id       INTEGER,                     -- Telegram message ID
    source_group        TEXT,                        -- назва групи
    sender_contact_id   TEXT REFERENCES contacts(id),
    type                TEXT CHECK(type IN ('cargo','transport')) NOT NULL,
    direction_from      TEXT NOT NULL,
    direction_to        TEXT,                        -- може бути NULL для transport ("вільний в Гданську")
    container_type      TEXT,
    weight_tons         REAL,
    cargo_description   TEXT,
    departure_date      TEXT,
    price               REAL,
    price_currency      TEXT,
    payment_type        TEXT,                        -- cash / bank / null
    contact_name_raw    TEXT,                        -- ім'я з повідомлення
    contact_phone_raw   TEXT,                        -- телефон з повідомлення
    raw_text            TEXT NOT NULL,               -- оригінал
    ai_analysis         TEXT,                        -- JSON від AI
    status              TEXT DEFAULT 'open' CHECK(status IN ('open','matched','expired','archived')),
    created_at          TEXT DEFAULT (datetime('now')),
    expires_at          TEXT                         -- auto-cleanup
);

CREATE INDEX idx_cargo_status ON cargo_offers(status, type);
CREATE INDEX idx_cargo_route ON cargo_offers(direction_from, direction_to, status);
CREATE INDEX idx_cargo_date ON cargo_offers(departure_date, status);
```

### deals

Зона 2 — активні та завершені угоди.
Один cargo_offer може мати кілька deals коли потрібно кілька авто на маршрут. Кожен deal — окреме авто-місце.

```sql
CREATE TABLE deals (
    id                  TEXT PRIMARY KEY,            -- UUID
    cargo_offer_id      TEXT REFERENCES cargo_offers(id),
    customer_contact_id TEXT REFERENCES contacts(id),
    carrier_contact_id  TEXT REFERENCES contacts(id),
    route_from          TEXT NOT NULL,
    route_to            TEXT NOT NULL,
    container_type      TEXT,
    departure_date      TEXT,
    customer_price      REAL,                        -- скільки платить замовник
    customer_currency   TEXT DEFAULT 'EUR',
    carrier_price       REAL,                        -- скільки отримує перевізник
    carrier_currency    TEXT DEFAULT 'EUR',
    margin              REAL,                        -- customer_price - carrier_price
    status              TEXT DEFAULT 'prospecting' CHECK(status IN (
                            'prospecting','negotiating','agreed','in_transit',
                            'completed','cancelled','disputed'
                        )),
    escalated           INTEGER DEFAULT 0,
    escalation_reason   TEXT,
    notes               TEXT,
    created_at          TEXT DEFAULT (datetime('now')),
    updated_at          TEXT DEFAULT (datetime('now'))
);

CREATE INDEX idx_deals_status ON deals(status);
CREATE INDEX idx_deals_customer ON deals(customer_contact_id, status);
CREATE INDEX idx_deals_carrier ON deals(carrier_contact_id, status);
```

### deal_events

Ланцюжок подій по угоді (status_history).

```sql
CREATE TABLE deal_events (
    id          TEXT PRIMARY KEY,
    deal_id     TEXT NOT NULL REFERENCES deals(id),
    event_type  TEXT NOT NULL,                       -- status_change / note / escalation / document
    old_value   TEXT,
    new_value   TEXT,
    note        TEXT,
    created_at  TEXT DEFAULT (datetime('now'))
);

CREATE INDEX idx_deal_events ON deal_events(deal_id, created_at);
```

### messages

Зберігання всіх повідомлень (з груп та DM).

```sql
CREATE TABLE messages (
    id              TEXT PRIMARY KEY,
    tg_msg_id       INTEGER,                        -- Telegram message ID
    contact_id      TEXT REFERENCES contacts(id),
    source          TEXT NOT NULL,                   -- group_name або 'dm'
    direction       TEXT CHECK(direction IN ('in','out')), -- in = від контакту, out = від агента
    text            TEXT NOT NULL,
    ai_analysis     TEXT,                            -- JSON
    deal_id         TEXT REFERENCES deals(id),       -- до якої угоди прив'язано (якщо відомо)
    profiler_processed INTEGER DEFAULT 0,            -- 0 = ще не оброблено Profiler-ом, 1 = оброблено
    created_at      TEXT DEFAULT (datetime('now'))
);

CREATE INDEX idx_messages_contact ON messages(contact_id, created_at);
CREATE INDEX idx_messages_deal ON messages(deal_id, created_at);
```

### deal_documents

Зона 4 — документи прив'язані до угод.

```sql
CREATE TABLE deal_documents (
    id          TEXT PRIMARY KEY,
    deal_id     TEXT NOT NULL REFERENCES deals(id),
    doc_type    TEXT,                                -- application / cmr / ttn / invoice / other
    file_path   TEXT,                                -- шлях до файлу
    file_name   TEXT,
    uploaded_by TEXT REFERENCES contacts(id),        -- хто прислав
    forwarded_to TEXT REFERENCES contacts(id),       -- кому переслано (NULL якщо ще не переслано)
    created_at  TEXT DEFAULT (datetime('now'))
);
```

### agent_config

Конфігурація агента (пороги, режими).

```sql
CREATE TABLE agent_config (
    key     TEXT PRIMARY KEY,
    value   TEXT NOT NULL,
    updated_at TEXT DEFAULT (datetime('now'))
);

-- Початкові значення
INSERT INTO agent_config VALUES ('margin_threshold_usd', '100', datetime('now'));
INSERT INTO agent_config VALUES ('max_carriers_to_contact', '3', datetime('now'));
INSERT INTO agent_config VALUES ('response_wait_hours', '2', datetime('now'));
INSERT INTO agent_config VALUES ('cargo_ttl_hours', '72', datetime('now'));
INSERT INTO agent_config VALUES ('escalation_amount_eur', '5000', datetime('now'));
INSERT INTO agent_config VALUES ('active_mode_enabled', '1', datetime('now'));
INSERT INTO agent_config VALUES ('min_reliability_for_active', '50', datetime('now'));
INSERT INTO agent_config VALUES ('carrier_channel_id', '', datetime('now'));
INSERT INTO agent_config VALUES ('nbu_rate_update_interval', 'daily', datetime('now'));
INSERT INTO agent_config VALUES ('first_contact_approval', '1', datetime('now'));
```

### unprocessed_messages

Черга повідомлень які не вдалось обробити (API down, помилка парсингу).

```sql
CREATE TABLE unprocessed_messages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tg_msg_id       INTEGER,
    tg_user_id      INTEGER,
    chat_id         INTEGER,
    text            TEXT,
    raw_data        TEXT,                                -- JSON повний payload
    reason          TEXT,                                -- api_down / parse_error / unknown
    received_at     TEXT DEFAULT (datetime('now')),
    processed       INTEGER DEFAULT 0,
    processed_at    TEXT
);
```

### driver_contacts

Верифіковані водії прив'язані до конкретних угод.

```sql
CREATE TABLE driver_contacts (
    id                  TEXT PRIMARY KEY,
    deal_id             TEXT REFERENCES deals(id),
    carrier_contact_id  TEXT REFERENCES contacts(id),
    driver_name         TEXT NOT NULL,
    driver_phone        TEXT,
    driver_tg_id        INTEGER,
    driver_tg_username  TEXT,
    verified            INTEGER DEFAULT 0,
    created_at          TEXT DEFAULT (datetime('now'))
);
```

### deals_archive

Архів завершених угод (старших за 90 днів). Ідентична структура до `deals` + поле `archived_at`.

```sql
CREATE TABLE deals_archive AS SELECT *, datetime('now') AS archived_at FROM deals WHERE 0;
```

### messages_archive

Архів повідомлень завершених угод (старших за 90 днів).

```sql
CREATE TABLE messages_archive AS SELECT *, datetime('now') AS archived_at FROM messages WHERE 0;
```

---

## 3. Міграція з існуючої бази

Існуюча база з парсера (logist_export.xlsx) має:
- **Користувачі** → contacts + contact_phones + contact_routes
- **Повідомлення** → messages + cargo_offers (для тих що match=ТАК)

Скрипт міграції повинен:
1. Нормалізувати міста (Гданськ/Гданск/Gdansk → Гданськ)
2. Розпарсити телефони з рядка в окремі записи
3. Витягти маршрути з поля "Напрямки" в contact_routes
4. Перенести AI-аналіз повідомлень
5. Створити cargo_offers з matched повідомлень

## 4. Нормалізація міст

Словник нормалізації (розширюваний):

```
Гданск, Gdansk, Гданьск → Гданськ
Гдыня, Gdynia → Гдиня
Киев, Київ, Kiev → Київ
Одесса, Одеса, Odessa → Одеса
Львів, Львов → Львів
Днепр, Дніпро → Дніпро
Харьков, Харків → Харків
Варшава, Warszawa → Варшава
```
