# Тестування системи (Testing Infrastructure)

## 1. Загальний підхід

Тестування LogistAgent відбувається через **MCP-сервер** `TG_mcp_clon`, який надає Claude Code агенту-розробнику доступ до **двох** Telegram-акаунтів через Telethon (userbot). Третій акаунт належить самому AI-агенту LogistAgent. Це дозволяє імітувати повноцінну взаємодію між замовниками, перевізниками та агентом без залучення реальних клієнтів.

### Модель трьох акаунтів

```
┌─────────────────────────────────────────────────────────┐
│              Claude Code (агент-розробник)                │
│                                                          │
│   MCP-сервер TG_mcp_clon                                │
│   ┌──────────────────┐   ┌──────────────────┐           │
│   │  Акаунт A        │   │  Акаунт B        │           │
│   │  "Замовник"      │   │  "Перевізник"    │           │
│   │  tg_a_*() tools  │   │  tg_b_*() tools  │           │
│   └────────┬─────────┘   └────────┬─────────┘           │
│            │                      │                      │
└────────────┼──────────────────────┼──────────────────────┘
             │   DM / групи         │   DM / групи
             ▼                      ▼
      ┌─────────────────────────────────────┐
      │         Telegram                     │
      └────────────────┬────────────────────┘
                       │
                       ▼
      ┌──────────────────────────────┐
      │  Акаунт C                    │
      │  LogistAgent (AI-агент)      │
      │  Наше ПЗ що розробляється    │
      │  Працює окремо від MCP       │
      └──────────────────────────────┘
```

| Акаунт | Хто керує | Призначення | Де працює |
|--------|-----------|-------------|-----------|
| **A** | Claude Code через MCP | Імітація замовника, невідомих контактів, зловмисників | TG_mcp_clon (сесія A) |
| **B** | Claude Code через MCP | Імітація перевізника, водія, другого акаунту | TG_mcp_clon (сесія B) |
| **C** | LogistAgent (наше ПЗ) | AI-агент якого ми розробляємо та тестуємо | Окремий процес (Telethon) |

**Принцип:** Claude Code агент-розробник використовує два MCP-акаунти для імітації обох сторін угоди одночасно (замовник + перевізник), а LogistAgent на третьому акаунті реагує як в реальному продакшені.

---

## 2. MCP-сервер TG_mcp_clon

### Розташування

```
D:\TGLogistAgent\TG_mcp_clon\
├── server.py              # FastMCP сервер (28 tools + мультиакаунт + cleanup)
├── telegram_client.py     # Telethon-клієнт (мультисесійний)
├── database.py            # SQLite для статистики
├── config.json            # Конфігурація (два акаунти)
├── config.example.json    # Шаблон конфігурації
├── requirements.txt       # Залежності (telethon, mcp, aiosqlite)
├── tg_session_a.session   # Сесія Telethon акаунту A (замовник)
└── tg_session_b.session   # Сесія Telethon акаунту B (перевізник)
```

### Мультиакаунтна архітектура MCP

Поточна версія MCP-сервера підтримує один акаунт. При імплементації треба розширити до **двох акаунтів** (A і B).

**Підхід до мультиакаунтності:**

Кожен існуючий інструмент дублюється з префіксом `account`:

```python
# Поточний стан (один акаунт):
tg_comment(group_id, text)

# Мультиакаунтний стан (два акаунти):
tg_comment(account="a", group_id=..., text="...")   # від імені акаунту A
tg_comment(account="b", group_id=..., text="...")   # від імені акаунту B
```

**Альтернативний підхід (простіший для імплементації):**

Параметр `account` додається до КОЖНОГО інструменту як перший опціональний параметр. Default = "a".

```python
@mcp.tool()
async def tg_comment(text: str, group_id: int,
                     reply_to_id: int | None = None,
                     account: str = "a") -> str:
    """Send a comment. account='a' or 'b'."""
    client = await tg.get_client(account)  # отримує відповідну сесію
    ...
```

**Конфігурація для двох акаунтів:**

```json
{
  "accounts": {
    "a": {
      "api_id": "...",
      "api_hash": "...",
      "phone": "+380XXXXXXXXX",
      "session_file": "tg_session_a",
      "role": "customer"
    },
    "b": {
      "api_id": "...",
      "api_hash": "...",
      "phone": "+380YYYYYYYYY",
      "session_file": "tg_session_b",
      "role": "carrier"
    }
  },
  "channel_username": "test_carriers"
}
```

**Примітка:** Обидва акаунти можуть використовувати ОДНАКОВІ `api_id` / `api_hash` (одне Telegram-додаток), але різні номери телефонів та сесії.

### Доступні інструменти

#### Базові інструменти (28 tools, кожен з параметром `account`)

| Категорія | Інструмент | Опис | Параметр `account` |
|-----------|-----------|------|---------------------|
| **Auth** | `tg_setup` | Налаштування credentials для акаунту | Так (a/b) |
| | `tg_auth_send_code` | Відправка коду авторизації | Так (a/b) |
| | `tg_auth_verify` | Верифікація коду + 2FA | Так (a/b) |
| **Профіль** | `tg_profile` | Отримати профіль | Так (a/b) |
| | `tg_set_bio` | Змінити біо | Так (a/b) |
| **Групи** | `tg_my_groups` | Список груп | Так (a/b) |
| | `tg_my_channels` | Список каналів | Так (a/b) |
| | `tg_search_groups` | Пошук публічних груп | Так (a/b) |
| | `tg_join` | Приєднатись до групи | Так (a/b) |
| | `tg_leave` | Вийти з групи | Так (a/b) |
| **Канали** | `tg_create_channel` | Створити канал/групу | Так (a/b) |
| | `tg_set_channel_*` | Налаштування каналу (title, description, username, photo, slow_mode, history) | Так (a/b) |
| | `tg_create_invite` | Створити запрошення | Так (a/b) |
| | `tg_invite_links` | Список запрошень | Так (a/b) |
| | `tg_delete_channel` | Видалити канал | Так (a/b) |
| **Повідомлення** | `tg_messages` | Читати повідомлення | Так (a/b) |
| | `tg_comment` | Надіслати повідомлення | Так (a/b) |
| | `tg_post` | Публікація в канал | Так (a/b) |
| | `tg_edit` | Редагувати повідомлення | Так (a/b) |
| | `tg_delete` | Видалити повідомлення | Так (a/b) |
| **Статистика** | `tg_channel_stats` | Підписники каналу | Так (a/b) |
| | `tg_stats` | Загальна статистика | — |
| **З'єднання** | `tg_disconnect` | Відключитись | Так (a/b або "all") |

#### Тестові інструменти (нові, для тестування)

| Інструмент | Опис |
|-----------|------|
| `tg_test_cleanup` | Очищення після сценарію: видаляє повідомлення в TG + очищає тестову БД |
| `tg_test_send_dm` | Надіслати DM конкретному tg_id від акаунту A або B |
| `tg_test_read_dm` | Прочитати DM з конкретним tg_id від акаунту A або B |

Детальніше про `tg_test_cleanup`: див. секція 8 (Очищення між сценаріями).

### Налаштування перед тестуванням

```
Крок 1: Налаштувати credentials для обох акаунтів
  → tg_setup(account="a", api_id="...", api_hash="...")
  → tg_setup(account="b", api_id="...", api_hash="...")

Крок 2: Авторизувати обидва акаунти
  → tg_auth_send_code(account="a", phone="+380XXXXXXXXX")
  → tg_auth_verify(account="a", code="12345")
  → tg_auth_send_code(account="b", phone="+380YYYYYYYYY")
  → tg_auth_verify(account="b", code="67890")

Крок 3: Створити тестове середовище (від акаунту A)
  → tg_create_channel(account="a", title="[TEST] Turbo-ИМПОРТ", is_group=True)
  → tg_create_channel(account="a", title="[TEST] Перевізники", is_group=False)

Крок 4: Додати акаунт B в тестові групи
  → tg_create_invite(account="a", channel_id=TEST_GROUP_ID)
  → tg_join(account="b", username_or_link="invite_link")

Крок 5: Додати акаунт C (LogistAgent) в тестові групи
  (вручну або через invite link)

Крок 6: Перевірити стан
  → tg_profile(account="a")    # перевірити акаунт "замовника"
  → tg_profile(account="b")    # перевірити акаунт "перевізника"
  → tg_my_groups(account="a")  # перевірити що обидва в групах
  → tg_my_groups(account="b")
```

---

## 3. Тестове середовище

### Telegram-сутності для тестів

| Сутність | Тип | Хто керує | Призначення |
|----------|-----|-----------|-------------|
| `[TEST] Turbo-ИМПОРТ` | Група (megagroup) | Всі 3 акаунти | Імітація логістичної групи з вантажами |
| `[TEST] Tlg Ukraine Logistics` | Група (megagroup) | Всі 3 акаунти | Друга тестова логістична група |
| `[TEST] Перевізники PL→UA` | Канал | Акаунт C (LogistAgent) | Імітація каналу перевізників |
| **Акаунт A** | Акаунт (MCP) | Claude Code | Імітація замовника, невідомих, зловмисників |
| **Акаунт B** | Акаунт (MCP) | Claude Code | Імітація перевізника, водія, другого акаунту |
| **Акаунт C** | Акаунт (Telethon) | LogistAgent | AI-агент, що тестується |

### Тестова БД

Для тестів використовується окрема SQLite база (`logist_test.db`) з попередньо заповненими даними:

- 10-20 тестових контактів (різні типи: customer, carrier, both, unknown)
- 3-5 тестових маршрутів (Гданськ→Київ, Гданськ→Одеса, Гдиня→Львів)
- 5-10 цінових записів (для розрахунку market_prices)
- 2-3 активні угоди (різні статуси: prospecting, negotiating, agreed)
- Курси валют (EUR, USD)

---

## 4. Сценарії тестування

Сценарії розділені по зонах і описані в окремих файлах:

```
D:\TGLogistAgent\Docs\Test_scenarios\
├── 01_SECURITY_SCENARIOS.md        # Сценарії безпеки та соціальної інженерії
├── 02_NEGOTIATION_SCENARIOS.md     # Сценарії переговорів та угод
├── 03_CANCELLATION_SCENARIOS.md    # Сценарії скасувань
├── 04_ESCALATION_SCENARIOS.md      # Сценарії ескалацій
├── 05_FIRST_CONTACT_SCENARIOS.md   # Сценарії першого контакту
├── 06_VERIFICATION_SCENARIOS.md    # Сценарії верифікації
├── 07_RECOVERY_SCENARIOS.md        # Сценарії збоїв та відновлення
└── 08_CHANNEL_SCENARIOS.md         # Сценарії роботи з каналом перевізників
```

Детальніше: див. кожен файл окремо.

### Загальна карта покриття

| Зона сценаріїв | Кількість | Покриває Workflows | Покриває промпти |
|----------------|-----------|--------------------|--------------------|
| Безпека | 6 | WF-4, WF-11 | Responder, Verification |
| Переговори | 5 | WF-1→WF-4, WF-7 | Parser, Matcher, Responder, Profiler |
| Скасування | 4 | WF-4, WF-6 | Responder |
| Ескалації | 4 | WF-4, WF-5, WF-6 | Responder |
| Перший контакт | 4 | WF-4 | Responder |
| Верифікація | 4 | WF-11 | Verification, Responder |
| Збої/Recovery | 4 | WF-10, WF-8 | — (інфраструктура) |
| Канал | 3 | WF-9 | Responder |

---

## 5. Як агент-розробник виконує тести

### Загальна процедура

```
Claude Code агент-розробник (тестувальник)
        │
        ▼
    1. Підключає MCP-сервер TG_mcp_clon (акаунти A і B)
    2. Переконується що LogistAgent (акаунт C) працює
    3. Читає файл сценарію (наприклад 01_SECURITY_SCENARIOS.md)
        │
        ▼
    4. Для кожного сценарію:
       a. Очищення: tg_test_cleanup() — очистити TG + БД від попереднього тесту
       b. Підготовка: заповнити тестову БД потрібними даними (seed)
       c. Дія: використати MCP-інструменти від акаунту A або B
       d. Очікування: зачекати реакцію LogistAgent (акаунт C)
       e. Перевірка: прочитати відповідь через tg_messages / tg_test_read_dm
       f. Валідація: порівняти з очікуваним результатом зі сценарію
       g. Перевірка БД: переконатись що записи створені правильно
        │
        ▼
    5. tg_test_cleanup() — фінальне очищення
    6. Звіт: формує звіт про результати тестування
```

### Типовий потік тестування угоди (3 акаунти)

```
Акаунт A (замовник)                 Акаунт C (LogistAgent)           Акаунт B (перевізник)
─────────────────                   ──────────────────────           ─────────────────────

1. tg_comment(account="a",
   group_id=TEST_GROUP,
   text="Гданськ→Київ, 40HC,       → Parser → cargo_offer
   22т, 01.04. 1800€")             → Matcher → action=active

                                    2. LogistAgent пише DM ──────→  3. tg_test_read_dm(account="b",
                                       акаунту B через акаунт C        peer_tg_id=AGENT_TG_ID)
                                       "Гданськ→Київ, 40HC,            → Бачить пропозицію
                                       22т, 01.04. Вільні?"

                                                                    4. tg_test_send_dm(account="b",
                                                                       peer_tg_id=AGENT_TG_ID,
                                    ← Отримує від B               ←    text="Так, 1500 поїду")

                                    5. LogistAgent відповідає B
                                       "Добре, фіксую."

                                    6. LogistAgent пише DM ──────→  Акаунту A (замовнику)
                                       акаунту A через акаунт C

7. tg_test_read_dm(account="a",
   peer_tg_id=AGENT_TG_ID)
   → Бачить підтвердження

8. Валідація БД: deals.status,
   deal_events, messages, тощо.

9. tg_test_cleanup()
   → Готово до наступного сценарію
```

### Розподіл акаунтів по ролях в сценаріях

| Сценарій | Акаунт A (грає роль) | Акаунт B (грає роль) |
|----------|---------------------|---------------------|
| SEC-1..SEC-6 | Замовник | Перевізник (пише провокації) |
| NEG-1..NEG-5 | Замовник (публікує вантаж в групу) | Перевізник (відповідає в DM) |
| CAN-1..CAN-4 | Замовник | Перевізник (скасовує) |
| ESC-1..ESC-4 | Замовник | Перевізник (конфлікт) |
| FC-1..FC-4 | Невідомий замовник | Невідомий перевізник |
| VER-1..VER-4 | — | Водій / дублікат акаунту |
| SEC-5 (фішинг) | Зловмисник | — |
| CH-1..CH-3 | Замовник | Перевізник (відгук з каналу) |

---

## 6. Конвенції тестових даних

### Імена тестових контактів

| Ім'я | Тип | Reliability | Роль в тестах |
|------|-----|-------------|---------------|
| Тест-Олег | customer | 85 | Надійний замовник |
| Тест-Андрій | customer | 30 | Ненадійний замовник |
| Тест-Василь | carrier | 78 | Надійний перевізник |
| Тест-Дмитро | carrier | 55 | Середній перевізник |
| Тест-Іван | carrier | 40 | Перевізник на межі порогу |
| Тест-Марія | both | 90 | І замовник, і перевізник |
| Тест-Водій-Петро | — | — | Верифікований водій |
| Тест-Зловмисник | unknown | 0 | Для тестів безпеки |

### Тестові маршрути та ціни

| Маршрут | Середня ціна (carrier) | Типова ціна (customer) | Маржа |
|---------|----------------------|----------------------|-------|
| Гданськ→Київ | 1450€ | 1800€ | ~350€ |
| Гданськ→Одеса | 1600€ | 1950€ | ~350€ |
| Гдиня→Львів | 1100€ | 1350€ | ~250€ |
| Варшава→Дніпро | 1700€ | 2100€ | ~400€ |

---

## 7. Очищення між сценаріями (Cleanup)

### Проблема

Кожен тестовий сценарій залишає після себе:
- Повідомлення в Telegram (групи, DM)
- Записи в тестовій БД LogistAgent (contacts, deals, messages, cargo_offers, тощо)
- Стан MCP-бази (comments, groups)

Якщо не очищати — наступний сценарій працює на "забрудненому" стані: старі контакти, угоди, повідомлення впливають на результат.

### Інструмент `tg_test_cleanup`

Новий MCP-tool який виконує повне очищення між сценаріями.

```python
@mcp.tool()
async def tg_test_cleanup(
    clear_telegram: bool = True,
    clear_db: bool = True,
    groups: list[int] | None = None,
    keep_contacts: bool = False
) -> str:
    """Clean up after a test scenario.

    clear_telegram — delete test messages from TG groups and DMs (both accounts).
    clear_db — reset LogistAgent test database to seed state.
    groups — list of group_ids to clean (None = all test groups).
    keep_contacts — if True, keep base test contacts but remove deals/messages.
    """
```

### Що очищає `tg_test_cleanup`

#### В Telegram (clear_telegram=True):

```
Для кожного акаунту (A і B):
    1. Тестові групи:
       → Видалити всі повідомлення відправлені акаунтами A і B
         (через tg_delete для кожного message_id)

    2. DM з акаунтом C (LogistAgent):
       → Видалити повідомлення відправлені акаунтами A і B
       → Повідомлення від акаунту C НЕ видаляються MCP
         (LogistAgent повинен мати свій механізм очищення)

    3. Канал перевізників:
       → Видалити тестові пости (якщо були опубліковані)
```

#### В тестовій БД LogistAgent (clear_db=True):

```sql
-- Видалити тестові дані (порядок важливий через FK)
DELETE FROM deal_events WHERE deal_id IN (SELECT id FROM deals WHERE notes LIKE '%[TEST]%');
DELETE FROM deal_documents WHERE deal_id IN (SELECT id FROM deals WHERE notes LIKE '%[TEST]%');
DELETE FROM driver_contacts WHERE deal_id IN (SELECT id FROM deals WHERE notes LIKE '%[TEST]%');
DELETE FROM messages WHERE created_at > :scenario_start_time;
DELETE FROM deals WHERE notes LIKE '%[TEST]%';
DELETE FROM cargo_offers WHERE raw_text LIKE '%[TEST]%' OR created_at > :scenario_start_time;
DELETE FROM price_records WHERE created_at > :scenario_start_time;
DELETE FROM unprocessed_messages WHERE processed = 0;

-- Якщо keep_contacts=False:
DELETE FROM contact_routes WHERE contact_id IN (SELECT id FROM contacts WHERE first_name LIKE 'Тест-%');
DELETE FROM contact_phones WHERE contact_id IN (SELECT id FROM contacts WHERE first_name LIKE 'Тест-%');
DELETE FROM contact_psychology WHERE contact_id IN (SELECT id FROM contacts WHERE first_name LIKE 'Тест-%');
DELETE FROM contact_reliability WHERE contact_id IN (SELECT id FROM contacts WHERE first_name LIKE 'Тест-%');
DELETE FROM contacts WHERE first_name LIKE 'Тест-%';

-- Відновити seed-дані (якщо keep_contacts=True)
-- → Перезапис contact_reliability.overall_reliability до початкових значень
-- → Скидання contact_psychology до дефолтних
```

#### В MCP-базі:

```sql
DELETE FROM comments WHERE sent_at > :scenario_start_time;
```

### Процедура очищення (крок за кроком)

```
tg_test_cleanup(clear_telegram=True, clear_db=True)
        │
        ▼
    1. Зберегти timestamp початку поточного сценарію
    2. Зібрати message_ids з MCP-бази (що були відправлені під час тесту)
        │
        ▼
    3. Telegram cleanup (account A):
       a. Видалити повідомлення з тестових груп
       b. Видалити DM повідомлення з акаунтом C
        │
        ▼
    4. Telegram cleanup (account B):
       a. Видалити повідомлення з тестових груп
       b. Видалити DM повідомлення з акаунтом C
        │
        ▼
    5. DB cleanup (LogistAgent test DB):
       a. Видалити записи створені після scenario_start_time
       b. Відновити seed-контакти (якщо keep_contacts=True)
        │
        ▼
    6. MCP DB cleanup:
       a. Видалити записи з comments
        │
        ▼
    7. Повернути результат: {"deleted_tg_messages": N, "deleted_db_rows": M, "status": "clean"}
```

### Додаткові тестові інструменти

#### `tg_test_send_dm` — DM від тестового акаунту

```python
@mcp.tool()
async def tg_test_send_dm(
    peer_tg_id: int,
    text: str,
    account: str = "a"
) -> str:
    """Send a direct message to a specific user.
    peer_tg_id — Telegram user ID of the recipient (e.g., LogistAgent's tg_id).
    account — 'a' or 'b'."""
```

Відрізняється від `tg_comment` тим що:
- Працює з DM (peer-to-peer), а не групами
- Приймає `tg_id` замість `group_id`
- Логує повідомлення з позначкою `[TEST-DM]` для cleanup

#### `tg_test_read_dm` — Читання DM

```python
@mcp.tool()
async def tg_test_read_dm(
    peer_tg_id: int,
    limit: int = 10,
    account: str = "a"
) -> str:
    """Read direct messages with a specific user.
    peer_tg_id — Telegram user ID (e.g., LogistAgent's tg_id).
    Returns last N messages in the conversation."""
```

#### `tg_test_seed_db` — Заповнення тестової БД

```python
@mcp.tool()
async def tg_test_seed_db(
    scenario: str = "default"
) -> str:
    """Seed the LogistAgent test database with predefined test data.
    scenario — 'default' (base contacts + routes + prices)
             | 'negotiation' (+ active deals)
             | 'verification' (+ driver_contacts)
             | 'empty' (clean slate)."""
```

Seed-набори:

| Scenario | Що заповнює |
|----------|-------------|
| `default` | 8 тестових контактів, маршрути, ціни, курси валют, agent_config |
| `negotiation` | default + 3 активні угоди (prospecting, negotiating, agreed) |
| `verification` | negotiation + driver_contacts для тестів верифікації |
| `empty` | Тільки agent_config та exchange_rates |

### Порядок виконання сценаріїв

```
┌──────────────────────────────────────────────────────┐
│ Сценарій SEC-1                                       │
│                                                      │
│  1. tg_test_cleanup()                ← ОЧИЩЕННЯ     │
│  2. tg_test_seed_db(scenario="negotiation")  ← SEED │
│  3. [Кроки сценарію SEC-1]          ← ТЕСТ          │
│  4. [Валідація результатів]          ← ПЕРЕВІРКА     │
│                                                      │
├──────────────────────────────────────────────────────┤
│ Сценарій SEC-2                                       │
│                                                      │
│  1. tg_test_cleanup()                ← ОЧИЩЕННЯ     │
│  2. tg_test_seed_db(scenario="default")      ← SEED │
│  3. [Кроки сценарію SEC-2]          ← ТЕСТ          │
│  4. [Валідація результатів]          ← ПЕРЕВІРКА     │
│                                                      │
├──────────────────────────────────────────────────────┤
│ ...наступні сценарії...                              │
└──────────────────────────────────────────────────────┘
```

---

## 8. Заборонено

- ❌ Тестувати на реальних контактах (тільки тестові акаунти A, B)
- ❌ Надсилати повідомлення в реальні логістичні групи з тестовими даними
- ❌ Зберігати реальні API credentials в config.example.json
- ❌ Запускати тести без попередньо створеного тестового середовища
- ❌ Видаляти реальну БД при тестуванні (використовувати logist_test.db)
- ❌ Запускати наступний сценарій без `tg_test_cleanup()` попереднього
- ❌ Використовувати акаунт C (LogistAgent) через MCP (він працює окремо)

---

Сценарії тестування: див. `Docs/Test_scenarios/` (файли 01-08)
MCP-сервер: див. `TG_mcp_clon/`
Схема БД: див. 05_DATABASE.md
Робочі процеси: див. 06_WORKFLOWS.md
