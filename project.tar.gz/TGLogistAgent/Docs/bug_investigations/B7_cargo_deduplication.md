# B-7: Дублікати cargo_offers

## ROOT CAUSE

Ні Router, ні GroupMonitor не перевіряють існування cargo_offer з таким же `source_msg_id` перед створенням. Обидва безумовно вставляють нові записи.

---

## Де виникають дублікати

### 1. Router._try_early_parse_cargo() (router.py:244-287)

```python
if not result.match or result.details is None:
    return None

# ❌ ВІДСУТНЯ перевірка: чи існує cargo_offer з таким tg_msg_id

offer = await self._create_cargo_offer_from_parse(...)  # Завжди створює новий
```

### 2. GroupMonitor._handle_new_message() (group_monitor.py:130-165)

Аналогічно — створює CargoOffer без дедуплікації.

### 3. DB Schema — немає UNIQUE constraint

```sql
CREATE TABLE IF NOT EXISTS cargo_offers (
    source_msg_id       INTEGER,        -- ❌ NOT UNIQUE
    source_group        TEXT,           -- ❌ Немає composite unique
);
```

### 4. CargoRepository — немає методу пошуку по source_msg_id

В `cargo_repo.py` є тільки `get_by_id()`, `get_open_offers()` — жодного методу для перевірки дублікатів.

---

## Сценарії дублікації

1. **Telethon Event Replay** — мережеві retry доставляють event двічі → 2 cargo_offers
2. **Double Processing** — Router (DM) + GroupMonitor (група) обробляють одне повідомлення
3. **Batch Reprocessing** — unprocessed_messages повторно обробляються

---

## План виправлення (4 зміни, ~20 рядків)

### 1. Додати метод в CargoRepository

**Файл:** `src/db/repositories/cargo_repo.py`

```python
async def get_by_source_msg_id(
    self, source_msg_id: int, source_group: str = "dm"
) -> CargoOffer | None:
    """Check if cargo offer with this source_msg_id already exists."""
    row = await self._fetch_one(
        "SELECT * FROM cargo_offers WHERE source_msg_id = ? AND source_group = ?",
        (source_msg_id, source_group),
    )
    return CargoOffer(**row) if row else None
```

### 2. Додати перевірку в Router

**Файл:** `src/agent/router.py`, метод `_try_early_parse_cargo()`, після перевірки `result.match`

```python
# Deduplication check
existing = await self._cargo.get_by_source_msg_id(tg_msg_id, "dm")
if existing:
    logger.warning("cargo_offer already exists for msg_id=%d, skipping", tg_msg_id)
    return existing  # Повернути існуючий для контексту Responder
```

### 3. Додати перевірку в GroupMonitor

**Файл:** `src/parser/group_monitor.py`, після визначення group_name

```python
existing = await self._cargo_repo.get_by_source_msg_id(event.message.id, group_name)
if existing:
    logger.warning("cargo_offer already exists for msg_id=%d, skipping", event.message.id)
    return
```

### 4. Додати UNIQUE constraint в schema

**Файл:** `src/db/schema.sql`

```sql
CREATE UNIQUE INDEX IF NOT EXISTS idx_cargo_source_msg
ON cargo_offers(source_msg_id, source_group)
WHERE source_msg_id IS NOT NULL;
```

---

## Файли для змін

| Файл | Зміна |
|------|-------|
| `src/db/repositories/cargo_repo.py` | Новий метод `get_by_source_msg_id()` |
| `src/agent/router.py` | Перевірка перед створенням в `_try_early_parse_cargo()` |
| `src/parser/group_monitor.py` | Перевірка перед створенням в `_handle_new_message()` |
| `src/db/schema.sql` | UNIQUE INDEX на (source_msg_id, source_group) |
