# Bug B-1: update_deal_status FK Constraint Failed

## Summary
Responder returns `cargo_offer_id` instead of `deal_id` in `update_deal_status` action, causing `sqlite3.IntegrityError: FOREIGN KEY constraint failed` when trying to update deals table.

**Root Cause:** Actions containing `deal_id` references are NOT validated before execution. Only the top-level `output.deal_id` is validated.

**Severity:** CRITICAL — blocks deal status updates via AI actions

---

## Full Call Chain

### WF-4: DM Processing Flow

1. **src/agent/router.py:83** - `_handle_dm(event)`
   - Receives incoming DM message
   - Extracts sender info, creates/loads contact

2. **src/agent/router.py:131** - `_context.for_responder(contact.id, text)`
   - Calls `ContextAssembler.for_responder()` to build AI context

3. **src/agent/context.py:34-91** - `ContextAssembler.for_responder()`
   - Loads active deals from DB: deal_summaries
   - Loads open cargo offers from DB: open_offers
   - **Context passed to Responder contains TWO types of IDs:**
     - `active_deals[].deal_id` — correct UUIDs of existing deals
     - `open_cargo_offers[].cargo_offer_id` — UUIDs of cargo offers (NOT deals)

4. **src/agent/responder.py:25-44** - `Responder.generate_response(context)`
   - Formats context dict as user message
   - Sends to Claude API with system prompt from `prompts/agent_codex.md`
   - **Responder prompt examples show both types of IDs in context**
   - AI may confuse which ID type belongs to which action

5. **src/agent/router.py:146** - Result of Responder: `output = ResponderOutput`
   - Contains `output.deal_id` (top-level) and `output.actions[]`
   - Each action may have `action.deal_id` field

6. **src/agent/router.py:166-168** - Validation (INCOMPLETE!)
   - Only validates top-level `output.deal_id`
   - Does NOT validate `deal_id` in individual actions

7. **src/agent/router.py:198-202** - `_execute_actions(output.actions, contact_id, output.deal_id)`
   - Executes each action from the list

8. **src/agent/router.py:244-265** - `_execute_single_action()` for `update_deal_status`
   - Uses action.deal_id directly without validation
   - If action.deal_id is a cargo_offer_id, it won't exist in deals table

9. **src/db/repositories/deal_repo.py:66-81** - `DealRepository.update_status()`
   - Attempts to update with non-existent ID
   - Tries to insert event with non-existent deal_id

10. **src/db/repositories/deal_repo.py:146-156** - `DealRepository.add_event()`
    - Tries to insert event with deal_id parameter
    - FK constraint: deal_id must exist in deals table

11. **src/db/repositories/base.py:52-61** - `BaseRepository._insert()`
    - Executes INSERT query with FK constraint check
    - SQLite FK check fails
    - Error raised: `sqlite3.IntegrityError: FOREIGN KEY constraint failed`

### Database Schema Context

From src/db/schema.sql:

- deals table: Primary table with id TEXT PRIMARY KEY
- deal_events table: Has FK to deals.id (NOT NULL REFERENCES deals(id))
- cargo_offers table: Separate with its own id column

The constraint violation happens because:
- cargo_offer_id (UUID from cargo_offers table) is passed as deal_id
- System tries to insert event with deal_id = cargo_offer_id
- SQLite checks: Does this cargo_offer_id exist in deals.id? NO
- FK constraint fails

---

## ROOT CAUSE Analysis

### Why AI confuses cargo_offer_id with deal_id

1. **Context Structure in agent_codex.md Responder Prompt**
   - Prompt receives JSON with BOTH types of IDs
   - АКТИВНІ УГОДИ section with deal_id
   - ВІДКРИТІ ВАНТАЖИ section with cargo_offer_id

2. **No Clear Field Naming Distinction in Responder Output**
   - ResponderAction model has generic deal_id field
   - Both action types reference it
   - No semantic distinction

3. **Responder Prompt Examples Show Both Types**
   - agent_codex.md line 62 shows update_deal_status with deal_id
   - Context lists cargo_offer_id only in open_cargo_offers section
   - AI sees deal_id field needed, looks at context, may pick wrong ID

4. **Validation Gap**
   - Only output.deal_id is validated (line 166 in router.py)
   - Each action's nested deal_id is NOT validated before use

### Example Scenario Where Bug Occurs

MESSAGE: "Договір про перевезення від Вроцлава до Київа — узгоджено ціну"

CONTEXT provided to Responder:
- active_deals with deal_id: 0b1a75c0-b682-4478-9db4-151fabc21e86
- open_cargo_offers with cargo_offer_id: cf7ff24e-b3c9-46f7-a125-513d6feac455

AI MAY RETURN (INCORRECTLY):
- action.deal_id = cf7ff24e-b3c9-46f7-a125-513d6feac455 (WRONG!)

EXECUTION FLOW:
- router._execute_single_action(action)
- deals.update_status(cf7ff24e..., agreed)
- deals.add_event(deal_id=cf7ff24e...)
- INSERT into deal_events
- FK CHECK fails: cf7ff24e does not exist in deals.id
- sqlite3.IntegrityError: FOREIGN KEY constraint failed

---

## Fix Plan

### Fix 1: Validate action.deal_id before execution (CRITICAL)

File: src/agent/router.py
Lines: 260-265

Current code:
```python
elif atype == "update_deal_status":
    if action.deal_id and action.new_status:
        await self._deals.update_status(
            action.deal_id,
            action.new_status,
        )
```

Fixed code:
```python
elif atype == "update_deal_status":
    if action.deal_id and action.new_status:
        valid_deal_id = await self._validate_deal_id(action.deal_id)
        if valid_deal_id:
            await self._deals.update_status(
                valid_deal_id,
                action.new_status,
            )
        else:
            logger.warning(
                "update_deal_status action ignored: deal_id=%s not found",
                action.deal_id,
            )
```

Rationale: Validates that action.deal_id actually references an existing deal.

---

### Fix 2: Validate all action deal_id references (IMPORTANT)

Apply the same pattern to other actions that reference deal_id:

File: src/agent/router.py

For escalate action (lines 289-304):
```python
elif atype == "escalate":
    target_deal = action.deal_id or deal_id
    if target_deal:
        valid_deal_id = await self._validate_deal_id(target_deal)
        if valid_deal_id:
            await self._deals.set_escalated(
                valid_deal_id,
                action.reason or "unknown",
            )
```

---

### Fix 3: Improve Responder Prompt (RECOMMENDED)

File: prompts/agent_codex.md
Line: 62

Add clarification:
```
IMPORTANT: deal_id must be from АКТИВНІ УГОДИ (active_deals), 
NOT from ВІДКРИТІ ВАНТАЖИ (open_cargo_offers)
```

---

## Testing Strategy

### Unit Test for Validation

Test that update_deal_status validates deal_id before execution:
- Create action with cargo_offer_id instead of deal_id
- Execution should NOT crash with FK constraint error
- Should log warning and skip action
- Verify no UPDATE was attempted

### Integration Test for Full Flow

Test Router validation of deal_ids:
- Create a deal in DB
- Create a cargo offer in DB
- Create output where AI confused cargo_offer_id with deal_id
- Execute actions
- Verify deal was NOT updated (validation rejected cargo.id)

---

## Error Location Reference

Error occurs at:
  src/agent/router.py:262 → _execute_single_action()
    → src/db/repositories/deal_repo.py:78 → update_status()
      → src/db/repositories/deal_repo.py:148 → add_event()
        → src/db/repositories/base.py:59 → _insert()
          → FK constraint check fails

---

## Files to Modify

1. src/agent/router.py - Add validation to update_deal_status and escalate actions
2. prompts/agent_codex.md - Add explicit guidance to Responder
3. tests/test_agent/ - Add unit/integration tests for validation
