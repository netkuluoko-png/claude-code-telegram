# B-2: carrier_price не зберігається (update_price handler)

## 1. Ланцюг виклику

```
WF-4: DM Message Processing (router.py)
├─ Line 103: contact = await self._contacts.get_by_tg_id(sender_tg_id)
│            → Отримуємо UUID контакту (наприклад: "c-uuid-123")
│
├─ Line 131: ctx = await self._context.for_responder(contact.id, text)
│  (context.py, Line 41-86)
│  ├─ Line 41: slice_task = self._contacts.get_contact_slice(contact_id)
│  │           → ContactSlice: name, type, reliability, routes...
│  │           → ВАЖЛИВО: contact UUID НЕ включається в ContactSlice!
│  │
│  └─ Line 86: "contact": contact_slice.model_dump()
│              → JSON для AI: {"name": "Кіріл", "type": "carrier", ...}
│              → БЕЗ поля "id"
│
├─ Responder отримує контекст з ім'ям (без UUID)
│  → AI повертає: {"type": "update_price", "contact_id": "Кіріл", ...}
│
└─ Line 198: await self._execute_actions(output.actions, contact.id, output.deal_id)
   └─ Line 267-287: atype == "update_price"
      ├─ Line 280: contact_id=contact_id  // від __handle_dm (ПРАВИЛЬНИЙ UUID)
      ├─ action.contact_id = "Кіріл"     // ІГНОРУЄТЬСЯ
      ├─ Line 287: await self._contacts.add_price_record(record)
      │            → Записує в price_records ✅
      └─ ❌ deal.carrier_price НЕ оновлюється
         ❌ deal.margin НЕ обраховується
```

## 2. ROOT CAUSE (3 проблеми)

### ISSUE #1: AI не отримує contact UUID в контексті

**Файл:** `src/models/contact.py`, лінія 110-122
**Проблема:** `ContactSlice` містить `name`, `type`, `reliability` але **НЕ містить `id`** (UUID)
**Наслідок:** AI не знає UUID контакту, повертає ім'я

### ISSUE #2: Router ігнорує action.contact_id

**Файл:** `src/agent/router.py`, лінії 267-287
**Проблема:** Код завжди використовує `contact_id` від `__handle_dm()`, ніколи не перевіряє `action.contact_id`
**Наслідок:** Навіть якби AI повернула UUID, його б ігнорували

### ISSUE #3: update_price не оновлює deal.carrier_price

**Файл:** `src/agent/router.py`, лінії 267-287
**Проблема:** Action тільки записує в `price_records`, ніколи не оновлює `deal.carrier_price`
**Наслідок:** deal.carrier_price = NULL, deal.margin = NULL

---

## 3. План виправлення

### 3.1. Передати contact_id в контекст AI

**Файл:** `src/models/contact.py`, лінія 110-122

```python
# БУЛО:
class ContactSlice(BaseModel):
    name: str
    type: ContactType
    reliability: int
    # ... решта полів

# СТАТИ:
class ContactSlice(BaseModel):
    id: str  # ← НОВЕ ПОЛЕ
    name: str
    type: ContactType
    reliability: int
    # ... решта полів
```

**Файл:** `src/db/repositories/contact_repo.py`, лінія ~347

```python
# БУЛО:
return ContactSlice(
    name=contact.first_name or "Невідомий",
    type=contact.type,
    ...
)

# СТАТИ:
return ContactSlice(
    id=contact.id,  # ← ДОДАТИ
    name=contact.first_name or "Невідомий",
    type=contact.type,
    ...
)
```

### 3.2. Оновити update_price handler в Router

**Файл:** `src/agent/router.py`, лінії 267-287

```python
elif atype == "update_price":
    if action.price is not None and action.route:
        # Резолвити contact_id
        target_contact_id = contact_id  # fallback від __handle_dm
        if action.contact_id:
            resolved = await self._contacts.get_by_id(action.contact_id)
            if resolved:
                target_contact_id = resolved.id
            else:
                logger.warning(
                    "update_price: could not resolve contact_id=%s, using current",
                    action.contact_id,
                )
        
        parts = action.route.split("→")
        route_from = parts[0].strip() if parts else ""
        route_to = parts[1].strip() if len(parts) > 1 else ""
        
        record = PriceRecord(
            id=new_id(),
            contact_id=target_contact_id,
            route_from=route_from,
            route_to=route_to,
            container_type=None,
            price=action.price,
            currency=action.currency or "EUR",
            source="message",
        )
        await self._contacts.add_price_record(record)
        
        # НОВЕ: Оновити deal.carrier_price якщо є deal
        target_deal_id = action.deal_id or deal_id
        if target_deal_id:
            deal = await self._deals.get_by_id(target_deal_id)
            if deal and deal.carrier_contact_id == target_contact_id:
                await self._deals.update_prices(
                    target_deal_id,
                    carrier_price=action.price,
                )
                logger.info(
                    "Updated deal %s: carrier_price=%.2f %s",
                    target_deal_id, action.price, action.currency or "EUR",
                )
```

### 3.3. Додати метод update_prices в DealRepository

**Файл:** `src/db/repositories/deal_repo.py`

Перевірити чи існує метод `update_prices`. Якщо ні — додати:

```python
async def update_prices(
    self, deal_id: str, carrier_price: float | None = None
) -> None:
    """Update carrier_price and recalculate margin."""
    deal = await self.get_by_id(deal_id)
    if not deal:
        return
    
    updates: dict[str, Any] = {"updated_at": utcnow()}
    if carrier_price is not None:
        updates["carrier_price"] = carrier_price
        if deal.customer_price:
            updates["margin"] = deal.customer_price - carrier_price
    
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    await self._db.execute(
        f"UPDATE deals SET {set_clause} WHERE id = ?",
        (*updates.values(), deal_id),
    )
    await self._db.commit()
```

### 3.4. Оновити промпт

**Файл:** `prompts/agent_codex.md`, лінія ~65

```markdown
# БУЛО:
- {"type": "update_price", "contact_id": "...", "price": число, "currency": "EUR", "route": "..."}

# СТАТИ:
- {"type": "update_price", "contact_id": "UUID контакту з ПРОФІЛЬ.id", "price": число, "currency": "EUR", "route": "Місто1→Місто2", "deal_id": "UUID угоди якщо є"}
  → Зберігає ціну + оновлює carrier_price/margin якщо є deal_id
```

---

## 4. Файли для змін

| Файл | Лінії | Операція |
|------|-------|----------|
| `src/models/contact.py` | 110-122 | Додати `id: str` до `ContactSlice` |
| `src/db/repositories/contact_repo.py` | ~347 | Передати `contact.id` при створенні `ContactSlice` |
| `src/agent/router.py` | 267-287 | Резолвити `action.contact_id` + оновити `deal.carrier_price` |
| `src/db/repositories/deal_repo.py` | новий метод | `update_prices()` якщо не існує |
| `prompts/agent_codex.md` | ~65 | Уточнити що `contact_id` = UUID з контексту |

---

## 5. Тестовий сценарій

1. Customer: cargo offer 1700€ Гданськ→Одеса
2. Carrier (Кіріл): "Можу за 1600€"
3. Очікувано після виправлення:
   - `price_records`: запис з contact_id = UUID Кіріла ✅
   - `deal.carrier_price` = 1600.0 ✅
   - `deal.margin` = 1700 - 1600 = 100.0 ✅

```sql
SELECT carrier_price, margin FROM deals WHERE id = '...';
-- Очікувано: carrier_price=1600.0, margin=100.0
```
