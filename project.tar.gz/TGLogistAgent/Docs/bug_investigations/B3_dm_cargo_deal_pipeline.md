# Bug Investigation B-3: DM cargo → deal pipeline broken

**Status**: OPEN  
**Severity**: CRITICAL  
**Date**: 2026-03-31  

## Summary

When a customer sends a cargo offer directly via DM, the deal creation fails:

```
WARNING src.agent.router: create_deal action missing cargo_offer_id
```

Responder generates `create_deal` action WITHOUT `cargo_offer_id`. Router rejects it (line 387-389 in router.py).

---

## Root Cause: Two Problems

### Problem 1: DM flow runs Responder BEFORE creating cargo_offer

**Group flow (WF-1)** - WORKS:
1. GroupMonitor reads group message
2. Parser analyzes → creates CargoOffer in DB
3. Matcher triggered with cargo_offer_id
4. Deal created with cargo_offer_id ✅

**DM flow (WF-4)** - BROKEN:
1. Router reads DM
2. Responder generates response (doesn't know this is a cargo offer!)
3. Responder returns action create_deal WITHOUT cargo_offer_id ❌
4. Router rejects action (missing field)
5. Deal NOT created

Problem: Responder runs before Parser. So Responder doesn't know about the new cargo offer.

### Problem 2: ParserDetails validation fails

When Router tries to parse DM afterwards, it hits error:

```
Pydantic validation failed for ParserOutput
details.route_from: Input should be a valid string [input_value=None]
```

Message "Побутова техніка, 1800€, Олег" has no route. Parser returns:
- match=False (correct)
- details.route_from=None (but field is defined as str, not str|None!)
- Validation fails

Result: No cargo_offer created.

---

## Full Call Chains

### WF-1: Group (WORKING) - group_monitor.py:57-204

```
Group Message
  ↓
1. Parser.analyze(text)
   └─ Returns ParserOutput with match=true
2. IF match=true:
   ├─ CREATE CargoOffer in DB
   │  └─ id, source_group, sender_contact_id, route_from/to
   └─ TRIGGER on_new_cargo(offer)
      └─ Matcher.evaluate(offer)
         └─ Returns action create_deal WITH cargo_offer_id
            └─ Deal created ✅
```

### WF-4: DM (BROKEN) - router.py:83-226

```
DM Message
  ↓
1. Responder.generate_response(context)
   ├─ Context has open_cargo_offers from DB
   └─ Returns ResponderOutput with actions
      └─ Action create_deal but cargo_offer_id=None ❌
2. Execute actions
   ├─ create_deal missing cargo_offer_id
   └─ Router rejects ❌
3. LATER (too late):
   ├─ Try Parser.analyze(text)
   └─ Parser validation fails (route_from=None)
      └─ No cargo_offer created

Result: No deal, no cargo_offer
```

---

## Fix Strategy

### Fix 1: Make ParserDetails.route_from Optional

File: src/models/ai_outputs.py line 68

Change:
```python
route_from: str  # Current: required
```

To:
```python
route_from: str | None = None  # Optional
```

Why: Parser sometimes returns match=False with no route info. Allow it.

Risk: LOW - Code already checks for None before using.

---

### Fix 2: Parse cargo_offer BEFORE Responder

File: src/agent/router.py

Reorder _handle_dm():
```python
async def _handle_dm(self, event):
    # ... setup ...
    
    # NEW: Parse early
    new_cargo_offer = await self._try_parse_cargo_offer_from_dm(
        text, contact.id, event.message.id
    )
    
    # Context has cargo_offer now
    ctx = await self._context.for_responder(contact.id, text)
    
    # Responder sees cargo_offer_id
    output = await self._responder.generate_response(ctx)
    
    # Execute actions (cargo_offer_id available)
    await self._execute_actions(output.actions, contact.id, output.deal_id)
    
    # Trigger Matcher
    if new_cargo_offer and self._on_new_cargo:
        await self._on_new_cargo(new_cargo_offer)
```

Risk: MEDIUM - Reorders control flow, needs testing.

---

### Fix 3: Update agent_codex.md

Add note about cargo offers in DM. No code impact.

---

## Files to Modify

1. src/models/ai_outputs.py (1 line)
2. src/agent/router.py (add method + reorder)
3. prompts/agent_codex.md (doc - optional)

---

Investigation completed: 2026-03-31
