# B-4: Водійські дані не зберігаються (відсутній action type)

## 1. Поточний стан

### Підтримувані Action Types (src/models/ai_outputs.py)

Клас `ResponderAction` підтримує типи:
- `"none"` | `"create_contact"` | `"update_deal_status"` | `"update_price"`
- `"escalate"` | `"notify_operator"` | `"forward_to_other_party"`
- `"send_to_carrier_channel"` | `"update_profile"` | `"ask_clarification"` | `"create_deal"`

**Немає `type="save_driver"`**.

### Структура таблиці driver_contacts (src/db/schema.sql)

```sql
CREATE TABLE IF NOT EXISTS driver_contacts (
    id                  TEXT PRIMARY KEY,
    deal_id             TEXT REFERENCES deals(id),
    carrier_contact_id  TEXT REFERENCES contacts(id),
    driver_name         TEXT NOT NULL,
    driver_phone        TEXT,
    driver_tg_id        INTEGER,
    driver_tg_username  TEXT,
    verified            INTEGER DEFAULT 0,
    created_at          TEXT DEFAULT (datetime('now'))
);
```

### DealRepository (src/db/repositories/deal_repo.py) — методи вже є

- `async def add_driver(self, driver: DriverContact)` (лінія 212-224)
- `async def get_driver_by_phone(self, phone: str)` (лінія 226-235)
- `async def get_driver_by_tg_id(self, tg_id: int)` (лінія 237-242)
- `async def verify_driver(self, driver_id: str)` (лінія 244-246)

### Router (src/agent/router.py)

В `_execute_single_action` (лінія 244-320) **немає обробника для водійських даних**.

### Промпт (prompts/agent_codex.md, лінія 59-72)

Список actions не включає `save_driver`.

---

## 2. ROOT CAUSE

### Сценарій бага

1. Перевізник надсилає: "Водій Петро, +380987654321"
2. Responder аналізує → записує в `internal_note`: "Водій Петро, +380987654321 — зафіксувати"
3. **Але НЕ створює action `save_driver`** — бо такого типу немає в промпті
4. Router виконує інші дії, дані водія **ігноруються**
5. `driver_contacts` = порожня
6. Верифікація (WF-11) не може перевірити водія

### Чому це сталося

1. `prompts/agent_codex.md` не має інструкцій про `save_driver`
2. `ResponderAction` не має полів для водійських даних
3. `Router._execute_single_action()` не обробляє `save_driver`
4. `DealRepository` методи існують, але їх ніхто не викликає

---

## 3. План виправлення

### 3.1. Додати поля в ResponderAction

**Файл**: `src/models/ai_outputs.py`

```python
class ResponderAction(BaseModel):
    """Single action from Responder output."""
    type: str
    # ... існуючі поля ...
    
    # НОВІ ПОЛЯ ДЛЯ ВОДІЯ:
    driver_name: str | None = None
    driver_phone: str | None = None
    driver_tg_id: int | None = None
    driver_tg_username: str | None = None
```

### 3.2. Додати обробник в Router

**Файл**: `src/agent/router.py`, метод `_execute_single_action()` (після лінії ~320)

```python
elif atype == "save_driver":
    if action.driver_name:
        # Знайти активний deal для цього контакту
        deal_id = action.deal_id
        if not deal_id:
            # Спробувати знайти deal по carrier_contact_id
            deals = await self._deals.get_active_by_contact(contact.id)
            if deals:
                deal_id = deals[0].id
        
        if not deal_id:
            logger.warning("save_driver: no deal found for contact %s", contact.tg_id)
            return
        
        driver = DriverContact(
            id=str(uuid4()),
            deal_id=deal_id,
            carrier_contact_id=contact.id,
            driver_name=action.driver_name,
            driver_phone=action.driver_phone,
            driver_tg_id=action.driver_tg_id,
            driver_tg_username=action.driver_tg_username,
            verified=False,
        )
        await self._deals.add_driver(driver)
        logger.info(
            "Driver saved: name=%s, phone=%s, deal=%s",
            action.driver_name, action.driver_phone, deal_id,
        )
    else:
        logger.warning("save_driver: missing driver_name")
```

### 3.3. Додати інструкцію в промпт

**Файл**: `prompts/agent_codex.md` (до списку actions)

Додати action:
```markdown
- {"type": "save_driver", "deal_id": "...", "driver_name": "...", "driver_phone": "...", "driver_tg_id": null}
```

Додати секцію:
```markdown
ВОДІЙ:
- Коли перевізник дає ім'я та контакт водія — зберегти через save_driver
- Приклад: "Водій Петро, +380987654321" → action save_driver
- Водій буде верифікований через WF-11
```

### 3.4. Інтеграція з верифікацією (WF-11)

**Вже готово** — `src/agent/verification.py` шукає driver_contacts по tg_id або phone.
Якщо дані збережені через `save_driver`, верифікація працюватиме автоматично.

---

## 4. Вплив на компоненти

| Компонент | Стан | Потрібна зміна |
|-----------|------|----------------|
| Action Model (`ai_outputs.py`) | Немає полів | Додати 4 поля |
| Router Handler (`router.py`) | Немає обробника | Додати elif "save_driver" |
| Промпт (`agent_codex.md`) | Немає інструкції | Додати action + секцію |
| DealRepository | Вже готовий | Не потребує змін |
| VerificationAgent | Вже готовий | Працюватиме коли дані збережені |
| DB Schema | Таблиця існує | Не потребує змін |

---

## 5. Тестовий сценарій

1. Перевізник: "Водій Олег, +380501234567"
2. Очікувано:
   - AI створює `{"type": "save_driver", "driver_name": "Олег", "driver_phone": "+380501234567"}`
   - Router зберігає в driver_contacts
   - `inspect_query("SELECT * FROM driver_contacts")` → 1 запис
3. Верифікація: WF-11 по телефону → verdict=verified_driver
