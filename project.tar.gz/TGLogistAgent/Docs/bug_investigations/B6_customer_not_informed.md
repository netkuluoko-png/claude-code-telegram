# B-6: Customer Not Informed About Deal Agreement

## Problem Statement

When a carrier confirms an agreement (deal status = "agreed"), the customer is NOT informed. Instead customer sees "подбираємо варіант" even when deal is already agreed.

Examples from testing (2026-03-31):
- Customer: "Дай контакти перевізника" -> Response: "контакти надаю після підтвердження угоди — зараз підбираємо варіант"
- Customer: "Ти бот?" -> Response: "вже в роботі — як буде перевізник, одразу повідомлю"
- Both responses WRONG because deal status is already "agreed"

---

## Technical Investigation

### 1. Action Handler Flow (VERIFIED WORKING)

File: src/agent/action_handlers.py:383-440

The _handle_forward() method IS working correctly:
- Resolves deal by deal_id
- Finds "other party" contact
- Sends message via Telethon
- Logs action

Evidence from logs (2026-03-31 13:51:41):
[INFO] src.agent.router: Forwarded message to contact d86a9094-eb8a-431e-85eb-b00965c200ff (deal 54562561...)

Status: WORKING CORRECTLY

### 2. ROOT CAUSE: Responder Not Generating forward_to_other_party Action

File: src/agent/responder.py and prompts/agent_codex.md

PROBLEM: prompts/agent_codex.md DOES NOT HAVE instructions to:
- Forward to customer when deal status changes to "agreed"
- Inform customer when carrier confirms deal
- Update deal_status to "agreed" when carrier confirms

Current prompt (line 68) only DESCRIBES the action capability:
- {"type": "forward_to_other_party", "deal_id": "...", "message": "..."}

But does NOT tell AI:
- WHEN to forward
- TO WHOM to forward
- WHAT MESSAGE to send

Status: MISSING CRITICAL INSTRUCTIONS

### 3. Context Assembly (Working But Incomplete)

File: src/agent/context.py:34-91

Context includes:
- active_deals with statuses
- contact profile
- recent messages

BUT AI is NEVER TOLD:
- "When deal status='agreed', you MUST inform customer"
- "Check if deal status CHANGED since last message"
- "When deal='agreed', forward details to customer"

Status: PROVIDES DATA but NO BUSINESS LOGIC INSTRUCTIONS

### 4. Customer Context Visibility (Working)

File: src/agent/context.py:285

Customer CAN see their own deal with status in active_deals.
AI CAN read deal status in context.

BUT: AI has NO INSTRUCTION to use this to inform customer.

Status: DATA VISIBLE but NO INSTRUCTION TO USE IT

### 5. Router Flow (Correct But Missing Logic)

File: src/agent/router.py:218-240

Flow is: Receive DM -> Assemble context -> Call Responder -> Execute actions

BUT there's NO check that says:
"Before calling Responder, if deal status changed to 'agreed', force notification"

Status: EXECUTES ACTIONS but NO BUSINESS LOGIC TRIGGER

---

## Root Cause Summary

Component | Status | Issue
---|---|---
action_handlers._handle_forward() | WORKING | Sends messages correctly
Router execution | WORKING | Executes actions from Responder
Context assembly | WORKING | Provides deal status
Responder prompt | BROKEN | NO instructions for deal notifications
Responder AI | WORKING AS DESIGNED | Follows incomplete prompt

THE ROOT CAUSE:

prompts/agent_codex.md LACKS CRITICAL BUSINESS RULES:
1. No rule to check deal status changes
2. No rule to auto-notify customer on agreement
3. No rule to inform customer when already agreed

---

## Real-World Flow Breakdown

### What Happens Now (WRONG):

Carrier: "1500€ поїду"
  -> update_price action
  -> forward_to_other_party action (by luck)
  -> NO update_deal_status to "agreed"

Carrier: "Добре, беру. Водій Петро"
  -> save_driver action
  -> forward_to_other_party action
  -> NO update_deal_status to "agreed"

Customer: "Дай контакти"
  -> AI sees deal status but has NO INSTRUCTION to mention it
  -> Response: "шукаємо варіант" (WRONG)

### What Should Happen (CORRECT):

Carrier: "1500€ поїду"
  -> update_price action
  -> update_deal_status to "agreed"
  -> forward_to_other_party with agreement confirmation to customer

Carrier: "Водій Петро"
  -> save_driver action
  -> forward_to_other_party with driver details to customer

Customer: "Дай контакти"
  -> AI recognizes deal status="agreed"
  -> Response: "Угода готова! Перевізник Кіріл, 1500€, водій Петро"

---

## Why forward_to_other_party Logs Appear

Logs show successful forwards (13:51:41, 13:52:12):
Forwarded message to contact d86a9094...

This happens ACCIDENTALLY:
1. Carrier sends message
2. Context includes customer in active_deals
3. BY LUCK, AI forwards to customer
4. _handle_forward() executes

But customer is NOT guaranteed to receive meaningful confirmation.

---

## The Fix

### Primary Fix: Update prompts/agent_codex.md

Add section about deal agreement notifications:

```
ІНФОРМУВАННЯ ПРО УГОДУ:
- Коли deal переходить в "agreed" -> ОБОВ'ЯЗКОВО інформуй другу сторону
- Коли замовник питає про статус угоди яка "agreed" -> СКАЖИ що угода готова
- Коли перевізник підтверджує -> СКАЖИ замовнику: перевізник, ціна, водій (якщо є)
- Якщо deal="agreed" та contact питає статус -> НЕ кажи "шукаємо" — скажи "угода готова"

FORWARD ТА STATUS CHANGE:
- Коли update_deal_status -> "agreed", ЗАВЖДИ додай forward_to_other_party з confirmation
- Якщо deal="agreed" та contact питає про деталі, генеруй forward з інформацією
```

### Secondary Fix (Optional): Router Business Logic

Add pre-Responder check in router._handle_dm() to detect deal status changes and auto-inject notifications.

---

## Files Needing Changes

1. PRIMARY: prompts/agent_codex.md
   - Add rules for deal agreement notifications
   - Add rules for deal status transitions
   - Add rules for customer queries on agreed deals

2. SECONDARY: src/agent/router.py
   - Optional: add automatic notification layer before Responder

3. REFERENCE: src/agent/action_handlers.py (NO CHANGES NEEDED - working correctly)

4. REFERENCE: src/agent/context.py (NO CHANGES NEEDED - provides required data)

---

## Test Cases

### TC-1: Carrier Agrees -> Customer Notified
Precondition: Deal status="negotiating"
Step: Carrier says "1500€ поїду"
Expected: Deal status changes to "agreed", customer receives agreement message

### TC-2: Customer Queries After Agreement -> Gets Confirmation
Precondition: Deal status="agreed"
Step: Customer says "Дай контакти"
Expected: Response shows "угода готова", NOT "шукаємо варіант"

### TC-3: Carrier Provides Driver -> Customer Notified
Precondition: Deal status="agreed"
Step: Carrier says "Водій Петро, +380987654321"
Expected: Driver saved, customer receives driver confirmation

### TC-4: No False Notifications
Precondition: Deal status="prospecting"
Step: Carrier sends price inquiry
Expected: Customer NOT notified (still negotiating)

---

## Summary

WORKING: Action handlers, message forwarding, deal status tracking
BROKEN: AI prompt lacks business logic rules for notifications
FIX: Update prompts/agent_codex.md with explicit deal notification rules

The system is architecturally sound. The bug is purely in the AI prompt.

---

## Additional Technical Details

### Data Flow Analysis

1. **Carrier sends agreement:** "1500€ поїду"
2. **Router._handle_dm() flow:**
   - Saves incoming message ✓
   - Calls context_assembler.for_responder() ✓
   - Passes context to Responder.generate_response() ✓
   - Executes returned actions ✓

3. **Responder receives context with:**
   - active_deals (including current deal with status)
   - But NO instruction: "check deal status and inform customer if changed"

4. **Responder generates actions:**
   - update_price action (if price is new) ✓
   - forward_to_other_party action (if AI randomly decides to forward) ✓
   - update_deal_status action (MISSING - no instruction)

5. **Router executes actions:**
   - ActionExecutor._execute_single_action() ✓ (works correctly)
   - _handle_forward() sends message via Telethon ✓

### Why This Works For Carrier But Not For Customer

**Carrier perspective (works partially):**
- Carrier sends offer/agreement
- AI sees new information from carrier
- AI generates response + forward action
- Forward happens (by luck or design)

**Customer perspective (fails):**
- Customer asks "where is carrier?" or "what's the status?"
- AI sees deal status in context (active_deals)
- BUT: AI has no instruction to focus on deal status
- AI generates generic response without considering deal status
- No forward action generated
- Customer gets "still searching" response (WRONG)

### Code Path for forward_to_other_party

1. Responder must include action in ResponderOutput.actions list
2. Router calls self._action_executor.execute_actions()
3. ActionExecutor._execute_single_action() dispatches to _handle_forward()
4. _handle_forward() resolves:
   - deal_id from action.deal_id or output.deal_id
   - other_contact_id from deal.carrier_contact_id or deal.customer_contact_id
   - other_contact from database
5. Sends message: await self._client.send_message(other_contact.tg_id, action.message)
6. Logs action

Current status: All code paths work. The issue is Responder never generates the action.

### Why Logs Show Some Forwards

From logs (13:51:41, 13:52:12), forwards ARE executed successfully.

This happens when:
- Carrier sends message about price/agreement
- Responder's context shows active deal
- By luck/partial design, forward action is generated
- _handle_forward() executes

But this is NOT consistent or guaranteed for all scenarios (especially customer queries).

### Database Schema Insights

The deal table has all necessary fields:
- customer_contact_id (who to notify)
- carrier_contact_id (who to notify)
- status (already "agreed" after carrier confirmation)

No schema changes needed. The data exists in DB and context.

---

## Conclusion

**BUG DIAGNOSIS:** PURELY PROMPT-BASED

No code refactoring needed. All infrastructure works.

The fix is to tell the AI (via prompt) what business logic rules to follow:

1. "When you see deal status='agreed' in active_deals, customer NEEDS to know"
2. "When carrier sends agreement, generate update_deal_status + forward actions"
3. "When customer asks about status on an 'agreed' deal, tell them immediately"

**ESTIMATED FIX TIME:** 15-30 minutes to update prompts/agent_codex.md

**RISK LEVEL:** Low (only affects prompt, not code infrastructure)

**TEST COMPLEXITY:** Medium (need to verify all deal status transitions)
