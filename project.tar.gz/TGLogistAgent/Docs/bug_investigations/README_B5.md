# Bug B5 Investigation: Role Confusion in Agent Responses

## Quick Navigation

This directory contains a complete investigation of LogistAgent's role confusion bug.

### Documents (in reading order)

1. **B5_SUMMARY.txt** (57 lines)
   - Quick overview of issue, root cause, and solution
   - Read this first (5 min read)

2. **B5_role_confusion_in_responses.md** (342 lines)
   - Complete technical investigation
   - Detailed analysis of code flow
   - Evidence and verification tests
   - Full appendix with technical details
   - Read this second (20 min read)

3. **B5_PROMPT_FIX.md** (126 lines)
   - Exact text to add to prompts/agent_codex.md
   - Installation instructions
   - Testing checklist
   - Read before implementing the fix

## The Issue (30-second summary)

Agent sends role-agnostic responses to carriers and customers, causing confusion:
- Carrier gets: "По вантажу є перевізник..." (sounds like 3rd party reference to himself)
- Customer gets: Messages formatted for carriers

## The Root Cause

`prompts/agent_codex.md` receives `contact.type` in JSON context but never instructs Claude to use it.

## The Fix

Add ~50 lines to `prompts/agent_codex.md` with:
- Explicit role identification rules
- Different response patterns for carrier vs customer
- Concrete examples of correct/incorrect responses
- Warnings against common mistakes

## Implementation

1. Read B5_SUMMARY.txt (understand the issue)
2. Read B5_role_confusion_in_responses.md (verify analysis)
3. Review B5_PROMPT_FIX.md (exact text to add)
4. Update prompts/agent_codex.md following B5_PROMPT_FIX.md
5. Test with carriers and customers
6. Monitor logs for improvements

## Evidence

✓ Infrastructure is correct (context.py passes contact.type)
✓ Code is correct (deal_repo.py handles roles correctly)
✗ Prompt is incomplete (agent_codex.md doesn't use contact.type)

This is a **prompt engineering issue, not a code bug**.

## Impact

- **Severity:** High (trust, clarity, negotiation affected)
- **Effort:** Low (prompt-only, ~30 lines)
- **Expected Result:** 90%+ reduction in role confusion

## Status

✓ Investigation Complete
✓ Root Cause Identified
✓ Solution Designed
→ Ready for Implementation

## Key Files

- `prompts/agent_codex.md` (needs update)
- `src/agent/context.py` (already correct)
- `src/agent/responder.py` (already correct)
- `src/db/repositories/deal_repo.py` (already correct)

## Questions?

See the detailed investigation document (B5_role_confusion_in_responses.md) for:
- Context flow diagrams
- Code evidence
- Technical analysis
- Test scenarios
- Verification procedures

---

**Investigation Date:** 2026-03-31  
**Investigation Status:** Complete  
**Recommended Action:** Implement fix as described in B5_PROMPT_FIX.md
