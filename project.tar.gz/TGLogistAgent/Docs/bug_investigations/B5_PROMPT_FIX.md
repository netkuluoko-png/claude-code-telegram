# B5: Exact Prompt Fix Instructions

This document shows the EXACT text to add to `prompts/agent_codex.md`

## Current File Structure

Lines 1-10: Basic intro and СТИЛЬ section
Lines 11-20: ЗАБОРОНИ section  
Lines 21-26: КОМУНІКАЦІЯ section
Lines 27-36: ПЕРШИЙ КОНТАКТ section
Lines 37-40: ВЕРИФІКАЦІЯ section
Lines 38-40: КОНТЕКСТ section
Lines 41-57: ЗАДАЧА section + JSON response format
Lines 59-73: Possible actions list

## INSERTION POINT

Add the following **AFTER line 10** (after the СТИЛЬ section ends):

---

## TEXT TO INSERT

```markdown
АДАПТАЦІЯ ПО РОЛЯХ КОНТАКТУ:
Дивись на поле "type" у розділі "ПРОФІЛЬ КОНТАКТУ" (contact.type):
- type: "carrier" → перевізник, проклав маршрут, має машину
- type: "customer" → замовник вантажу, потребує доставку
- type: "both" або "unknown" → визнач з контексту розмови

ДЛЯ CARRIER (перевізник):
  • Звертайся ДО НЬОГО другою особою: "Ви пропонуєте", "Ваша ставка", "Ви можете взяти"
  • Про вантаж: "Потребує перевезення 40HC...", "Якщо можеш взяти..."
  • Його цінова пропозиція: "Записав: 1500 EUR по факту. На яку дату готовий?"
  • Чужа цінова пропозиція: "Є ще пропозиції від інших" (але рідко!)
  • ЗАБОРОНЕ: говорити "є перевізник...", "інший перевізник..." 
    (звучить як 3-я особа, а це він сам, адресе!)

ДЛЯ CUSTOMER (замовник):
  • Говори про його вантаж: "Ваш вантаж", "У вас потребує", "Ви запропонували"
  • Про перевізників: "Знайшов перевізника", "Перевізник пропонує 1500 EUR"
  • Для узгодження: "Підтверджуєте цю ставку?", "Узгодили умови?"
  • ЗАБОРОНЕ: "ви пропонуєте ставку", "ви беріте" (customer замовляє, не пропонує)

ПРИКЛАДИ (ДУЖЕ ВАЖЛИВО ДЛЯ РОЗУМІННЯ):

Приклад 1: Петро (type="carrier") каже "1500 євро, можу взяти, по факту вивантаження"
  ✓ ПРАВИЛЬНО: "Записав, Петро: 1500 EUR за Гданськ→Київ (40HC), розрахунок по факту вивантаження. На яку дату потребує отправка?"
  ✗ НЕПРАВИЛЬНО: "Є перевізник з ставкою 1500 EUR. Підтверджуємо?" (чому 3-я особа якщо це Петро?!)

Приклад 2: Марія (type="customer") питає "Скільки коштує перевезення 40HC з Гданська до Києва на 5 квітня?"
  ✓ ПРАВИЛЬНО: "Знайшов перевізника з ставкою 1500 EUR за Гданськ→Київ (40HC). Підтверджуєте цю ціну?"
  ✗ НЕПРАВИЛЬНО: "Записав твою ставку 1500 EUR" (customer не пропонує ставку, замовляє доставку!)

Приклад 3: Forward для customer про offer від Петро (carrier)
  ✓ ПРАВИЛЬНО: "Перевізник пропонує 1500 EUR для вашого вантажу (40HC, Гданськ→Київ). Розрахунок по факту. Підтверджуєте?"
  ✗ НЕПРАВИЛЬНО: "Перевізник підтвердив вантаж" (неясно, що точно підтвердив — ціна? маршрут? дату?)

ЛОГІКА АДАПТАЦІЇ:
Якщо type="carrier" — розраховуєш машину/маршрут/дату, тому:
  → Звертайся про його можливості: "Ви можете", "Ваша ставка"
Якщо type="customer" — розраховуєш доставку вантажу, тому:
  → Звертайся про його вантаж: "Ваш вантаж", "Ви запропонували"
```

---

## VERIFICATION

After adding this section:

1. Check that it comes AFTER line 10 (СТИЛЬ section)
2. Check that it comes BEFORE line 11 (original ЗАБОРОНИ section, now shifted down)
3. The section should be ~50 lines
4. Formatting should use markdown (heading `АДАПТАЦІЯ...` and bullet points)

## Line Count Change

Original file: ~84 lines
After insertion: ~134 lines

## Why This Fix Works

1. **Explicit instruction**: "Дивись на поле 'type'" — tells Claude to look at the field
2. **Clear rules**: Separate bullets for each role
3. **Examples**: Shows exactly what's right and wrong
4. **Logic**: Explains WHY different roles need different approaches
5. **Warnings**: Highlights common mistakes (3rd person references)

## Expected Result

After this change:
- ✓ Carrier gets: "Записав: 1500 EUR" (direct address)
- ✓ Customer gets: "Знайшов перевізника" (3rd person about carrier, natural)
- ✓ No more confusion about who's saying what
- ✓ Tone matches audience

## Testing the Fix

Test these scenarios AFTER making the change:

1. Send carrier a message about their offer
   - Expected: Direct address "Ви", "Ваша ставка"
   - Verify: No third-person "є перевізник" about them

2. Send customer info about available carriers
   - Expected: Third-person "Перевізник пропонує"
   - Verify: Customer understands we found someone, not that they proposed

3. Forward carrier's offer to customer
   - Expected: Clear "Перевізник пропонує X за ваш вантаж"
   - Verify: Customer knows what carrier is offering

---

## Implementation Checklist

- [ ] Read current prompts/agent_codex.md
- [ ] Locate end of СТИЛЬ section (line 10)
- [ ] Insert this section
- [ ] Verify formatting (markdown bullets, headings)
- [ ] Test with carriers (expect different response)
- [ ] Test with customers (expect different response)
- [ ] Monitor logs for improvements
- [ ] Iterate if needed

