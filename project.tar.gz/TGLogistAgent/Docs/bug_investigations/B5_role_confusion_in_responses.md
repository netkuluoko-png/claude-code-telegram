# Bug B5: Role Confusion in Agent Responses

**Status:** Investigation Complete  
**Severity:** High  
**Date:** 2026-03-31  

## Issue Summary

Responder generates role-agnostic responses, causing confusion when sent to specific parties:

- **Carrier receives:** "По вантажу 40HC Гданськ→Київ є перевізник зі ставкою 1500 EUR" (sounds like third party)
- **Customer receives:** Messages phrased for carriers, not appropriate for customers

**Root Cause:** `prompts/agent_codex.md` receives `contact.type` in context but never instructs Claude to use it.

## Investigation Results

### 1. Prompt Analysis

**Present in prompts/agent_codex.md:**
- Role identification rules for new contacts
- Guidelines about what NOT to do
- Action types for role updates

**Missing (ROOT CAUSE):**
- NO instructions for role-specific response adaptation
- NO examples showing how to write for carrier vs customer  
- NO explicit rule to adapt based on contact.type

### 2. Context Transmission

`src/agent/context.py` - `for_responder()` method correctly passes:

```python
{
    "contact": contact_slice.model_dump(),  # Includes contact.type
    "active_deals": formatted_deals,
    "open_cargo_offers": formatted_offers,
    "recent_messages": formatted_messages,
    "new_message": new_message,
}
```

ContactSlice model includes `type: ContactType` field ("customer" or "carrier").

**Result:** The context DOES include contact.type in JSON passed to Claude, but the prompt doesn't instruct Claude to use it.

### 3. How forward_to_other_party Works

`src/agent/action_handlers.py` lines 383-440:
- Correctly identifies "the other party" from deal
- Correctly sends message to the other contact
- Action works properly

Issue: The message was drafted without knowing target audience.

### 4. Example Scenario

1. Кіріл (carrier) sends: "1500 євро можу, якщо оплата по факту"
   → context.contact.type = "carrier"

2. Router calls Responder with context including contact.type="carrier"

3. Prompt has NO instruction: "Since this is a CARRIER, respond appropriately to a carrier"

4. Responder generates generic: "По вантажу 40HC є перевізник зі ставкою 1500 EUR"
   ❌ Wrong: Sounds like reference to another carrier, not Кіріл himself

5. Message sent to Кіріл → confusion

## Root Cause Summary

| Component | Has Role? | Uses It? | Status |
|-----------|-----------|----------|--------|
| ContextAssembler | ✓ | N/A | OK |
| Responder prompt | ✓ | ✗ | **CRITICAL** |
| ActionHandlers | ✓ | ✓ | OK |

**ROOT CAUSE:** Prompt receives contact.type but doesn't use it for response adaptation.

## Fix Strategy

### Primary Fix: Update prompts/agent_codex.md

Add new section after line 39 ("КОНТЕКСТ:"):

```
РОЛЬ КОНТАКТУ — КРИТИЧНО ВАЖЛИВО:
Дивись на поле "type" у ПРОФІЛІ КОНТАКТУ:
- type: "carrier" → перевізник, пропонує машину/маршрут
- type: "customer" → замовник, має вантаж

Якщо type="carrier":
  ✓ Звертайся ДО НЬОГО: "Ви пропонуєте", "Ваша ставка", "Ви можете"
  ✓ Про вантаж: "Потребує перевезення 40HC...", "Якщо можеш взяти..."
  ✓ Про його ціну: "Записав: 1500 EUR по факту"
  ✗ НЕ говори: "є перевізник...", "інший перевізник..."

Якщо type="customer":
  ✓ Про його вантаж: "У вас є вантаж", "Ваша доставка"
  ✓ Про перевізників: "Знайшов перевізника", "Перевізник пропонує 1500 EUR"
  ✓ Для узгодження: "Підтверджуєте цю ставку?"
  ✗ НЕ говори: "ви пропонуєте ставку" (customer не пропонує ціну)

ПРИКЛАДИ:

Петро (carrier) каже "1500 євро, по факту"
  ✓ ПРАВИЛЬНО: "Записав: 1500 EUR за Гданськ→Київ, по факту. Дата коли готовий?"
  ✗ НЕПРАВИЛЬНО: "Є перевізник з ставкою 1500" (третя особа)

Марія (customer) питає "Яка ціна на 40HC?"
  ✓ ПРАВИЛЬНО: "Знайшов перевізника з ставкою 1500 EUR. Підтверджуєте?"
  ✗ НЕПРАВИЛЬНО: "Записав твою ставку 1500" (customer не пропонує)
```

### Secondary Fix: Response Logging

Update `src/agent/responder.py` in `_format_context_as_user_message()` to explicitly mark contact role:

```python
contact = context.get("contact", {})
if contact:
    contact_type = contact.get("type", "unknown")
    parts.append(f"CURRENT CONTACT ROLE: {contact_type}")
    parts.append("")
```

This makes role awareness explicit in Claude's input.

## Verification Tests

### Test 1: Carrier Input
- Contact: Петро (type="carrier")
- Input: "1500 євро за 40HC Гданськ-Київ, по факту вивантаження"
- Expected: "Записав: 1500 EUR для Гданськ→Київ (40HC), розрахунок по факту вивантаження. На яку дату потребує?"
- NOT: "Є перевізник з ставкою 1500 EUR"

### Test 2: Customer Input
- Contact: Марія (type="customer")
- Input: "Мені потребує перевезення 40HC з Гданська до Києва, 5 квітня"
- Expected: "Зрозумів, шукаю перевізника. Яка вага вантажу приблизно?"
- NOT: "Записав твою ставку" (customer doesn't offer price)

### Test 3: Forwarding Scenario
- Петро (carrier) offers 1500 EUR
- Forward to customer Марія
- Expected: "Перевізник пропонує 1500 EUR за ваш вантаж. Підтверджуєте?"
- NOT: "Перевізник підтвердив вантаж" (ambiguous)

## Implementation Checklist

1. ✓ Analyze issue (done - this document)
2. Update prompts/agent_codex.md with role-specific section
3. Update src/agent/responder.py logging (optional)
4. Create test scenarios for each role
5. Test with actual carriers and customers
6. Monitor logs for role-confusion patterns
7. Iterate based on real feedback

## Files Affected

- **PRIMARY:** `prompts/agent_codex.md` (add role-specific section)
- **SECONDARY:** `src/agent/responder.py` (improve logging)
- **REFERENCE:** `src/agent/context.py` (no changes needed)

## Conclusion

Infrastructure already supports role-aware responses. The issue is **prompt engineering** — the prompt doesn't instruct Claude to use the contact.type field that's already available.

Fix is straightforward:
1. Add explicit role identification section to prompt
2. Provide clear rules for each role
3. Include concrete examples
4. Warn against common mistakes

Expected result: 90%+ reduction in role-confusion issues.

---

## APPENDIX: Detailed Technical Analysis

### Context Flow Diagram

```
User Message (DM)
       ↓
Router._handle_dm()
       ↓
ContextAssembler.for_responder(contact_id, text)
    - Gets contact_slice (includes contact.type)
    - Gets active_deals (lightweight summaries)
    - Gets open_cargo_offers
    - Gets recent messages
       ↓
Formats as user message with JSON:
{
    "contact": {
        "id": "...",
        "name": "Петро",
        "type": "carrier",          ← KEY FIELD (ignored by prompt!)
        "reliability": 75,
        ...
    },
    "active_deals": [...],
    "recent_messages": [...]
}
       ↓
Responder.__init__() loads system prompt from prompts/agent_codex.md
       ↓
Responder.generate_response(context)
    - Calls Claude API with:
      * system_prompt: agent_codex.md (DOESN'T mention "use contact.type")
      * user_message: formatted context JSON (HAS contact.type)
       ↓
Claude generates ResponderOutput
    - response_text (role-agnostic, problem is here!)
    - actions
    - confidence
       ↓
Router executes actions
    - If forward_to_other_party: finds other party and sends message
       (message was drafted without knowing target!)
```

### Why It's a Prompt Problem, Not Code Problem

**The code is correct:**
- ✓ Context includes contact.type
- ✓ Contact profile is properly structured
- ✓ DealSummary correctly shows "my_price" (relative to contact role)
- ✓ forward_to_other_party correctly identifies other party

**The prompt is incomplete:**
- ✗ Never says "Check contact.type and adapt accordingly"
- ✗ Treats all contacts generically
- ✗ No examples of role-specific responses
- ✗ No warnings about third-person references to the contact

### Evidence from Context Analysis

In `src/db/repositories/deal_repo.py` lines 281-298, `get_deal_summaries_for_contact()` correctly:

```python
is_customer = d.customer_contact_id == contact_id
my_price = d.customer_price if is_customer else d.carrier_price
```

This shows code correctly handles role-awareness! But the **prompt doesn't know to do the same**.

### Why Logs Don't Show the Problem Clearly

Logs only record:
- module=responder
- response_text (the problematic output)
- confidence score

But they DON'T log:
- contact.type (the available info ignored)
- which role we're addressing

Adding role info to logs would make this obvious:
```
[INFO] module=responder: Contact type=carrier, Response text="По вантажу..."
       ↑ Would immediately show mismatch
```

---

## APPENDIX: Exact Prompt Modification

### Current agent_codex.md (line 1-10):

```
Ти — логістичний диспетчер. Працюєш з контейнерними перевезеннями, переважно імпорт Польща→Україна. Ти посередник між замовниками і перевізниками.

СТИЛЬ:
- Максимум 1-2 речення
- Тільки суть, нуль води
- Мова контакту (укр/рус/суржик — як пише контакт)
- Ніколи не вибачайся
- Ніколи не пояснюй як ти знаєш інформацію
- Якщо не знаєш — кажи "уточню" або постав ОДНЕ питання
```

### Add AFTER line 10 (new section):

```
АДАПТАЦІЯ ПО РОЛЯХ КОНТАКТУ:
Завжди читай поле "type" у розділі "ПРОФІЛЬ КОНТАКТУ":
- Якщо type = "carrier" → розраховуєш машину/маршрут
- Якщо type = "customer" → розраховуєш доставку вантажу
- Якщо type = "both" → дивись з контексту, що релевантно

ДЛЯ CARRIER (перевізник):
  • Звертайся ДО НЬОГО другою особою: "Ви", "Вам", "Ваша ставка"
  • Про вантаж: "Потребує перевезення 40HC...", "На якій машині їздиш?"
  • Його пропозиція ціни: "Записав: 1500 EUR по факту. Готово."
  • Чужа пропозиція ціни: "Є ще пропозиції від інших" (рідко!)
  • ЗАБОРОНЕ: "є перевізник", "інший перевізник" (звучить як 3-я особа, а це ОН!)

ДЛЯ CUSTOMER (замовник вантажу):
  • Про його ситуацію: "Ваш вантаж", "У вас потребує", "Ви запропонували"
  • Про перевізників: "Знайшов перевізника", "Перевізник пропонує 1500 EUR"
  • Для узгодження: "Підтверджуєте цю ставку?", "Узгодили умови?"
  • ЗАБОРОНЕ: "ви пропонуєте ставку" (customer не пропонує, а замовляє)

ПРИКЛАДИ (ДУЖЕ ВАЖЛИВО):

Ситуація: Петро (type="carrier") каже "1500 євро, можу взяти контейнер, по факту вивантаження"
  ✓ ПРАВИЛЬНО: "Записав, Петро: 1500 EUR за Гданськ→Київ (40HC), розрахунок по факту. На яку дату потребує?"
  ✗ НЕПРАВИЛЬНО: "є перевізник з ставкою 1500 EUR. Підтверджуємо?" (чому 3-я особа? це ПЕТРО ж!)

Ситуація: Марія (type="customer") питає "Скільки коштує перевезення 40HC з Гданська до Києва?"
  ✓ ПРАВИЛЬНО: "Знайшов перевізника з ставкою 1500 EUR. Підтверджуєте цю ціну?"
  ✗ НЕПРАВИЛЬНО: "Записав твою ставку 1500 EUR" (customer не пропонує ставку, а замовляє доставку!)

Ситуація: Forward для customer про Петро's offer
  ✓ ПРАВИЛЬНО: "Перевізник пропонує 1500 EUR для вашого вантажу. Розрахунок по факту. Підтверджуєте?"
  ✗ НЕПРАВИЛЬНО: "Перевізник підтвердив вантаж" (неясно, що він підтвердив)
```

### Modified section after "КОНТЕКСТ:" (line 39):

Remove or keep original, but ADD before it:

```
ВАЖЛИВО: Контекст включає ПРОФІЛЬ КОНТАКТУ з полем "type".
Це ОСНОВНЕ для адаптації відповіді. Читай його в першу чергу!
```

---

## Why This Matters

This bug affects:
1. **Trust**: Users feel agent doesn't understand roles
2. **Clarity**: Messages are ambiguous about who's agreeing to what
3. **Negotiation**: Tone is wrong for the audience
4. **Scalability**: As more deals overlap, confusion multiplies

The fix is simple (update prompt) but impact is high (much better UX).

