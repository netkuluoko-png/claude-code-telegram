"""Interactive Telethon session authorization.

Run: uv run python scripts/auth_session.py
"""

import asyncio

from telethon import TelegramClient

API_ID = 34064872
API_HASH = "53c040857041d166022d559fd55f499b"
SESSION_NAME = "logist_agent_session"
PHONE = "+380972774744"


async def main() -> None:
    client = TelegramClient(SESSION_NAME, API_ID, API_HASH)
    await client.start(phone=PHONE)
    me = await client.get_me()
    print(f"Authorized as: {me.first_name} (id={me.id})")
    print(f"Session saved: {SESSION_NAME}.session")
    await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
