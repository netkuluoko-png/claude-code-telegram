"""
Telegram MCP server — multi-account (A/B) with test tools for LogistAgent.
"""
import asyncio
import json
from mcp.server.fastmcp import FastMCP

import database as db
import telegram_client as tg
from inspector import register_tools as register_inspector_tools

mcp = FastMCP("tg-mcp", instructions=(
    "Telegram MCP tools for LogistAgent testing. "
    "Two accounts: account='a' (customer) and account='b' (carrier). "
    "Use tg_test_send_dm / tg_test_read_dm for DM with LogistAgent. "
    "Use inspect_* tools to view agent DB state, logs, and AI traces."
))

# Register DB/log inspector tools
register_inspector_tools(mcp)


# ── Auth ──────────────────────────────────────────────────────

@mcp.tool()
async def tg_setup(api_id: str, api_hash: str,
                   phone: str = "", account: str = "a",
                   channel_username: str = "") -> str:
    """Configure Telegram API credentials for account (a or b)."""
    config = tg.load_config()
    if "accounts" not in config:
        config["accounts"] = {}
    if account not in config["accounts"]:
        config["accounts"][account] = {}
    acc = config["accounts"][account]
    acc["api_id"] = api_id
    acc["api_hash"] = api_hash
    acc["session_file"] = f"tg_session_{account}"
    if phone:
        acc["phone"] = phone
    if channel_username:
        config["channel_username"] = channel_username.lstrip("@")
    tg.save_config(config)
    await db.init_db()
    return f"Account {account} configured. Use tg_auth_send_code to authenticate."


@mcp.tool()
async def tg_auth_send_code(phone: str, account: str = "a") -> str:
    """Send auth code. account='a' or 'b'."""
    phone_code_hash = await tg.send_code(phone, account)
    config = tg.load_config()
    config[f"_{account}_phone"] = phone
    config[f"_{account}_hash"] = phone_code_hash
    tg.save_config(config)
    return f"Code sent to {phone} (account {account}). Use tg_auth_verify."


@mcp.tool()
async def tg_auth_verify(code: str, password: str = "", account: str = "a") -> str:
    """Verify auth code + optional 2FA. account='a' or 'b'."""
    config = tg.load_config()
    phone = config.get(f"_{account}_phone", "")
    phone_code_hash = config.get(f"_{account}_hash", "")
    if not phone:
        return f"Error: call tg_auth_send_code for account {account} first"
    result = await tg.sign_in(phone, code, phone_code_hash,
                              password=password or None, account=account)
    config.pop(f"_{account}_phone", None)
    config.pop(f"_{account}_hash", None)
    tg.save_config(config)
    return result


# ── Profile ───────────────────────────────────────────────────

@mcp.tool()
async def tg_profile(account: str = "a") -> str:
    """Get profile info. account='a' or 'b'."""
    return json.dumps(await tg.get_profile(account), ensure_ascii=False, indent=2)

@mcp.tool()
async def tg_set_bio(bio: str, account: str = "a") -> str:
    """Update bio. Max 70 chars."""
    if len(bio) > 70:
        return f"Error: {len(bio)} chars, max 70."
    return json.dumps(await tg.update_bio(bio, account), ensure_ascii=False)


# ── Groups/Channels ──────────────────────────────────────────

@mcp.tool()
async def tg_my_groups(limit: int = 100, account: str = "a") -> str:
    """List groups. account='a' or 'b'."""
    return json.dumps(await tg.get_my_groups(limit, account), ensure_ascii=False, indent=2)

@mcp.tool()
async def tg_my_channels(limit: int = 50, account: str = "a") -> str:
    """List channels. account='a' or 'b'."""
    return json.dumps(await tg.get_my_channels(limit, account), ensure_ascii=False, indent=2)

@mcp.tool()
async def tg_search_groups(query: str, limit: int = 20,
                           search_type: str = "all", account: str = "a") -> str:
    """Search public groups/channels."""
    return json.dumps(await tg.search_public(query, limit, search_type, account),
                      ensure_ascii=False, indent=2)

@mcp.tool()
async def tg_join(username_or_link: str, account: str = "a") -> str:
    """Join group/channel."""
    result = await tg.join_group(username_or_link, account)
    if result.get("success"):
        await db.init_db()
        await db.save_group(result["id"], result["title"], username_or_link, None)
    return json.dumps(result, ensure_ascii=False)

@mcp.tool()
async def tg_leave(channel_id: int, account: str = "a") -> str:
    """Leave group/channel."""
    return json.dumps(await tg.leave_channel(channel_id, account), ensure_ascii=False)

@mcp.tool()
async def tg_create_channel(title: str, about: str = "",
                            is_group: bool = False, account: str = "a") -> str:
    """Create channel or group (megagroup)."""
    return json.dumps(await tg.create_channel(title, about, megagroup=is_group, account=account),
                      ensure_ascii=False, indent=2)

@mcp.tool()
async def tg_set_channel_title(channel_id: int, title: str, account: str = "a") -> str:
    """Change channel/group title."""
    return json.dumps(await tg.set_channel_title(channel_id, title, account), ensure_ascii=False)

@mcp.tool()
async def tg_set_channel_description(channel_id: int, about: str, account: str = "a") -> str:
    """Change description."""
    return json.dumps(await tg.set_channel_description(channel_id, about, account), ensure_ascii=False)

@mcp.tool()
async def tg_set_channel_username(channel_id: int, username: str, account: str = "a") -> str:
    """Set public @username."""
    return json.dumps(await tg.set_channel_username(channel_id, username, account), ensure_ascii=False)

@mcp.tool()
async def tg_set_channel_photo(channel_id: int, photo_path: str, account: str = "a") -> str:
    """Set channel photo."""
    return json.dumps(await tg.set_channel_photo(channel_id, photo_path, account), ensure_ascii=False)

@mcp.tool()
async def tg_set_slow_mode(channel_id: int, seconds: int = 0, account: str = "a") -> str:
    """Set slow mode. 0=disable."""
    return json.dumps(await tg.set_channel_slow_mode(channel_id, seconds, account), ensure_ascii=False)

@mcp.tool()
async def tg_set_history_hidden(channel_id: int, hidden: bool = True, account: str = "a") -> str:
    """Hide history for new members."""
    return json.dumps(await tg.set_channel_history_hidden(channel_id, hidden, account), ensure_ascii=False)

@mcp.tool()
async def tg_create_invite(channel_id: int, title: str = "",
                           expire_hours: int = 0, usage_limit: int = 0,
                           request_needed: bool = False, account: str = "a") -> str:
    """Create invite link."""
    return json.dumps(await tg.create_invite_link(
        channel_id, title, expire_hours, usage_limit, request_needed, account),
        ensure_ascii=False, indent=2)

@mcp.tool()
async def tg_invite_links(channel_id: int, account: str = "a") -> str:
    """Get all invite links."""
    return json.dumps(await tg.get_invite_links(channel_id, account), ensure_ascii=False, indent=2)

@mcp.tool()
async def tg_delete_channel(channel_id: int, account: str = "a") -> str:
    """Delete channel/group. Irreversible!"""
    return json.dumps(await tg.delete_channel(channel_id, account), ensure_ascii=False)


# ── Messages ──────────────────────────────────────────────────

@mcp.tool()
async def tg_messages(group_id: int, limit: int = 20, account: str = "a") -> str:
    """Get recent messages from group."""
    return json.dumps(await tg.get_messages(group_id, limit, account), ensure_ascii=False, indent=2)

@mcp.tool()
async def tg_comment(group_id: int, text: str,
                     reply_to_id: int | None = None, account: str = "a") -> str:
    """Send message in group."""
    result = await tg.send_comment(group_id, text, reply_to_id, account)
    if result.get("success"):
        await db.init_db()
        await db.log_comment(group_id, "", result["message_id"], reply_to_id, text)
    return json.dumps(result, ensure_ascii=False)

@mcp.tool()
async def tg_post(channel_id: int, text: str, parse_mode: str = "md", account: str = "a") -> str:
    """Publish post to channel."""
    return json.dumps(await tg.publish_post(channel_id, text, parse_mode, account), ensure_ascii=False)

@mcp.tool()
async def tg_edit(channel_id: int, message_id: int, text: str,
                  parse_mode: str = "md", account: str = "a") -> str:
    """Edit message/post."""
    return json.dumps(await tg.edit_message(channel_id, message_id, text, parse_mode, account), ensure_ascii=False)

@mcp.tool()
async def tg_delete(channel_id: int, message_id: int, account: str = "a") -> str:
    """Delete message/post."""
    return json.dumps(await tg.delete_message(channel_id, message_id, account), ensure_ascii=False)


# ── Stats ─────────────────────────────────────────────────────

@mcp.tool()
async def tg_channel_stats(channel_username: str = "", account: str = "a") -> str:
    """Get subscriber count."""
    if not channel_username:
        config = tg.load_config()
        channel_username = config.get("channel_username", "")
        if not channel_username:
            return "Error: no channel configured."
    return json.dumps(await tg.get_channel_subscribers(channel_username, account),
                      ensure_ascii=False, indent=2)

@mcp.tool()
async def tg_stats(days: int = 7) -> str:
    """Get MCP comment statistics."""
    await db.init_db()
    stats = await db.get_stats(days)
    stats["groups_detail"] = (await db.get_commented_groups())[:20]
    stats["today_comments"] = await db.get_today_comment_count()
    return json.dumps(stats, ensure_ascii=False, indent=2)

@mcp.tool()
async def tg_disconnect(account: str = "all") -> str:
    """Disconnect. account='a', 'b', or 'all'."""
    await tg.disconnect(account)
    return f"Disconnected: {account}"


# ══════════════════════════════════════════════════════════════
# TEST TOOLS — DM + cleanup for LogistAgent testing
# ══════════════════════════════════════════════════════════════

@mcp.tool()
async def tg_test_send_dm(peer_tg_id: int, text: str, account: str = "a") -> str:
    """Send DM to a Telegram user (e.g. LogistAgent tg_id).
    account='a' (customer) or 'b' (carrier)."""
    return json.dumps(await tg.send_dm(peer_tg_id, text, account), ensure_ascii=False, indent=2)

@mcp.tool()
async def tg_test_read_dm(
    peer_tg_id: int, limit: int = 10, account: str = "a",
    after_id: int = 0, only_incoming: bool = False,
) -> str:
    """Read DM with a Telegram user. out=true means sent by this account.

    after_id: only messages with id > after_id (use sent message_id to get responses).
    only_incoming: filter to only messages FROM the peer (agent responses).
    """
    return json.dumps(
        await tg.read_dm(peer_tg_id, limit, account, after_id, only_incoming),
        ensure_ascii=False, indent=2,
    )

@mcp.tool()
async def tg_test_send_and_wait(
    peer_tg_id: int,
    text: str,
    account: str = "a",
    timeout_sec: int = 30,
    poll_interval_sec: float = 1.5,
) -> str:
    """Send DM and wait until the peer responds. Returns both sent and received messages.

    Polls every poll_interval_sec for a response. Returns after first response or timeout.
    Ideal for testing: send a message to LogistAgent and get its response in one call.
    """
    import time

    # 1. Send
    send_result = await tg.send_dm(peer_tg_id, text, account)
    if not send_result.get("success"):
        return json.dumps(
            {"success": False, "error": send_result.get("error")},
            ensure_ascii=False, indent=2,
        )

    sent_msg_id = send_result["message_id"]
    start = time.monotonic()

    # 2. Poll for response
    response = None
    while (time.monotonic() - start) < timeout_sec:
        await asyncio.sleep(poll_interval_sec)
        msgs = await tg.read_dm(peer_tg_id, limit=5, account=account)
        for msg in msgs:
            if "error" in msg:
                continue
            if msg.get("id", 0) > sent_msg_id and not msg.get("out"):
                response = msg
                break
        if response:
            break

    elapsed = round(time.monotonic() - start, 2)

    result = {
        "success": True,
        "sent": {
            "message_id": sent_msg_id,
            "text": text,
        },
        "response": response,
        "wait_time_sec": elapsed,
        "timed_out": response is None,
    }
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def tg_test_cleanup(agent_tg_id: int = 656774281,
                          test_group_id: int = 3560542856) -> str:
    """Clean up after test scenario.
    1. DM: deletes messages sent BY accounts A/B to agent (our messages only)
    2. Test group: deletes ALL messages (account A is admin)
    Does NOT touch other groups, channels, or chats.
    agent_tg_id — LogistAgent tg_id (default: 656774281).
    test_group_id — [TEST] Turbo-ИМПОРТ group id (default: 3560542856)."""
    deleted_dm = 0
    deleted_group = 0
    # 1. DM з агентом — тільки наші повідомлення
    for acc in ["a", "b"]:
        try:
            client = await tg.get_client(acc)
            me = await client.get_me()
            entity = await client.get_entity(agent_tg_id)
            msgs = await client.get_messages(entity, limit=100, from_user=me)
            if msgs:
                await client.delete_messages(entity, [m.id for m in msgs])
                deleted_dm += len(msgs)
        except Exception:
            pass
    # 2. Тестова група — ВСІ повідомлення (через адміна, акаунт A)
    try:
        client_a = await tg.get_client("a")
        group = await client_a.get_entity(test_group_id)
        msgs = await client_a.get_messages(group, limit=200)
        if msgs:
            await client_a.delete_messages(group, [m.id for m in msgs])
            deleted_group += len(msgs)
    except Exception:
        pass
    return json.dumps({
        "deleted_dm_messages": deleted_dm,
        "deleted_group_messages": deleted_group,
        "status": "clean"
    }, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    import sys
    import logging
    logging.disable(logging.CRITICAL)
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    mcp.run(transport="stdio")
