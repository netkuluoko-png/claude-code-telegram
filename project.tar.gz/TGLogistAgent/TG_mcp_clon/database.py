import aiosqlite
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "tg_farm.db")


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS groups (
                id INTEGER PRIMARY KEY,
                title TEXT,
                username TEXT,
                members_count INTEGER,
                category TEXT,
                joined_at TEXT,
                is_active INTEGER DEFAULT 1
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER,
                group_title TEXT,
                message_id INTEGER,
                reply_to_id INTEGER,
                text TEXT,
                sent_at TEXT,
                FOREIGN KEY (group_id) REFERENCES groups(id)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS daily_stats (
                date TEXT PRIMARY KEY,
                comments_count INTEGER DEFAULT 0,
                groups_commented INTEGER DEFAULT 0,
                new_groups_joined INTEGER DEFAULT 0
            )
        """)
        await db.commit()


async def log_comment(group_id: int, group_title: str, message_id: int,
                      reply_to_id: int | None, text: str):
    async with aiosqlite.connect(DB_PATH) as db:
        now = datetime.now().isoformat()
        await db.execute(
            "INSERT INTO comments (group_id, group_title, message_id, reply_to_id, text, sent_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (group_id, group_title, message_id, reply_to_id, text, now)
        )
        today = datetime.now().strftime("%Y-%m-%d")
        await db.execute(
            "INSERT INTO daily_stats (date, comments_count, groups_commented) "
            "VALUES (?, 1, 1) "
            "ON CONFLICT(date) DO UPDATE SET comments_count = comments_count + 1",
            (today,)
        )
        await db.commit()


async def save_group(group_id: int, title: str, username: str | None,
                     members_count: int | None, category: str = ""):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR REPLACE INTO groups (id, title, username, members_count, category, joined_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (group_id, title, username, members_count, category,
             datetime.now().isoformat())
        )
        await db.commit()


async def get_stats(days: int = 7) -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM daily_stats ORDER BY date DESC LIMIT ?", (days,)
        )
        daily = [dict(row) for row in await cursor.fetchall()]

        cursor = await db.execute("SELECT COUNT(*) as total FROM comments")
        total_comments = (await cursor.fetchone())[0]

        cursor = await db.execute(
            "SELECT COUNT(DISTINCT group_id) as total FROM comments"
        )
        total_groups = (await cursor.fetchone())[0]

        cursor = await db.execute(
            "SELECT COUNT(*) FROM comments WHERE sent_at >= datetime('now', '-1 hour')"
        )
        last_hour = (await cursor.fetchone())[0]

        return {
            "total_comments": total_comments,
            "total_groups_commented": total_groups,
            "comments_last_hour": last_hour,
            "daily_breakdown": daily
        }


async def get_commented_groups() -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("""
            SELECT group_id, group_title,
                   COUNT(*) as comment_count,
                   MAX(sent_at) as last_comment
            FROM comments
            GROUP BY group_id
            ORDER BY last_comment DESC
        """)
        return [dict(row) for row in await cursor.fetchall()]


async def get_today_comment_count() -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        today = datetime.now().strftime("%Y-%m-%d")
        cursor = await db.execute(
            "SELECT comments_count FROM daily_stats WHERE date = ?", (today,)
        )
        row = await cursor.fetchone()
        return row[0] if row else 0
