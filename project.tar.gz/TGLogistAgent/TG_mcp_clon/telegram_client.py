"""Multi-account Telethon client for MCP testing (accounts A and B)."""

import os
import json
from telethon import TelegramClient, functions, types
from telethon.tl.functions.channels import (
    JoinChannelRequest, GetFullChannelRequest,
    CreateChannelRequest, DeleteChannelRequest, LeaveChannelRequest,
    EditTitleRequest, UpdateUsernameRequest, EditPhotoRequest,
    TogglePreHistoryHiddenRequest, ToggleSlowModeRequest,
)
from telethon.tl.functions.messages import (
    EditChatAboutRequest, ImportChatInviteRequest,
    ExportChatInviteRequest, GetExportedChatInvitesRequest,
)
from datetime import datetime, timedelta, timezone
from telethon.errors import (
    FloodWaitError, ChatWriteForbiddenError, UserBannedInChannelError,
    SlowModeWaitError, ChannelPrivateError
)

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")
BASE_DIR = os.path.dirname(__file__)

_clients: dict[str, TelegramClient | None] = {"a": None, "b": None}
_config: dict = {}


def load_config() -> dict:
    global _config
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            _config = json.load(f)
    return _config


def save_config(config: dict):
    global _config
    _config = config
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def _get_account_config(account: str) -> dict:
    config = load_config()
    accounts = config.get("accounts", {})
    if account not in accounts:
        raise ValueError(f"Account '{account}' not configured.")
    return accounts[account]


async def get_client(account: str = "a") -> TelegramClient:
    global _clients
    if _clients.get(account) and _clients[account].is_connected():
        return _clients[account]

    acc = _get_account_config(account)
    session_file = acc.get("session_file", f"tg_session_{account}")
    session_path = os.path.join(BASE_DIR, session_file)

    client = TelegramClient(
        session_path, int(acc["api_id"]), acc["api_hash"],
        system_version="4.16.30-vxCUSTOM"
    )
    await client.connect()
    if not await client.is_user_authorized():
        raise ValueError(f"Account '{account}' not authorized. Use tg_auth_send_code.")
    _clients[account] = client
    return client


async def disconnect(account: str = "all"):
    global _clients
    targets = list(_clients.keys()) if account == "all" else [account]
    for key in targets:
        if _clients.get(key):
            await _clients[key].disconnect()
            _clients[key] = None


async def send_code(phone: str, account: str = "a") -> str:
    acc = _get_account_config(account)
    session_file = acc.get("session_file", f"tg_session_{account}")
    session_path = os.path.join(BASE_DIR, session_file)
    client = TelegramClient(
        session_path, int(acc["api_id"]), acc["api_hash"],
        system_version="4.16.30-vxCUSTOM"
    )
    await client.connect()
    result = await client.send_code_request(phone)
    _clients[account] = client
    return result.phone_code_hash


async def sign_in(phone: str, code: str, phone_code_hash: str,
                  password: str | None = None, account: str = "a") -> str:
    client = _clients.get(account)
    if not client:
        raise ValueError(f"Call send_code for account '{account}' first")
    try:
        await client.sign_in(phone, code, phone_code_hash=phone_code_hash)
    except Exception as e:
        if "Two-step" in str(e) or "password" in str(type(e).__name__.lower()):
            if not password:
                raise ValueError("2FA enabled. Provide password.")
            await client.sign_in(password=password)
        else:
            raise
    me = await client.get_me()
    return f"Account {account}: {me.first_name} (@{me.username or '-'}, id={me.id})"


# ── Profile ───────────────────────────────────────────────────

async def get_profile(account: str = "a") -> dict:
    client = await get_client(account)
    me = await client.get_me()
    full = await client(functions.users.GetFullUserRequest(me))
    return {
        "id": me.id, "first_name": me.first_name,
        "last_name": me.last_name or "", "username": me.username or "",
        "bio": full.full_user.about or "", "phone": me.phone or "",
        "account": account,
    }


async def update_bio(bio: str, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        await client(functions.account.UpdateProfileRequest(about=bio))
        return {"success": True, "bio": bio}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ── Groups/Channels ──────────────────────────────────────────

async def get_my_groups(limit: int = 100, account: str = "a") -> list[dict]:
    client = await get_client(account)
    dialogs = await client.get_dialogs(limit=limit)
    return [
        {"id": d.entity.id, "title": d.title,
         "username": getattr(d.entity, 'username', None),
         "members_count": getattr(d.entity, 'participants_count', None)}
        for d in dialogs
        if d.is_group or (d.is_channel and getattr(d.entity, 'megagroup', False))
    ]


async def get_my_channels(limit: int = 100, account: str = "a") -> list[dict]:
    client = await get_client(account)
    dialogs = await client.get_dialogs(limit=limit)
    return [
        {"id": d.entity.id, "title": d.title,
         "username": getattr(d.entity, 'username', None),
         "members_count": getattr(d.entity, 'participants_count', None)}
        for d in dialogs
        if d.is_channel and not getattr(d.entity, 'megagroup', False)
    ]


async def create_channel(title: str, about: str = "",
                         megagroup: bool = False, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        result = await client(CreateChannelRequest(
            title=title, about=about, megagroup=megagroup, broadcast=not megagroup))
        ch = result.chats[0]
        return {"success": True, "id": ch.id, "title": ch.title,
                "type": "group" if megagroup else "channel"}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def set_channel_title(channel_id: int, title: str, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        await client(EditTitleRequest(channel=entity, title=title))
        return {"success": True, "title": title}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def set_channel_description(channel_id: int, about: str, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        await client(EditChatAboutRequest(peer=entity, about=about))
        return {"success": True, "about": about}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def set_channel_username(channel_id: int, username: str, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        await client(UpdateUsernameRequest(channel=entity, username=username))
        return {"success": True, "username": username}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def set_channel_photo(channel_id: int, photo_path: str, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        upload = await client.upload_file(photo_path)
        await client(EditPhotoRequest(
            channel=entity, photo=types.InputChatUploadedPhoto(file=upload)))
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def set_channel_slow_mode(channel_id: int, seconds: int, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        await client(ToggleSlowModeRequest(channel=entity, seconds=seconds))
        return {"success": True, "slow_mode_seconds": seconds}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def set_channel_history_hidden(channel_id: int, hidden: bool, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        await client(TogglePreHistoryHiddenRequest(channel=entity, enabled=hidden))
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def create_invite_link(channel_id: int, title: str = "",
                             expire_hours: int = 0, usage_limit: int = 0,
                             request_needed: bool = False, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        expire_date = (datetime.now(timezone.utc) + timedelta(hours=expire_hours)
                       if expire_hours > 0 else None)
        result = await client(ExportChatInviteRequest(
            peer=entity, title=title or None, expire_date=expire_date,
            usage_limit=usage_limit if usage_limit > 0 else None,
            request_needed=request_needed))
        return {"success": True, "link": result.link}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def get_invite_links(channel_id: int, account: str = "a") -> list[dict]:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        me = await client.get_me()
        result = await client(GetExportedChatInvitesRequest(
            peer=entity, admin_id=me, limit=20))
        return [{"link": inv.link, "usage": getattr(inv, 'usage', 0) or 0}
                for inv in result.invites]
    except Exception as e:
        return [{"error": str(e)}]


async def delete_channel(channel_id: int, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        await client(DeleteChannelRequest(entity))
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def leave_channel(channel_id: int, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        await client(LeaveChannelRequest(entity))
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ── Messages ─────────────────────────────────────────────────

async def get_messages(group_id: int, limit: int = 20, account: str = "a") -> list[dict]:
    client = await get_client(account)
    entity = await client.get_entity(group_id)
    messages = await client.get_messages(entity, limit=limit)
    result = []
    for msg in messages:
        if msg.text:
            sender_name = ""
            if msg.sender:
                sender_name = getattr(msg.sender, 'first_name', '') or ''
                uname = getattr(msg.sender, 'username', '')
                if uname:
                    sender_name += f" (@{uname})"
            result.append({
                "id": msg.id, "text": msg.text[:500],
                "sender": sender_name, "sender_id": msg.sender_id,
                "date": msg.date.isoformat() if msg.date else "",
                "reply_to": msg.reply_to.reply_to_msg_id if msg.reply_to else None,
            })
    return result


async def send_comment(group_id: int, text: str,
                       reply_to_id: int | None = None, account: str = "a") -> dict:
    client = await get_client(account)
    entity = await client.get_entity(group_id)
    try:
        msg = await client.send_message(entity, text, reply_to=reply_to_id)
        return {"success": True, "message_id": msg.id, "group_id": group_id,
                "text": text, "account": account}
    except FloodWaitError as e:
        return {"success": False, "error": f"Flood wait: {e.seconds}s"}
    except (ChatWriteForbiddenError, UserBannedInChannelError) as e:
        return {"success": False, "error": str(e)}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def publish_post(channel_id: int, text: str,
                       parse_mode: str = "md", account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        pm = "md" if parse_mode == "md" else "html" if parse_mode == "html" else None
        msg = await client.send_message(entity, text, parse_mode=pm)
        return {"success": True, "message_id": msg.id}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def edit_message(channel_id: int, message_id: int, text: str,
                       parse_mode: str = "md", account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        pm = "md" if parse_mode == "md" else "html" if parse_mode == "html" else None
        await client.edit_message(entity, message_id, text, parse_mode=pm)
        return {"success": True, "message_id": message_id}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def delete_message(channel_id: int, message_id: int, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_id)
        await client.delete_messages(entity, [message_id])
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def search_public(query: str, limit: int = 20,
                        search_type: str = "all", account: str = "a") -> list[dict]:
    client = await get_client(account)
    result = await client(functions.contacts.SearchRequest(q=query, limit=limit))
    items = []
    for chat in result.chats:
        if not isinstance(chat, types.Channel):
            continue
        is_group = getattr(chat, 'megagroup', False)
        is_channel = getattr(chat, 'broadcast', False)
        if search_type == "groups" and not is_group:
            continue
        if search_type == "channels" and not is_channel:
            continue
        items.append({"id": chat.id, "title": chat.title,
                      "username": getattr(chat, 'username', None),
                      "type": "channel" if is_channel else "group"})
    return items


async def join_group(username_or_link: str, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        # Invite link: https://t.me/+HASH or https://t.me/joinchat/HASH
        invite_hash = None
        if "/+" in username_or_link:
            invite_hash = username_or_link.split("/+")[-1]
        elif "/joinchat/" in username_or_link:
            invite_hash = username_or_link.split("/joinchat/")[-1]

        if invite_hash:
            result = await client(ImportChatInviteRequest(invite_hash))
            chat = result.chats[0]
            return {"success": True, "title": chat.title, "id": chat.id}

        entity = await client.get_entity(username_or_link)
        await client(JoinChannelRequest(entity))
        return {"success": True, "title": getattr(entity, 'title', ''),
                "id": entity.id}
    except ChannelPrivateError:
        return {"success": False, "error": "Private group/channel"}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def get_channel_subscribers(channel_username: str, account: str = "a") -> dict:
    client = await get_client(account)
    try:
        entity = await client.get_entity(channel_username)
        full = await client(GetFullChannelRequest(entity))
        return {"title": entity.title,
                "subscribers": full.full_chat.participants_count}
    except Exception as e:
        return {"error": str(e)}


# ── Test-specific: DM ─────────────────────────────────────────

async def send_dm(peer_tg_id: int, text: str, account: str = "a") -> dict:
    """Send a direct message to a specific Telegram user."""
    client = await get_client(account)
    try:
        entity = await client.get_entity(peer_tg_id)
        msg = await client.send_message(entity, text)
        return {"success": True, "message_id": msg.id,
                "peer_tg_id": peer_tg_id, "account": account}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def read_dm(
    peer_tg_id: int, limit: int = 10, account: str = "a",
    after_id: int = 0, only_incoming: bool = False,
) -> list[dict]:
    """Read direct messages with a specific Telegram user.

    Args:
        after_id: Only return messages with id > after_id.
        only_incoming: If True, filter to only messages FROM the peer.
    """
    client = await get_client(account)
    try:
        entity = await client.get_entity(peer_tg_id)
        messages = await client.get_messages(entity, limit=limit)
        result = []
        for msg in messages:
            if not msg.text:
                continue
            if after_id and msg.id <= after_id:
                continue
            if only_incoming and msg.out:
                continue
            result.append({
                "id": msg.id,
                "text": msg.text[:500],
                "from_id": msg.sender_id,
                "out": msg.out,
                "date": msg.date.isoformat() if msg.date else "",
                "reply_to_msg_id": (
                    msg.reply_to.reply_to_msg_id if msg.reply_to else None
                ),
            })
        return result
    except Exception as e:
        return [{"error": str(e)}]
