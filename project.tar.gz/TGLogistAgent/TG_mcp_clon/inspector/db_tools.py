"""DB inspection MCP tools for LogistAgent testing."""

import json
import os
from datetime import datetime, timezone

import aiosqlite

from inspector.agent_db import (
    _AGENT_DB_PATH,
    _error,
    _parse_ai_analysis,
    read_query,
    resolve_contact_id,
)


def register_db_tools(mcp) -> None:  # noqa: ANN001
    """Register all DB inspection tools with the MCP server."""

    @mcp.tool()
    async def inspect_contact(tg_id: int) -> str:
        """Full contact profile by Telegram ID.

        Returns: contact info, psychology, reliability, routes, phones,
        source groups, recent prices.
        """
        contact_id = await resolve_contact_id(tg_id)
        if not contact_id:
            return _error(f"Contact not found for tg_id={tg_id}")

        contact = (await read_query(
            "SELECT * FROM contacts WHERE id = ?", (contact_id,),
        ))[0]

        psych_rows = await read_query(
            "SELECT * FROM contact_psychology WHERE contact_id = ?",
            (contact_id,),
        )
        psychology = dict(psych_rows[0]) if psych_rows else None
        if psychology:
            psychology.pop("contact_id", None)

        rel_rows = await read_query(
            "SELECT * FROM contact_reliability WHERE contact_id = ?",
            (contact_id,),
        )
        reliability = dict(rel_rows[0]) if rel_rows else None
        if reliability:
            reliability.pop("contact_id", None)

        routes = await read_query(
            "SELECT from_city, to_city, frequency, last_seen "
            "FROM contact_routes WHERE contact_id = ?",
            (contact_id,),
        )

        phones = await read_query(
            "SELECT phone, source FROM contact_phones WHERE contact_id = ?",
            (contact_id,),
        )

        groups = await read_query(
            "SELECT group_name, group_tg_id, first_seen, last_seen "
            "FROM contact_source_groups WHERE contact_id = ?",
            (contact_id,),
        )

        prices = await read_query(
            "SELECT route_from, route_to, container_type, price, currency, "
            "date, source FROM price_records "
            "WHERE contact_id = ? ORDER BY date DESC LIMIT 10",
            (contact_id,),
        )

        result = {
            "contact": contact,
            "psychology": psychology,
            "reliability": reliability,
            "routes": routes,
            "phones": phones,
            "source_groups": groups,
            "price_records": prices,
        }
        return json.dumps(result, ensure_ascii=False, indent=2, default=str)

    @mcp.tool()
    async def inspect_messages(
        tg_id: int = 0,
        direction: str = "",
        deal_id: str = "",
        limit: int = 20,
    ) -> str:
        """View messages with ai_analysis JSON.

        Filter by tg_id (contact), direction ('in'/'out'), or deal_id.
        Shows full ai_analysis for debugging AI parsing.
        """
        conditions = []
        params: list = []

        if tg_id:
            contact_id = await resolve_contact_id(tg_id)
            if not contact_id:
                return _error(f"Contact not found for tg_id={tg_id}")
            conditions.append("m.contact_id = ?")
            params.append(contact_id)

        if direction:
            conditions.append("m.direction = ?")
            params.append(direction)

        if deal_id:
            conditions.append("m.deal_id = ?")
            params.append(deal_id)

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        params.append(limit)

        rows = await read_query(
            f"SELECT m.*, c.tg_id, c.first_name, c.type as contact_type "
            f"FROM messages m "
            f"LEFT JOIN contacts c ON m.contact_id = c.id "
            f"{where} "
            f"ORDER BY m.created_at DESC LIMIT ?",
            tuple(params),
        )

        messages = []
        for row in rows:
            msg = dict(row)
            msg["ai_analysis"] = _parse_ai_analysis(msg.get("ai_analysis"))
            messages.append(msg)

        return json.dumps(
            {"count": len(messages), "messages": messages},
            ensure_ascii=False, indent=2, default=str,
        )

    @mcp.tool()
    async def inspect_deals(
        tg_id: int = 0,
        status: str = "",
        deal_id: str = "",
        limit: int = 10,
    ) -> str:
        """View deals with events timeline.

        Filter by tg_id (as customer or carrier), status, or specific deal_id.
        Includes deal_events, documents count, and driver info.
        """
        if deal_id:
            deals = await read_query(
                "SELECT * FROM deals WHERE id = ?", (deal_id,),
            )
        else:
            conditions = []
            params: list = []

            if tg_id:
                contact_id = await resolve_contact_id(tg_id)
                if not contact_id:
                    return _error(f"Contact not found for tg_id={tg_id}")
                conditions.append(
                    "(customer_contact_id = ? OR carrier_contact_id = ?)",
                )
                params.extend([contact_id, contact_id])

            if status:
                conditions.append("status = ?")
                params.append(status)

            where = "WHERE " + " AND ".join(conditions) if conditions else ""
            params.append(limit)

            deals = await read_query(
                f"SELECT * FROM deals {where} "
                f"ORDER BY created_at DESC LIMIT ?",
                tuple(params),
            )

        result_deals = []
        for deal in deals:
            d = dict(deal)
            d_id = d["id"]

            # Resolve contact names
            for role in ("customer_contact_id", "carrier_contact_id"):
                cid = d.get(role)
                if cid:
                    c_rows = await read_query(
                        "SELECT tg_id, first_name, type FROM contacts "
                        "WHERE id = ?", (cid,),
                    )
                    if c_rows:
                        d[role.replace("_id", "")] = c_rows[0]

            # Events
            events = await read_query(
                "SELECT event_type, old_value, new_value, note, created_at "
                "FROM deal_events WHERE deal_id = ? "
                "ORDER BY created_at DESC LIMIT 10",
                (d_id,),
            )
            d["events"] = events

            # Documents count
            docs = await read_query(
                "SELECT COUNT(*) as cnt FROM deal_documents "
                "WHERE deal_id = ?", (d_id,),
            )
            d["documents_count"] = docs[0]["cnt"] if docs else 0

            # Drivers
            drivers = await read_query(
                "SELECT driver_name, driver_phone, driver_tg_id, verified "
                "FROM driver_contacts WHERE deal_id = ?", (d_id,),
            )
            d["drivers"] = drivers

            result_deals.append(d)

        return json.dumps(
            {"count": len(result_deals), "deals": result_deals},
            ensure_ascii=False, indent=2, default=str,
        )

    @mcp.tool()
    async def inspect_cargo(
        status: str = "",
        type: str = "",
        tg_id: int = 0,
        limit: int = 10,
    ) -> str:
        """View cargo/transport offers with ai_analysis.

        Filter by status ('open'/'matched'/'expired'), type ('cargo'/'transport'),
        or sender tg_id. Shows full AI parser output.
        """
        conditions = []
        params: list = []

        if status:
            conditions.append("co.status = ?")
            params.append(status)

        if type:
            conditions.append("co.type = ?")
            params.append(type)

        if tg_id:
            contact_id = await resolve_contact_id(tg_id)
            if not contact_id:
                return _error(f"Contact not found for tg_id={tg_id}")
            conditions.append("co.sender_contact_id = ?")
            params.append(contact_id)

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        params.append(limit)

        rows = await read_query(
            f"SELECT co.*, c.tg_id as sender_tg_id, c.first_name as sender_name "
            f"FROM cargo_offers co "
            f"LEFT JOIN contacts c ON co.sender_contact_id = c.id "
            f"{where} "
            f"ORDER BY co.created_at DESC LIMIT ?",
            tuple(params),
        )

        offers = []
        for row in rows:
            offer = dict(row)
            offer["ai_analysis"] = _parse_ai_analysis(offer.get("ai_analysis"))
            offers.append(offer)

        return json.dumps(
            {"count": len(offers), "offers": offers},
            ensure_ascii=False, indent=2, default=str,
        )

    @mcp.tool()
    async def inspect_unprocessed(show_processed: bool = False) -> str:
        """View unprocessed message queue.

        Shows messages that failed processing (API errors, low confidence, etc.).
        Set show_processed=True to include already-processed entries.
        """
        condition = "" if show_processed else "WHERE processed = 0"
        rows = await read_query(
            f"SELECT * FROM unprocessed_messages {condition} "
            f"ORDER BY received_at DESC LIMIT 30",
        )

        pending = sum(1 for r in rows if not r.get("processed"))
        return json.dumps(
            {"pending_count": pending, "total": len(rows), "messages": rows},
            ensure_ascii=False, indent=2, default=str,
        )

    @mcp.tool()
    async def inspect_overview() -> str:
        """Global DB state summary: row counts per table, config, rates.

        Call at start/end of test session to see baseline and what changed.
        """
        tables = [
            "contacts", "contact_phones", "contact_routes",
            "contact_source_groups", "contact_psychology", "contact_reliability",
            "price_records", "cargo_offers", "deals", "deal_events",
            "deal_documents", "driver_contacts", "messages",
            "unprocessed_messages", "market_prices", "exchange_rates",
        ]

        counts = {}
        for table in tables:
            try:
                rows = await read_query(f"SELECT COUNT(*) as cnt FROM {table}")
                counts[table] = rows[0]["cnt"]
            except Exception:
                counts[table] = -1

        # Status breakdowns
        cargo_status = await read_query(
            "SELECT status, COUNT(*) as cnt FROM cargo_offers GROUP BY status",
        )
        deals_status = await read_query(
            "SELECT status, COUNT(*) as cnt FROM deals GROUP BY status",
        )
        unprocessed_pending = await read_query(
            "SELECT COUNT(*) as cnt FROM unprocessed_messages WHERE processed=0",
        )

        # Config
        config = await read_query("SELECT key, value FROM agent_config")
        config_dict = {r["key"]: r["value"] for r in config}

        # Exchange rates
        rates = await read_query("SELECT currency, rate_uah, date FROM exchange_rates")

        # Recent activity
        last_msg = await read_query(
            "SELECT created_at FROM messages ORDER BY created_at DESC LIMIT 1",
        )
        last_deal = await read_query(
            "SELECT updated_at FROM deals ORDER BY updated_at DESC LIMIT 1",
        )

        result = {
            "counts": counts,
            "cargo_by_status": {r["status"]: r["cnt"] for r in cargo_status},
            "deals_by_status": {r["status"]: r["cnt"] for r in deals_status},
            "unprocessed_pending": unprocessed_pending[0]["cnt"] if unprocessed_pending else 0,
            "agent_config": config_dict,
            "exchange_rates": {r["currency"]: {"rate_uah": r["rate_uah"], "date": r["date"]} for r in rates},
            "last_message_at": last_msg[0]["created_at"] if last_msg else None,
            "last_deal_updated_at": last_deal[0]["updated_at"] if last_deal else None,
        }
        return json.dumps(result, ensure_ascii=False, indent=2, default=str)

    @mcp.tool()
    async def inspect_query(sql: str) -> str:
        """Run arbitrary read-only SQL against agent DB.

        Only SELECT queries allowed. Max 100 rows.
        Use for ad-hoc checks not covered by other inspect_* tools.
        Example: inspect_query("SELECT * FROM contacts WHERE type='carrier'")
        """
        sql_stripped = sql.strip()
        upper = sql_stripped.upper()

        # Block dangerous keywords
        blocked = ["DROP", "DELETE", "UPDATE", "INSERT", "ALTER", "CREATE", "ATTACH"]
        for kw in blocked:
            if kw in upper and not upper.startswith("SELECT"):
                return _error(f"Blocked keyword: {kw}. Only SELECT allowed.")

        if not upper.startswith("SELECT") and not upper.startswith("PRAGMA"):
            return _error(f"Only SELECT/PRAGMA allowed. Got: {sql_stripped[:50]}")

        try:
            rows = await read_query(sql_stripped, limit=100)
            columns = list(rows[0].keys()) if rows else []
            return json.dumps(
                {"columns": columns, "rows": rows, "row_count": len(rows)},
                ensure_ascii=False, indent=2, default=str,
            )
        except FileNotFoundError as e:
            return _error(str(e))
        except Exception as e:
            return _error(f"SQL error: {e}")

    @mcp.tool()
    async def db_reset(confirm: bool = False) -> str:
        """Wipe all data from LogistAgent DB, preserving table structure.

        Deletes rows from ALL tables (respecting FK order), then seeds
        agent_config defaults and exchange_rates (EUR/USD).

        Safety: pass confirm=True to actually execute. Without it — dry run.
        """
        if not confirm:
            return json.dumps(
                {
                    "status": "dry_run",
                    "message": (
                        "No changes made. Pass confirm=True to wipe all data. "
                        "This will DELETE every row from every table."
                    ),
                },
                ensure_ascii=False,
            )

        if not os.path.exists(_AGENT_DB_PATH):
            return _error(f"Agent DB not found at {_AGENT_DB_PATH}")

        # Tables ordered by FK dependency (deepest first)
        tables_ordered = [
            # Level 3: FK -> deals
            "deal_events",
            "deal_documents",
            "driver_contacts",
            # Archive (no FK, safe anytime)
            "deals_archive",
            "messages_archive",
            # Level 2: FK -> contacts + cargo_offers / deals
            "messages",
            "deals",
            "market_prices",
            # Level 1: FK -> contacts
            "contact_phones",
            "contact_routes",
            "contact_source_groups",
            "contact_psychology",
            "contact_reliability",
            "price_records",
            "cargo_offers",
            # Level 0: no FK
            "contacts",
            "unprocessed_messages",
            "agent_config",
            "exchange_rates",
        ]

        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        cleared: dict[str, int] = {}
        errors: list[str] = []

        try:
            async with aiosqlite.connect(_AGENT_DB_PATH, timeout=10.0) as db:
                await db.execute("PRAGMA journal_mode=WAL")
                await db.execute("PRAGMA foreign_keys=OFF")

                for table in tables_ordered:
                    try:
                        cursor = await db.execute(
                            f"SELECT COUNT(*) FROM {table}",  # noqa: S608
                        )
                        row = await cursor.fetchone()
                        count_before = row[0] if row else 0

                        await db.execute(f"DELETE FROM {table}")  # noqa: S608
                        cleared[table] = count_before
                    except Exception as exc:
                        errors.append(f"{table}: {exc}")

                # Seed agent_config defaults
                config_defaults = [
                    ("margin_threshold_usd", "100"),
                    ("max_carriers_to_contact", "3"),
                    ("response_wait_hours", "2"),
                    ("cargo_ttl_hours", "72"),
                    ("escalation_amount_eur", "5000"),
                    ("active_mode_enabled", "1"),
                    ("min_reliability_for_active", "50"),
                    ("carrier_channel_id", ""),
                    ("nbu_rate_update_interval", "daily"),
                    ("first_contact_approval", "1"),
                ]
                for key, value in config_defaults:
                    await db.execute(
                        "INSERT OR IGNORE INTO agent_config (key, value, updated_at) "
                        "VALUES (?, ?, ?)",
                        (key, value, now),
                    )

                # Seed exchange_rates (EUR and USD placeholder rates)
                rates = [
                    ("EUR", 44.50, now),
                    ("USD", 41.20, now),
                ]
                for currency, rate, date in rates:
                    await db.execute(
                        "INSERT OR IGNORE INTO exchange_rates "
                        "(currency, rate_uah, date, updated_at) "
                        "VALUES (?, ?, ?, ?)",
                        (currency, rate, date, now),
                    )

                await db.execute("PRAGMA foreign_keys=ON")
                await db.commit()

        except Exception as exc:
            return _error(f"DB reset failed: {exc}")

        total_deleted = sum(cleared.values())
        result = {
            "status": "completed",
            "tables_cleared": len(cleared),
            "total_rows_deleted": total_deleted,
            "details": cleared,
            "seeded": {
                "agent_config": len(config_defaults),
                "exchange_rates": len(rates),
            },
        }
        if errors:
            result["errors"] = errors

        return json.dumps(result, ensure_ascii=False, indent=2)
