"""Inspector tools for LogistAgent — DB, logs, and AI trace inspection."""

from inspector.db_tools import register_db_tools
from inspector.log_tools import register_log_tools


def register_tools(mcp) -> None:  # noqa: ANN001
    """Register all inspection tools with the MCP server."""
    register_db_tools(mcp)
    register_log_tools(mcp)
