"""Log inspection MCP tools for LogistAgent testing."""

import json
import os
import re
from datetime import date

_LOG_DIR = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "..", "logs")
)

# Шум який фільтруємо за замовчуванням
_NOISE_PATTERNS = [
    "getUpdates",
    "telethon.crypto",
    "deleteWebhook",
    "httpx: HTTP Request: POST https://api.telegram.org",
]


def _error(message: str) -> str:
    return json.dumps({"error": message}, ensure_ascii=False)


def register_log_tools(mcp) -> None:  # noqa: ANN001
    """Register log inspection tools with the MCP server."""

    @mcp.tool()
    async def inspect_logs(
        log_date: str = "",
        level: str = "",
        module: str = "",
        search: str = "",
        tail: int = 50,
        exclude_noise: bool = True,
    ) -> str:
        """View agent logs with filtering.

        Args:
            log_date: Date in YYYY-MM-DD format (default: today).
            level: Filter by level: INFO, WARNING, ERROR, DEBUG.
            module: Filter by module name (e.g. 'router', 'responder', 'matcher').
            search: Free-text substring search.
            tail: Number of last matching lines to return.
            exclude_noise: Skip httpx polling and telethon crypto spam (default: True).

        Returns last N matching lines from the log file.
        """
        target_date = log_date or date.today().isoformat()
        log_path = os.path.join(_LOG_DIR, f"logist_{target_date}.log")

        if not os.path.exists(log_path):
            available = _list_log_files()
            return json.dumps({
                "error": f"No log file for {target_date}",
                "available_dates": available,
            }, ensure_ascii=False, indent=2)

        try:
            with open(log_path, encoding="utf-8") as f:
                lines = f.readlines()
        except Exception as e:
            return _error(f"Failed to read log: {e}")

        filtered = []
        for line in lines:
            line_s = line.rstrip()
            if not line_s:
                continue

            # Фільтр шуму
            if exclude_noise and any(p in line_s for p in _NOISE_PATTERNS):
                continue

            # Фільтр по рівню
            if level:
                level_upper = level.upper()
                if f"[{level_upper}]" not in line_s:
                    continue

            # Фільтр по модулю
            if module and module.lower() not in line_s.lower():
                continue

            # Пошук по тексту
            if search and search.lower() not in line_s.lower():
                continue

            filtered.append(line_s)

        result_lines = filtered[-tail:]

        return json.dumps({
            "date": target_date,
            "total_lines": len(lines),
            "matched_lines": len(filtered),
            "showing_last": len(result_lines),
            "filters": {
                "level": level or "all",
                "module": module or "all",
                "search": search or "none",
                "exclude_noise": exclude_noise,
            },
            "lines": result_lines,
        }, ensure_ascii=False, indent=2)

    @mcp.tool()
    async def inspect_errors(
        log_date: str = "",
        tail: int = 30,
    ) -> str:
        """View only ERROR and WARNING log entries with tracebacks.

        Captures multi-line tracebacks that follow error entries.
        Useful for quick debugging after a test failure.
        """
        target_date = log_date or date.today().isoformat()
        log_path = os.path.join(_LOG_DIR, f"logist_{target_date}.log")

        if not os.path.exists(log_path):
            return _error(f"No log file for {target_date}")

        try:
            with open(log_path, encoding="utf-8") as f:
                lines = f.readlines()
        except Exception as e:
            return _error(f"Failed to read log: {e}")

        # Паттерн для початку log-рядка (з timestamp)
        log_line_re = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}")

        error_blocks: list[str] = []
        current_block: list[str] = []
        capturing = False

        for line in lines:
            line_s = line.rstrip()
            is_log_start = log_line_re.match(line_s)

            if is_log_start:
                # Зберегти попередній блок
                if capturing and current_block:
                    error_blocks.append("\n".join(current_block))
                    current_block = []
                    capturing = False

                # Новий error/warning?
                if "[ERROR]" in line_s or "[WARNING]" in line_s:
                    capturing = True
                    current_block = [line_s]
            elif capturing:
                # Traceback continuation
                current_block.append(line_s)

        # Останній блок
        if capturing and current_block:
            error_blocks.append("\n".join(current_block))

        result_blocks = error_blocks[-tail:]

        return json.dumps({
            "date": target_date,
            "total_errors_warnings": len(error_blocks),
            "showing_last": len(result_blocks),
            "entries": result_blocks,
        }, ensure_ascii=False, indent=2)


def _list_log_files() -> list[str]:
    """List available log dates."""
    if not os.path.exists(_LOG_DIR):
        return []
    files = []
    for f in sorted(os.listdir(_LOG_DIR), reverse=True):
        if f.startswith("logist_") and f.endswith(".log"):
            date_part = f.replace("logist_", "").replace(".log", "")
            files.append(date_part)
    return files[:10]
