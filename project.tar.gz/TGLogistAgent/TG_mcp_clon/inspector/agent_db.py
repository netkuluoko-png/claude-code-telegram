"""Read-only access to LogistAgent's SQLite database."""

import json
import os

import aiosqlite

# Шлях до БД агента — відносно кореня проекту
_AGENT_DB_PATH = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "..", "data", "logist.db")
)


def _error(message: str) -> str:
    """Return JSON error string."""
    return json.dumps({"error": message}, ensure_ascii=False)


def _parse_ai_analysis(raw: str | None) -> dict | str | None:
    """Parse ai_analysis JSON string into dict. Return raw on failure."""
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return raw


async def read_query(
    query: str, params: tuple = (), *, limit: int = 100,
) -> list[dict]:
    """Execute a read-only query against the agent's DB.

    Opens a fresh connection per call with WAL mode.
    Returns list of dicts (one per row).

    Raises:
        FileNotFoundError: If DB file doesn't exist.
        ValueError: If query is not SELECT/PRAGMA.
    """
    q_upper = query.strip().upper()
    if not q_upper.startswith("SELECT") and not q_upper.startswith("PRAGMA"):
        raise ValueError("Only SELECT and PRAGMA queries are allowed")

    if not os.path.exists(_AGENT_DB_PATH):
        raise FileNotFoundError(f"Agent DB not found at {_AGENT_DB_PATH}")

    async with aiosqlite.connect(_AGENT_DB_PATH, timeout=5.0) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA journal_mode=WAL")
        await db.execute("PRAGMA query_only=ON")
        async with db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
            return [dict(r) for r in rows[:limit]]


async def resolve_contact_id(tg_id: int) -> str | None:
    """Resolve tg_id -> internal contact_id. Returns None if not found."""
    rows = await read_query(
        "SELECT id FROM contacts WHERE tg_id = ?", (tg_id,),
    )
    return rows[0]["id"] if rows else None
