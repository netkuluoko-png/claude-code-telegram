"""Private Telegram bot for the operator (whitelist access)."""

from __future__ import annotations

import logging

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from src.bot.contact_briefing import ContactBriefingService
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository

logger = logging.getLogger(__name__)


class AdminBot:
    """Private Telegram bot for the operator with whitelist access."""

    def __init__(
        self,
        bot_token: str,
        admin_tg_id: int,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        message_repo: MessageRepository,
        contact_briefing: ContactBriefingService,
    ) -> None:
        self._token = bot_token
        self._admin_id = admin_tg_id
        self._contacts = contact_repo
        self._deals = deal_repo
        self._messages = message_repo
        self._briefing = contact_briefing
        self._app: Application | None = None  # type: ignore[type-arg]

    async def start(self) -> None:
        """Build and start the bot application."""
        if not self._token:
            logger.warning("Admin bot token not configured, skipping")
            return

        self._app = (
            Application.builder()
            .token(self._token)
            .build()
        )

        self._app.add_handler(CommandHandler("who", self._cmd_who))
        self._app.add_handler(CommandHandler("resolve", self._cmd_resolve))
        self._app.add_handler(CommandHandler("cancel", self._cmd_cancel))
        self._app.add_handler(CommandHandler("note", self._cmd_note))
        self._app.add_handler(CommandHandler("health", self._cmd_health))
        self._app.add_handler(CommandHandler("archive", self._cmd_archive_stats))
        self._app.add_handler(
            MessageHandler(filters.FORWARDED, self._handle_forwarded_call),
        )

        await self._app.initialize()
        await self._app.start()
        if self._app.updater:
            await self._app.updater.start_polling()
        logger.info("Admin bot started")

    def _is_authorized(self, user_id: int | None) -> bool:
        """Check if user is in the whitelist."""
        return user_id == self._admin_id

    async def _cmd_who(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """WF-12: /who <phone|@username|tg_id> — contact briefing."""
        if not update.effective_user or not self._is_authorized(update.effective_user.id):
            return
        if not update.message or not context.args:
            if update.message:
                await update.message.reply_text(
                    "Використання: /who <телефон|@username|tg_id>",
                )
            return

        query = " ".join(context.args).strip()
        contact = None

        # Парсинг: @username
        if query.startswith("@"):
            contact = await self._contacts.search_by_username(query)
        # Парсинг: числовий tg_id
        elif query.isdigit() and len(query) > 5:
            contact = await self._contacts.get_by_tg_id(int(query))
        # Парсинг: телефон
        else:
            contact = await self._contacts.search_by_phone(query)

        if contact is None:
            await update.message.reply_text("❌ Контакт не знайдено в базі.")
            return

        try:
            briefing = await self._briefing.generate_briefing(contact.id)
            await update.message.reply_text(
                briefing.briefing_text,
                parse_mode="Markdown",
            )
        except Exception:
            logger.exception("Briefing generation failed for %s", contact.id)
            await update.message.reply_text("❌ Помилка генерації брифінгу.")

    async def _cmd_resolve(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """WF-6: /resolve <deal_id> <instruction>."""
        if not update.effective_user or not self._is_authorized(update.effective_user.id):
            return
        if not update.message or not context.args or len(context.args) < 2:
            if update.message:
                await update.message.reply_text(
                    "Використання: /resolve <deal_id> <інструкція>",
                )
            return

        deal_id = context.args[0]
        instruction = " ".join(context.args[1:])

        deal = await self._deals.get_by_id(deal_id)
        if deal is None:
            await update.message.reply_text(f"❌ Угоду {deal_id} не знайдено.")
            return

        await self._deals.clear_escalation(deal_id)
        from src.db.repositories.base import new_id
        from src.models.deal import DealEvent

        await self._deals.add_event(DealEvent(
            id=new_id(), deal_id=deal_id,
            event_type="note",
            note=f"Resolved by operator: {instruction}",
        ))
        await update.message.reply_text(
            f"✅ Ескалацію по {deal_id[:12]} знято.\nІнструкція: {instruction}",
        )

    async def _cmd_cancel(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Cancel a deal: /cancel <deal_id> <reason>."""
        if not update.effective_user or not self._is_authorized(update.effective_user.id):
            return
        if not update.message or not context.args or len(context.args) < 2:
            if update.message:
                await update.message.reply_text(
                    "Використання: /cancel <deal_id> <причина>",
                )
            return

        deal_id = context.args[0]
        reason = " ".join(context.args[1:])

        deal = await self._deals.get_by_id(deal_id)
        if deal is None:
            await update.message.reply_text(f"❌ Угоду {deal_id} не знайдено.")
            return

        await self._deals.update_status(deal_id, "cancelled", f"Operator: {reason}")
        await update.message.reply_text(
            f"❌ Угоду {deal_id[:12]} скасовано.\nПричина: {reason}",
        )

    async def _cmd_note(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Add a note to a deal: /note <deal_id> <text>."""
        if not update.effective_user or not self._is_authorized(update.effective_user.id):
            return
        if not update.message or not context.args or len(context.args) < 2:
            if update.message:
                await update.message.reply_text(
                    "Використання: /note <deal_id> <текст>",
                )
            return

        deal_id = context.args[0]
        text = " ".join(context.args[1:])

        deal = await self._deals.get_by_id(deal_id)
        if deal is None:
            await update.message.reply_text(f"❌ Угоду {deal_id} не знайдено.")
            return

        from src.db.repositories.base import new_id
        from src.models.deal import DealEvent

        await self._deals.add_event(DealEvent(
            id=new_id(), deal_id=deal_id,
            event_type="note", note=text,
        ))
        await update.message.reply_text(f"📝 Примітку додано до {deal_id[:12]}.")

    async def _cmd_health(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Show system health status via HealthMonitor."""
        if not update.effective_user or not self._is_authorized(update.effective_user.id):
            return
        if not update.message:
            return

        queue_count = await self._messages.get_unprocessed_count()
        text = (
            "📊 *Стан системи:*\n"
            f"Необроблених повідомлень: {queue_count}\n"
        )
        await update.message.reply_text(text, parse_mode="Markdown")

    async def _cmd_archive_stats(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """/archive stats — show archive statistics."""
        if not update.effective_user or not self._is_authorized(update.effective_user.id):
            return
        if not update.message:
            return

        # Підрахунок архівних записів
        archive_deals = await self._deals._count("deals_archive")
        archive_msgs = await self._deals._count("messages_archive")
        text = (
            "📦 *Архів:*\n"
            f"deals\\_archive: {archive_deals} записів\n"
            f"messages\\_archive: {archive_msgs} записів\n"
        )
        await update.message.reply_text(text, parse_mode="Markdown")

    async def _handle_forwarded_call(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle forwarded missed call → extract tg_id → WF-12."""
        if not update.effective_user or not self._is_authorized(update.effective_user.id):
            return
        if not update.message or not update.message.forward_from:
            return

        tg_id = update.message.forward_from.id
        contact = await self._contacts.get_by_tg_id(tg_id)

        if contact is None:
            await update.message.reply_text(
                f"❌ Контакт tg_id={tg_id} не знайдено в базі.",
            )
            return

        try:
            briefing = await self._briefing.generate_briefing(contact.id)
            await update.message.reply_text(
                briefing.briefing_text,
                parse_mode="Markdown",
            )
        except Exception:
            logger.exception("Briefing failed for forwarded call tg_id=%d", tg_id)
            await update.message.reply_text("❌ Помилка генерації брифінгу.")

    async def close(self) -> None:
        """Stop the bot."""
        if self._app:
            if self._app.updater and self._app.updater.running:
                await self._app.updater.stop()
            await self._app.stop()
            await self._app.shutdown()
