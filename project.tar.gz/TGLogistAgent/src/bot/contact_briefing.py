"""Contact Briefing service — AI briefing for operator (WF-12, step 4)."""

from __future__ import annotations

import json
import logging
from typing import Any

from src.agent.codex import PromptLoader
from src.agent.context import ContextAssembler
from src.models.ai_outputs import ContactBriefingOutput
from src.services.claude_client import ClaudeClient

logger = logging.getLogger(__name__)


class ContactBriefingService:
    """Generate AI-powered contact briefing for the operator."""

    def __init__(
        self,
        claude_client: ClaudeClient,
        prompt_loader: PromptLoader,
        context_assembler: ContextAssembler,
    ) -> None:
        self._claude = claude_client
        self._system_prompt = prompt_loader.load_contact_briefing()
        self._context = context_assembler

    async def generate_briefing(
        self, contact_id: str
    ) -> ContactBriefingOutput:
        """Assemble context and generate AI briefing.

        Args:
            contact_id: UUID of the contact.

        Returns:
            ContactBriefingOutput with briefing text, intent, urgency.
        """
        ctx = await self._context.for_contact_briefing(contact_id)
        user_message = self._format_context(ctx)
        return await self._claude.call_json(
            system_prompt=self._system_prompt,
            user_message=user_message,
            response_model=ContactBriefingOutput,
            temperature=0.3,
            max_tokens=1500,
            timeout=30.0,
        )

    def _format_context(self, ctx: dict[str, Any]) -> str:
        """Format context dict as user message for the briefing prompt."""
        parts: list[str] = []

        contact = ctx.get("contact", {})
        if contact:
            parts.append("ПРОФІЛЬ КОНТАКТУ:")
            parts.append(json.dumps(contact, ensure_ascii=False, indent=2))
            parts.append("")

        deals = ctx.get("active_deals", [])
        if deals:
            parts.append("АКТИВНІ УГОДИ:")
            parts.append(json.dumps(deals, ensure_ascii=False, indent=2))
            parts.append("")

        events = ctx.get("recent_deal_events", [])
        if events:
            parts.append("ОСТАННІ ПОДІЇ ПО УГОДАХ:")
            parts.append(json.dumps(events, ensure_ascii=False, indent=2))
            parts.append("")

        messages = ctx.get("recent_messages", [])
        if messages:
            parts.append("ОСТАННІ ПОВІДОМЛЕННЯ:")
            for m in messages:
                sender = "Контакт" if m["from"] == "contact" else "Агент"
                parts.append(f"  [{m.get('date', '')}] {sender}: {m['text']}")
            parts.append("")

        cargos = ctx.get("our_open_cargos", [])
        if cargos:
            parts.append("НАШІ ВІДКРИТІ ВАНТАЖІ:")
            parts.append(json.dumps(cargos, ensure_ascii=False, indent=2))
            parts.append("")

        parts.append(f"Сьогоднішня дата: {ctx.get('current_date', '')}")

        return "\n".join(parts)
