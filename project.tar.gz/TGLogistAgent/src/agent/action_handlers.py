"""Action executor — handles Responder actions (WF-4 actions)."""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from telethon import TelegramClient

from src.config import Settings
from src.db.repositories.base import new_id
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository
from src.models.ai_outputs import ResponderAction
from src.models.contact import PriceRecord
from src.models.deal import DriverContact

if TYPE_CHECKING:
    from src.agent.verification import VerificationAgent
    from src.deals.manager import DealManager
    from src.notifications.notifier import Notifier

logger = logging.getLogger(__name__)


class ActionExecutor:
    """Execute Responder actions dispatched by Router."""

    _VERIFICATION_KEYWORDS: tuple[str, ...] = (
        "другий акаунт",
        "second account",
        "duplicate",
        "підозрілий",
        "suspicious",
        "фішинг",
        "phishing",
        "шахрай",
        "fraud",
        "інший номер",
        "інший акаунт",
    )

    def __init__(
        self,
        client: TelegramClient,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        message_repo: MessageRepository,
        cargo_repo: CargoRepository,
        notifier: Notifier,
        config: Settings,
        deal_manager: DealManager,
        verification: VerificationAgent | None = None,
    ) -> None:
        self._client = client
        self._contacts = contact_repo
        self._deals = deal_repo
        self._messages = message_repo
        self._cargo = cargo_repo
        self._notifier = notifier
        self._config = config
        self._deal_manager = deal_manager
        self._verification = verification

    async def execute_actions(
        self,
        actions: list[ResponderAction],
        contact_id: str,
        deal_id: str | None,
    ) -> None:
        """Execute all actions from ResponderOutput.

        Args:
            actions: List of actions to execute.
            contact_id: UUID of the contact.
            deal_id: Deal ID from responder output.
        """
        for action in actions:
            try:
                await self._execute_single_action(
                    action,
                    contact_id,
                    deal_id,
                )
            except Exception:
                logger.exception("Action %s failed", action.type)

    async def _execute_single_action(
        self,
        action: ResponderAction,
        contact_id: str,
        deal_id: str | None,
    ) -> None:
        """Execute a single Responder action."""
        atype = action.type

        if atype == "none" or atype == "ask_clarification":
            return

        if atype == "create_contact":
            if action.role:
                await self._contacts.update_type(contact_id, action.role)

        elif atype == "update_deal_status":
            await self._handle_update_deal_status(action, contact_id)

        elif atype == "update_price":
            await self._handle_update_price(action, contact_id, deal_id)

        elif atype == "escalate":
            await self._handle_escalate(action, contact_id, deal_id)

        elif atype == "notify_operator":
            if action.text:
                await self._notifier.send(action.text)

        elif atype == "create_deal":
            await self._handle_create_deal(action, contact_id)

        elif atype == "forward_to_other_party":
            await self._handle_forward(action, deal_id, contact_id)

        elif atype == "send_to_carrier_channel":
            await self._handle_send_to_channel(action)

        elif atype == "update_profile":
            pass  # Буде викликано окремим Profiler task

        elif atype == "save_driver":
            await self._handle_save_driver(action, contact_id, deal_id)

    async def _handle_update_deal_status(
        self,
        action: ResponderAction,
        contact_id: str,
    ) -> None:
        """Handle update_deal_status action.

        Args:
            action: Action with deal_id and new_status.
            contact_id: Current sender contact ID.
        """
        if action.deal_id and action.new_status:
            valid_deal_id = await self.validate_deal_id(action.deal_id)
            if valid_deal_id:
                await self._deals.update_status(
                    valid_deal_id,
                    action.new_status,
                )
            else:
                logger.warning(
                    "update_deal_status skipped: deal_id=%s not found",
                    action.deal_id,
                )

    async def _handle_update_price(
        self,
        action: ResponderAction,
        contact_id: str,
        deal_id: str | None,
    ) -> None:
        """Handle update_price action.

        Args:
            action: Action with price, route, and optional contact_id.
            contact_id: Current contact ID.
            deal_id: Deal ID from responder output.
        """
        if action.price is None or not action.route:
            return

        # Резолвити contact_id: action.contact_id може бути UUID
        target_contact_id = contact_id
        if action.contact_id and action.contact_id != contact_id:
            resolved = await self._contacts.get_by_id(action.contact_id)
            if resolved:
                target_contact_id = resolved.id
            else:
                logger.warning(
                    "update_price: could not resolve contact_id=%s, using current",
                    action.contact_id,
                )

        parts = action.route.split("→")
        route_from = parts[0].strip() if parts else ""
        route_to = parts[1].strip() if len(parts) > 1 else ""

        record = PriceRecord(
            id=new_id(),
            contact_id=target_contact_id,
            route_from=route_from,
            route_to=route_to,
            price=action.price,
            currency=action.currency or "EUR",
            date=datetime.now(tz=UTC).date().isoformat(),
        )
        await self._contacts.add_price_record(record)

        # Оновити deal.carrier_price та margin якщо є deal
        target_deal_id = action.deal_id or deal_id
        if target_deal_id:
            deal = await self._deals.get_by_id(target_deal_id)
            if deal and deal.carrier_contact_id == target_contact_id:
                await self._deals.update_prices(
                    target_deal_id,
                    carrier_price=action.price,
                )
                logger.info(
                    "Updated deal %s: carrier_price=%.2f %s",
                    target_deal_id,
                    action.price,
                    action.currency or "EUR",
                )

    async def _handle_escalate(
        self,
        action: ResponderAction,
        contact_id: str,
        deal_id: str | None,
    ) -> None:
        """Handle escalate action.

        Args:
            action: Action with reason and optional deal_id.
            contact_id: Current contact ID.
            deal_id: Deal ID from responder output.
        """
        target_deal = action.deal_id or deal_id
        if target_deal:
            valid_deal_id = await self.validate_deal_id(target_deal)
            if valid_deal_id:
                await self._deals.set_escalated(
                    valid_deal_id,
                    action.reason or "unknown",
                )
            else:
                logger.warning(
                    "escalate: deal_id=%s not found, skipping set_escalated",
                    target_deal,
                )
        contact = await self._contacts.get_by_id(contact_id)
        await self._notifier.send_escalation(
            contact_name=(contact.first_name if contact else "Невідомий"),
            deal_id=target_deal,
            reason=action.reason or "unknown",
            context="",
        )
        # WF-11: тригерити верифікацію при підозрілих ескалаціях
        await self._maybe_verify(contact_id, action.reason)

    async def _handle_save_driver(
        self,
        action: ResponderAction,
        contact_id: str,
        deal_id: str | None,
    ) -> None:
        """Save driver contact information to a deal.

        Args:
            action: Action with driver_name, driver_phone, etc.
            contact_id: Current carrier contact ID.
            deal_id: Deal ID from responder output.
        """
        if not action.driver_name:
            logger.warning("save_driver: missing driver_name")
            return

        target_deal_id = action.deal_id or deal_id
        if target_deal_id:
            target_deal_id = await self.validate_deal_id(target_deal_id)

        if not target_deal_id:
            active_deals = await self._deals.get_active_deals_for_contact(
                contact_id,
            )
            if active_deals:
                target_deal_id = active_deals[0].id

        if not target_deal_id:
            logger.warning(
                "save_driver: no deal found for contact %s",
                contact_id,
            )
            return

        # Dedup: не зберігати водія якщо такий телефон вже є на цій угоді
        if action.driver_phone:
            existing = await self._deals.get_driver_by_phone(action.driver_phone)
            if existing and existing.deal_id == target_deal_id:
                logger.info(
                    "Driver %s already saved for deal %s, skipping duplicate",
                    action.driver_name,
                    target_deal_id,
                )
                return

        driver = DriverContact(
            id=new_id(),
            deal_id=target_deal_id,
            carrier_contact_id=contact_id,
            driver_name=action.driver_name,
            driver_phone=action.driver_phone,
            driver_tg_id=action.driver_tg_id,
            driver_tg_username=action.driver_tg_username,
            verified=False,
        )
        await self._deals.add_driver(driver)
        logger.info(
            "Driver saved: name=%s, phone=%s, deal=%s",
            action.driver_name,
            action.driver_phone,
            target_deal_id,
        )

    async def _maybe_verify(
        self,
        contact_id: str,
        reason: str | None,
    ) -> None:
        """Trigger WF-11 verification if escalation reason looks suspicious.

        Args:
            contact_id: UUID of the contact being escalated.
            reason: Escalation reason text from Responder.
        """
        if not self._verification or not reason:
            return
        reason_lower = reason.lower()
        if not any(kw in reason_lower for kw in self._VERIFICATION_KEYWORDS):
            return

        contact = await self._contacts.get_by_id(contact_id)
        if contact is None:
            return

        logger.info(
            "Triggering WF-11 verification for contact=%s, reason=%s",
            contact_id,
            reason,
        )
        try:
            result = await self._verification.verify(
                claimer_tg_id=contact.tg_id,
                claimed_contact_id=contact_id,
            )
            logger.info(
                "Verification result for contact=%s: verdict=%s, confidence=%.2f",
                contact_id,
                result.verdict,
                result.confidence,
            )
        except Exception:
            logger.exception("Verification failed for contact %s", contact_id)

    async def _handle_create_deal(
        self,
        action: ResponderAction,
        contact_id: str,
    ) -> None:
        """Create a deal from Responder action.

        Args:
            action: Action with cargo_offer_id and contact_role.
            contact_id: Current contact ID.
        """
        if not action.cargo_offer_id:
            logger.warning("create_deal action missing cargo_offer_id")
            return

        cargo_offer = await self._cargo.get_by_id(action.cargo_offer_id)
        if cargo_offer is None:
            logger.warning(
                "create_deal: cargo_offer_id=%s not found",
                action.cargo_offer_id,
            )
            return

        carrier_id: str | None = None
        if action.contact_role == "carrier":
            carrier_id = contact_id

        deal = await self._deal_manager.create_deal_from_match(
            cargo_offer,
            carrier_contact_id=carrier_id,
        )
        logger.info(
            "Deal created via action: deal_id=%s, cargo=%s, contact=%s",
            deal.id,
            action.cargo_offer_id,
            contact_id,
        )

    async def _handle_forward(
        self,
        action: ResponderAction,
        deal_id: str | None,
        contact_id: str,
    ) -> None:
        """Forward message to the other party of a deal.

        Args:
            action: Action with message text and optional deal_id.
            deal_id: Deal ID from responder output.
            contact_id: Current sender contact ID (to determine OTHER party).
        """
        target_deal_id = action.deal_id or deal_id
        if not target_deal_id or not action.message:
            logger.warning(
                "forward_to_other_party: missing deal_id or message",
            )
            return

        deal = await self._deals.get_by_id(target_deal_id)
        if deal is None:
            logger.warning(
                "forward_to_other_party: deal_id=%s not found",
                target_deal_id,
            )
            return

        # Визначити ІНШУ сторону (не поточного відправника)
        if contact_id == deal.customer_contact_id:
            other_contact_id = deal.carrier_contact_id
        elif contact_id == deal.carrier_contact_id:
            other_contact_id = deal.customer_contact_id
        else:
            other_contact_id = deal.customer_contact_id or deal.carrier_contact_id

        if not other_contact_id:
            logger.warning(
                "forward_to_other_party: no other party in deal %s",
                target_deal_id,
            )
            return

        # Dedup: не відправляти якщо для цього deal вже є out-message
        # за останні 2 хвилини (уникнення повторних forward)
        recent = await self._messages.get_recent_out_for_deal(
            other_contact_id, target_deal_id, within_minutes=2,
        )
        if recent:
            logger.info(
                "forward_to_other_party: skipping duplicate — "
                "recent message already sent to %s for deal %s",
                other_contact_id,
                target_deal_id,
            )
            return

        other_contact = await self._contacts.get_by_id(other_contact_id)
        if other_contact is None:
            logger.warning(
                "forward_to_other_party: contact %s not found",
                other_contact_id,
            )
            return

        await self._client.send_message(
            other_contact.tg_id,
            action.message,
        )
        await self._messages.save_message(
            contact_id=other_contact_id,
            source="dm",
            direction="out",
            text=action.message,
            deal_id=target_deal_id,
        )
        logger.info(
            "Forwarded message to contact %s (deal %s)",
            other_contact_id,
            target_deal_id,
        )

    async def _handle_send_to_channel(
        self,
        action: ResponderAction,
    ) -> None:
        """Send message to carrier channel.

        Args:
            action: Action with message_draft text.
        """
        if not action.message_draft:
            logger.warning("send_to_carrier_channel: missing message_draft")
            return

        channel_id = self._config.carrier_channel_id
        if not channel_id:
            logger.warning(
                "send_to_carrier_channel: carrier_channel_id not configured",
            )
            return

        await self._client.send_message(channel_id, action.message_draft)
        logger.info(
            "Sent to carrier channel: %s",
            action.message_draft[:80],
        )

    async def validate_deal_id(self, deal_id: str | None) -> str | None:
        """Validate that deal_id references an existing deal.

        If the ID is not found in deals, tries to resolve it as
        cargo_offer_id (AI may confuse the two).

        Args:
            deal_id: Deal ID from AI output, may be None or invalid.

        Returns:
            A valid deal_id if found, or None otherwise.
        """
        if deal_id is None:
            return None
        deal = await self._deals.get_by_id(deal_id)
        if deal is not None:
            return deal_id

        # Fallback: AI might have passed cargo_offer_id instead of deal_id
        deal_by_cargo = await self._deals.get_by_cargo_offer_id(deal_id)
        if deal_by_cargo is not None:
            logger.warning(
                "AI returned cargo_offer_id=%s instead of deal_id, resolved to deal_id=%s",
                deal_id,
                deal_by_cargo.id,
            )
            return deal_by_cargo.id

        logger.warning(
            "AI returned non-existent deal_id=%s, resetting to None",
            deal_id,
        )
        return None
