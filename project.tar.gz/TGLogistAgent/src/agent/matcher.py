"""AI-based cargo↔carrier matching (WF-2)."""

from __future__ import annotations

import json
import logging
from typing import Any

from src.agent.codex import PromptLoader
from src.agent.context import ContextAssembler
from src.config import AgentConfig
from src.models.ai_outputs import MatcherOutput
from src.models.cargo import CargoOffer
from src.services.claude_client import ClaudeClient

logger = logging.getLogger(__name__)


class Matcher:
    """Evaluate new cargo offers and decide active/passive/skip (WF-2)."""

    def __init__(
        self,
        claude_client: ClaudeClient,
        prompt_loader: PromptLoader,
        context_assembler: ContextAssembler,
        agent_config: AgentConfig,
    ) -> None:
        self._claude = claude_client
        self._prompt_template = prompt_loader.load_matcher()
        self._context = context_assembler
        self._agent_config = agent_config

    async def evaluate(self, cargo_offer: CargoOffer) -> MatcherOutput:
        """WF-2: Evaluate a cargo offer and decide strategy.

        Args:
            cargo_offer: New cargo offer (type=cargo).

        Returns:
            MatcherOutput with action, reason, candidates.
        """
        logger.info(
            "Matcher evaluating cargo_offer_id=%s, type=%s, route=%s→%s",
            cargo_offer.id, cargo_offer.type,
            cargo_offer.direction_from, cargo_offer.direction_to,
        )

        if not self._agent_config.active_mode_enabled:
            logger.info("Matcher skipped: reason=active mode disabled")
            return MatcherOutput(
                action="passive",
                reason="Active mode disabled in config",
            )

        ctx = await self._context.for_matcher(cargo_offer)
        system_prompt = self._build_system_prompt()
        user_message = self._format_context(ctx)

        result = await self._claude.call_json(
            system_prompt=system_prompt,
            user_message=user_message,
            response_model=MatcherOutput,
            temperature=0.0,
            max_tokens=1024,
        )

        logger.info(
            "Matcher result: action=%s, reason=%s, candidates_count=%d",
            result.action, result.reason, len(result.candidates),
        )
        if result.action == "skip":
            logger.info("Matcher skipped: reason=%s", result.reason)

        return result

    async def check_transport_against_open_cargos(
        self, transport_offer: CargoOffer
    ) -> MatcherOutput | None:
        """For type=transport: check if there are open cargo offers on route.

        Cargo-first principle: we do NOT actively search for cargo.
        We only check existing open cargo_offers.
        """
        logger.info(
            "Matcher checking transport offer_id=%s, route=%s→%s",
            transport_offer.id, transport_offer.direction_from,
            transport_offer.direction_to,
        )

        if not transport_offer.direction_from:
            logger.info("Matcher skipped: reason=no direction_from")
            return None

        ctx = await self._context.for_matcher(transport_offer)
        if not ctx.get("candidate_carriers"):
            logger.info(
                "Matcher skipped: reason=no open cargo on route (cargo-first)",
            )
            return MatcherOutput(
                action="skip",
                reason="No open cargo on this route (cargo-first)",
            )

        result = await self._claude.call_json(
            system_prompt=self._build_system_prompt(),
            user_message=self._format_context(ctx),
            response_model=MatcherOutput,
            temperature=0.0,
            max_tokens=1024,
        )

        logger.info(
            "Matcher transport result: action=%s, reason=%s, candidates_count=%d",
            result.action, result.reason, len(result.candidates),
        )

        return result

    def _build_system_prompt(self) -> str:
        """Build system prompt with config values injected."""
        return self._prompt_template.replace(
            "{margin_threshold}",
            str(self._agent_config.margin_threshold_usd),
        )

    def _format_context(self, ctx: dict[str, Any]) -> str:
        """Format matcher context as user message."""
        parts: list[str] = []

        cargo = ctx.get("cargo", {})
        if cargo:
            parts.append("ВАНТАЖ:")
            parts.append(json.dumps(cargo, ensure_ascii=False, indent=2))
            parts.append("")

        market_avg = ctx.get("market_avg_price")
        if market_avg is not None:
            parts.append(f"СЕРЕДНЯ ЦІНА ПЕРЕВІЗНИКІВ: {market_avg:.0f}€")
            parts.append("")

        candidates = ctx.get("candidate_carriers", [])
        if candidates:
            parts.append(f"ПЕРЕВІЗНИКИ В БАЗІ ({len(candidates)}):")
            parts.append(
                json.dumps(candidates, ensure_ascii=False, indent=2),
            )
            parts.append("")

        parts.append(f"ПОРІГ МАРЖІ: ${self._agent_config.margin_threshold_usd}")
        parts.append(f"КУРС USD: {ctx.get('usd_rate', 41.0)}")
        parts.append(f"КУРС EUR: {ctx.get('eur_rate', 45.0)}")

        return "\n".join(parts)
