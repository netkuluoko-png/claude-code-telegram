"""Prompt loader — loads system prompts from markdown files."""

from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

_PROMPTS_DIR = Path(__file__).parent.parent.parent / "prompts"


class PromptLoader:
    """Load and cache system prompts from prompts/ directory."""

    def __init__(self, prompts_dir: Path | None = None) -> None:
        self._dir = prompts_dir or _PROMPTS_DIR

    def load(self, prompt_name: str) -> str:
        """Load prompt from prompts/{prompt_name}.md."""
        path = self._dir / f"{prompt_name}.md"
        if not path.exists():
            raise FileNotFoundError(f"Prompt not found: {path}")
        return path.read_text(encoding="utf-8")

    def load_responder(self) -> str:
        """Load Responder (main) system prompt."""
        return self.load("agent_codex")

    def load_parser(self) -> str:
        """Load Parser system prompt."""
        return self.load("parser_prompt")

    def load_matcher(self) -> str:
        """Load Matcher system prompt."""
        return self.load("matcher_prompt")

    def load_profiler(self) -> str:
        """Load Profiler system prompt."""
        return self.load("profiler_prompt")

    def load_verification(self) -> str:
        """Load Verification Agent system prompt."""
        return self.load("verification_prompt")

    def load_contact_briefing(self) -> str:
        """Load Contact Briefing system prompt."""
        return self.load("contact_briefing_prompt")
