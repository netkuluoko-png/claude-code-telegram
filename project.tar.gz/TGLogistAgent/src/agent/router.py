"""Router — handles incoming DM messages from contacts (WF-4)."""

from __future__ import annotations

import logging
from collections import defaultdict
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

from telethon import TelegramClient, events

from src.agent.action_handlers import ActionExecutor
from src.agent.context import ContextAssembler
from src.agent.responder import Responder
from src.config import AgentConfig, Settings, is_polish_city, normalize_city
from src.db.repositories.base import new_id
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository
from src.exceptions import ClaudeAPIError
from src.models.ai_outputs import ParserOutput
from src.models.cargo import CargoOffer
from src.models.contact import PriceRecord
from src.parser.message_analyzer import MessageAnalyzer

if TYPE_CHECKING:
    from src.agent.verification import VerificationAgent
    from src.deals.manager import DealManager
    from src.notifications.notifier import Notifier

logger = logging.getLogger(__name__)

_CONFIDENCE_THRESHOLD = 0.7
_MAX_MESSAGES_PER_HOUR = 9999  # Без обмежень для тестування, prod = 3


class Router:
    """Route incoming DM messages to Responder and execute actions (WF-4)."""

    def __init__(
        self,
        client: TelegramClient,
        context_assembler: ContextAssembler,
        responder: Responder,
        analyzer: MessageAnalyzer,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        message_repo: MessageRepository,
        cargo_repo: CargoRepository,
        notifier: Notifier,
        config: Settings,
        agent_config: AgentConfig,
        deal_manager: DealManager,
        on_new_cargo: Callable[[CargoOffer], Awaitable[None]] | None = None,
        verification: VerificationAgent | None = None,
    ) -> None:
        self._client = client
        self._context = context_assembler
        self._responder = responder
        self._analyzer = analyzer
        self._contacts = contact_repo
        self._deals = deal_repo
        self._messages = message_repo
        self._cargo = cargo_repo
        self._notifier = notifier
        self._config = config
        self._agent_config = agent_config
        self._deal_manager = deal_manager
        self._on_new_cargo = on_new_cargo
        self._verification = verification
        self._outgoing_timestamps: dict[str, list[datetime]] = defaultdict(list)

        self._action_executor = ActionExecutor(
            client=client,
            contact_repo=contact_repo,
            deal_repo=deal_repo,
            message_repo=message_repo,
            cargo_repo=cargo_repo,
            notifier=notifier,
            config=config,
            deal_manager=deal_manager,
            verification=verification,
        )

    async def start(self) -> None:
        """Register DM event handler via Telethon."""

        @self._client.on(events.NewMessage(incoming=True, func=lambda e: e.is_private))
        async def handler(event: events.NewMessage.Event) -> None:
            await self._handle_dm(event)

        logger.info("Router DM handler registered")

    async def _handle_dm(self, event: events.NewMessage.Event) -> None:
        """WF-4: full DM processing flow."""
        text = event.message.message
        if not text:
            return

        sender = await event.get_sender()
        if sender is None:
            return
        sender_tg_id: int = sender.id

        # 0. Test whitelist — ігнорувати всіх крім дозволених
        whitelist = self._config.test_whitelist_tg_ids
        if whitelist and sender_tg_id not in whitelist:
            logger.debug("Ignoring DM from non-whitelisted tg_id=%d", sender_tg_id)
            return

        logger.info("DM received from tg_id=%d: %s", sender_tg_id, text[:80])

        # 1. Перевірити чи це логістичний контакт
        contact = await self._contacts.get_by_tg_id(sender_tg_id)
        if contact is None:
            is_whitelisted = bool(whitelist and sender_tg_id in whitelist)
            is_known = is_whitelisted or await self._is_logistics_contact(sender_tg_id)
            if not is_known:
                logger.info("Ignoring DM from unknown non-logistics tg_id=%d", sender_tg_id)
                return
            # Створити новий контакт
            contact = await self._contacts.create(
                tg_id=sender_tg_id,
                first_name=getattr(sender, "first_name", None),
                tg_username=getattr(sender, "username", None),
            )
            logger.info("Created new contact: %s (tg_id=%d)", contact.first_name, sender_tg_id)

        # 2. Зберегти вхідне повідомлення
        in_msg_id = await self._messages.save_message(
            contact_id=contact.id,
            source="dm",
            direction="in",
            text=text,
            tg_msg_id=event.message.id,
        )
        await self._contacts.update_last_seen(contact.id)
        await self._contacts.increment_messages(contact.id)

        # 2.5. B-3 fix: early parse — створити cargo_offer ДО Responder,
        # щоб cargo_offer_id потрапив у контекст і Responder міг створити deal
        early_offer = await self._try_early_parse_cargo(
            text,
            contact.id,
            event.message.id,
        )

        # 3. Зібрати контекст (cargo_offer вже в БД → потрапить в open_cargo_offers)
        try:
            ctx = await self._context.for_responder(contact.id, text)
        except Exception:
            logger.exception("Context assembly failed for contact %s", contact.id)
            await self._messages.add_unprocessed(
                tg_msg_id=event.message.id,
                tg_user_id=sender_tg_id,
                chat_id=None,
                text=text,
                raw_data=None,
                reason="context_error",
            )
            return

        # 4. Викликати Responder
        try:
            output = await self._responder.generate_response(ctx)
        except ClaudeAPIError as e:
            logger.error("Responder API failed: %s", e)
            await self._messages.add_unprocessed(
                tg_msg_id=event.message.id,
                tg_user_id=sender_tg_id,
                chat_id=None,
                text=text,
                raw_data=None,
                reason="api_error",
            )
            return

        # 4.1. Зберегти ai_analysis для вхідного повідомлення
        await self._messages.update_ai_analysis(
            in_msg_id,
            output.model_dump_json(),
        )

        # 4.5. Валідація deal_id — AI може сплутати cargo_offer_id з deal_id
        validated_deal_id = await self._action_executor.validate_deal_id(output.deal_id)
        if validated_deal_id != output.deal_id:
            output.deal_id = validated_deal_id

        # 5. Перевірити confidence
        if output.confidence < _CONFIDENCE_THRESHOLD:
            logger.warning(
                "Low confidence %.2f for contact %s",
                output.confidence,
                contact.id,
            )
            await self._notifier.send_escalation(
                contact_name=contact.first_name or "Невідомий",
                deal_id=output.deal_id,
                reason=f"Low confidence: {output.confidence:.2f}",
                context=output.internal_note,
            )
            # Відповідаємо нейтрально
            await self._client.send_message(
                sender_tg_id,
                "Очікуйте, уточнюю.",
            )
            await self._messages.save_message(
                contact_id=contact.id,
                source="dm",
                direction="out",
                text="Очікуйте, уточнюю.",
                deal_id=output.deal_id,
            )
            return

        # 6. Виконати actions
        await self._action_executor.execute_actions(
            output.actions,
            contact.id,
            output.deal_id,
        )

        # 6.5. Тригерити Matcher якщо early parse створив cargo_offer
        if early_offer and self._on_new_cargo:
            await self._on_new_cargo(early_offer)

        # 7. Rate limit check + відправити відповідь
        if output.response_text:
            if self._check_rate_limit(contact.id):
                await self._client.send_message(sender_tg_id, output.response_text)
                await self._messages.save_message(
                    contact_id=contact.id,
                    source="dm",
                    direction="out",
                    text=output.response_text,
                    deal_id=output.deal_id,
                )
                self._record_outgoing(contact.id)
            else:
                logger.warning("Rate limit hit for contact %s, skipping", contact.id)

    async def _try_early_parse_cargo(
        self,
        text: str,
        contact_id: str,
        tg_msg_id: int,
    ) -> CargoOffer | None:
        """Parse DM as cargo/transport offer before Responder (B-3 fix).

        Runs Parser early so cargo_offer exists in DB before context
        assembly, allowing Responder to reference cargo_offer_id.

        Args:
            text: Raw DM message text.
            contact_id: UUID of the sending contact.
            tg_msg_id: Telegram message ID.

        Returns:
            Created CargoOffer if message is a cargo/transport offer,
            None otherwise.
        """
        from datetime import date as date_type

        try:
            result = await self._analyzer.analyze(
                raw_text=text,
                sender_tg_id=0,  # DM, не група
                source_group="dm",
                current_date=date_type.today(),
            )
        except ClaudeAPIError:
            logger.warning("Early parse failed for DM, skipping")
            return None

        if not result.match or result.details is None:
            return None

        # Перевізник який питає "є щось на X?" — це запит, не вантаж.
        # Не створювати cargo_offer якщо carrier питає наявність без деталей.
        contact = await self._contacts.get_by_id(contact_id)
        if (
            contact
            and contact.type == "carrier"
            and result.type == "cargo"
            and result.details.price is None
            and result.details.weight_tons is None
        ):
            logger.info(
                "Skipping cargo_offer: carrier %s asking availability, not offering cargo",
                contact_id,
            )
            return None

        # Deduplication check (B-7)
        # По source_msg_id
        existing = await self._cargo.get_by_source_msg_id(tg_msg_id, "dm")
        if existing:
            logger.warning(
                "cargo_offer already exists for msg_id=%d, skipping duplicate",
                tg_msg_id,
            )
            return existing

        # Content-based dedup (різні msg_id, ідентичний текст)
        content_dup = await self._cargo.get_recent_duplicate(
            contact_id, text, within_minutes=10,
        )
        if content_dup:
            logger.warning(
                "Duplicate DM cargo content from %s (existing offer %s), skipping",
                contact_id,
                content_dup.id,
            )
            return content_dup

        offer = await self._create_cargo_offer_from_parse(
            result,
            text,
            contact_id,
            tg_msg_id,
        )
        await self._update_contact_from_parse(result, contact_id, tg_msg_id)
        return offer

    async def _create_cargo_offer_from_parse(
        self,
        result: ParserOutput,
        text: str,
        contact_id: str,
        tg_msg_id: int,
    ) -> CargoOffer:
        """Create and persist a CargoOffer from Parser result.

        Args:
            result: Validated ParserOutput with match=True and details.
            text: Raw DM message text.
            contact_id: UUID of the sending contact.
            tg_msg_id: Telegram message ID.

        Returns:
            The persisted CargoOffer.
        """
        details = result.details
        assert details is not None  # noqa: S101

        route_from = normalize_city(details.route_from) if details.route_from else "Невідомо"
        route_to = normalize_city(details.route_to) if details.route_to else None

        now = datetime.now(tz=UTC)
        offer = CargoOffer(
            id=new_id(),
            source_msg_id=tg_msg_id,
            source_group="dm",
            sender_contact_id=contact_id,
            type=result.type or "cargo",
            direction_from=route_from,
            direction_to=route_to,
            container_type=details.container_type,
            weight_tons=details.weight_tons,
            cargo_description=details.cargo_description,
            departure_date=details.departure_date,
            price=details.price,
            price_currency=details.price_currency,
            payment_type=details.payment_type,
            contact_name_raw=details.contact_name,
            contact_phone_raw=details.contact_phone,
            raw_text=text,
            ai_analysis=result.model_dump_json(),
            status="open",
            created_at=now,
            expires_at=now + timedelta(hours=72),
        )
        await self._cargo.create_offer(offer)
        logger.info(
            "Early-parsed cargo offer from DM: %s->%s, type=%s, id=%s",
            route_from,
            route_to,
            result.type,
            offer.id,
        )
        return offer

    async def _update_contact_from_parse(
        self,
        result: ParserOutput,
        contact_id: str,
        tg_msg_id: int,
    ) -> None:
        """Update contact metadata from Parser result.

        Args:
            result: Validated ParserOutput with match=True and details.
            contact_id: UUID of the sending contact.
            tg_msg_id: Telegram message ID (for price record source).
        """
        details = result.details
        if details is None:
            return

        route_from = normalize_city(details.route_from) if details.route_from else "Невідомо"
        route_to = normalize_city(details.route_to) if details.route_to else None

        contact = await self._contacts.get_by_id(contact_id)
        if contact and result.type:
            contact_type = "customer" if result.type == "cargo" else "carrier"
            if contact.type == "unknown":
                await self._contacts.update_type(contact_id, contact_type)

        if route_to:
            await self._contacts.add_or_update_route(contact_id, route_from, route_to)

        if is_polish_city(route_from) or (route_to and is_polish_city(route_to)):
            await self._contacts.set_poland_related(contact_id, True)

        if details.price is not None and route_to:
            now = datetime.now(tz=UTC)
            price_record = PriceRecord(
                id=new_id(),
                contact_id=contact_id,
                route_from=route_from,
                route_to=route_to,
                container_type=details.container_type,
                price=details.price,
                currency=details.price_currency or "EUR",
                date=now.date().isoformat(),
                source="dm",
                source_msg_id=tg_msg_id,
            )
            await self._contacts.add_price_record(price_record)

    async def _is_logistics_contact(self, tg_id: int) -> bool:
        """Check if tg_id belongs to a known logistics contact."""
        contact = await self._contacts.get_by_tg_id(tg_id)
        return contact is not None

    def _check_rate_limit(self, contact_id: str) -> bool:
        """Check if we can send another message (max 3 per hour)."""
        now = datetime.now(tz=UTC)
        cutoff = now - timedelta(hours=1)
        timestamps = self._outgoing_timestamps[contact_id]
        # Прибрати старі
        self._outgoing_timestamps[contact_id] = [t for t in timestamps if t > cutoff]
        return len(self._outgoing_timestamps[contact_id]) < _MAX_MESSAGES_PER_HOUR

    def _record_outgoing(self, contact_id: str) -> None:
        """Record an outgoing message timestamp."""
        self._outgoing_timestamps[contact_id].append(datetime.now(tz=UTC))


# Action handlers: see src/agent/action_handlers.py
