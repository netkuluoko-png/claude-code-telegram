"""Responder — main AI prompt for generating responses (WF-4, step 3)."""

from __future__ import annotations

import json
import logging
from typing import Any

from src.agent.codex import PromptLoader
from src.models.ai_outputs import ResponderOutput
from src.services.claude_client import ClaudeClient

logger = logging.getLogger(__name__)


class Responder:
    """Generate AI responses to incoming DM messages."""

    def __init__(
        self, claude_client: ClaudeClient, prompt_loader: PromptLoader
    ) -> None:
        self._claude = claude_client
        self._system_prompt = prompt_loader.load_responder()

    async def generate_response(
        self, context: dict[str, Any]
    ) -> ResponderOutput:
        """Call Claude API with context, return structured ResponderOutput.

        Args:
            context: Dict from ContextAssembler.for_responder().

        Returns:
            ResponderOutput with response_text, actions, confidence.
        """
        user_message = self._format_context_as_user_message(context)
        return await self._claude.call_json(
            system_prompt=self._system_prompt,
            user_message=user_message,
            response_model=ResponderOutput,
            temperature=0.3,
            max_tokens=1024,
            timeout=60.0,
        )

    def _format_context_as_user_message(
        self, context: dict[str, Any]
    ) -> str:
        """Serialize context dict to a text user message for the prompt."""
        parts: list[str] = []

        # Профіль контакту
        contact = context.get("contact", {})
        if contact:
            parts.append("ПРОФІЛЬ КОНТАКТУ:")
            parts.append(json.dumps(contact, ensure_ascii=False, indent=2))
            parts.append("")

        # Активні угоди
        deals = context.get("active_deals", [])
        if deals:
            parts.append("АКТИВНІ УГОДИ:")
            parts.append(json.dumps(deals, ensure_ascii=False, indent=2))
            parts.append("")

        # Відкриті вантажі/транспорт в базі
        offers = context.get("open_cargo_offers", [])
        if offers:
            parts.append("ВІДКРИТІ ВАНТАЖІ/ТРАНСПОРТ В БАЗІ:")
            parts.append(json.dumps(offers, ensure_ascii=False, indent=2))
            parts.append("")

        # Останні повідомлення
        messages = context.get("recent_messages", [])
        if messages:
            parts.append("ОСТАННІ ПОВІДОМЛЕННЯ:")
            for m in messages:
                sender = "Контакт" if m["from"] == "contact" else "Агент"
                parts.append(f"  [{m.get('date', '')}] {sender}: {m['text']}")
            parts.append("")

        # Нове повідомлення
        new_msg = context.get("new_message", "")
        parts.append(f"НОВЕ ПОВІДОМЛЕННЯ:\n{new_msg}")

        return "\n".join(parts)
