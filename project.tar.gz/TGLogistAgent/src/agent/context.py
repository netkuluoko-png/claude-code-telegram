"""Context Assembly — builds minimal context slices for AI prompts."""

from __future__ import annotations

import asyncio
import logging
from datetime import date
from typing import Any

from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository
from src.models.cargo import CargoOffer

logger = logging.getLogger(__name__)


class ContextAssembler:
    """Assemble minimal context from DB zones for each AI prompt."""

    def __init__(
        self,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        cargo_repo: CargoRepository,
        message_repo: MessageRepository,
    ) -> None:
        self._contacts = contact_repo
        self._deals = deal_repo
        self._cargo = cargo_repo
        self._messages = message_repo

    async def for_responder(
        self, contact_id: str, new_message: str
    ) -> dict[str, Any]:
        """Build context for Responder prompt (WF-4, step 2).

        Zones: 2 (active deals) + 3 (contact slice) + recent messages.
        """
        slice_task = self._contacts.get_contact_slice(contact_id)
        deals_task = self._deals.get_deal_summaries_for_contact(contact_id)
        msgs_task = self._messages.get_recent_messages(contact_id, limit=15)

        contact_slice, deal_summaries, recent_msgs = await asyncio.gather(
            slice_task, deals_task, msgs_task,
        )

        formatted_messages = [
            {
                "from": "contact" if m["direction"] == "in" else "agent",
                "text": m["text"],
                "date": m["created_at"],
            }
            for m in reversed(recent_msgs)  # хронологічний порядок
        ]

        formatted_deals = [
            {
                "deal_id": d.deal_id,
                "route": d.route,
                "status": d.status,
                "date": str(d.departure_date) if d.departure_date else None,
                "my_price": d.my_price,
                "customer_price": d.customer_price,
                "carrier_price": d.carrier_price,
                "margin": d.margin,
                "container_type": d.container_type,
            }
            for d in deal_summaries
        ]

        # Відкриті вантажі — щоб Responder знав що можна запропонувати
        open_offers = await self._cargo.get_open_offers_all(limit=10)
        formatted_offers = [
            {
                "cargo_offer_id": o.id,
                "type": o.type,
                "route": f"{o.direction_from}→{o.direction_to or '?'}",
                "container_type": o.container_type,
                "departure_date": str(o.departure_date) if o.departure_date else None,
                "price": o.price,
                "currency": o.price_currency,
            }
            for o in open_offers
        ]

        return {
            "contact": contact_slice.model_dump() if contact_slice else {},
            "active_deals": formatted_deals,
            "open_cargo_offers": formatted_offers,
            "recent_messages": formatted_messages,
            "new_message": new_message,
        }

    async def for_matcher(self, cargo_offer: CargoOffer) -> dict[str, Any]:
        """Build context for Matcher prompt (WF-2, step 2).

        Zones: 1 (cargo) + 3 (candidate carriers) + market prices.
        """
        market_avg = await self._cargo.get_market_avg_price(
            cargo_offer.direction_from,
            cargo_offer.direction_to or "",
            cargo_offer.container_type,
        )

        # Знайти перевізників для маршруту
        carriers = await self._contacts.get_carriers_for_route(
            cargo_offer.direction_from, min_reliability=0,
        )

        # Надійність замовника
        sender_reliability = 50
        if cargo_offer.sender_contact_id:
            rel = await self._contacts.get_reliability(
                cargo_offer.sender_contact_id,
            )
            if rel:
                sender_reliability = rel.overall_reliability

        # Курси валют
        usd_rate = await self._cargo.get_exchange_rate("USD") or 41.0
        eur_rate = await self._cargo.get_exchange_rate("EUR") or 45.0

        candidates = []
        for c in carriers:
            candidates.append({
                "contact_id": c["id"],
                "name": c.get("first_name", "Невідомий"),
                "reliability": c.get("overall_reliability", 50),
                "last_seen": c.get("last_seen"),
            })

        return {
            "cargo": {
                "route_from": cargo_offer.direction_from,
                "route_to": cargo_offer.direction_to,
                "container_type": cargo_offer.container_type,
                "weight_tons": cargo_offer.weight_tons,
                "departure_date": str(cargo_offer.departure_date)
                if cargo_offer.departure_date
                else None,
                "price": cargo_offer.price,
                "price_currency": cargo_offer.price_currency,
                "sender_reliability": sender_reliability,
            },
            "market_avg_price": market_avg,
            "candidate_carriers": candidates,
            "usd_rate": usd_rate,
            "eur_rate": eur_rate,
        }

    async def for_profiler(
        self, contact_id: str, deal_result: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Build context for Profiler prompt (WF-4, step 9)."""
        profile = await self._contacts.get_full_profile(contact_id)
        unprocessed = await self._messages.get_unprocessed_for_profiler(
            contact_id,
        )

        conversation = [
            {
                "from": "contact" if m["direction"] == "in" else "agent",
                "text": m["text"],
                "date": m["created_at"],
            }
            for m in unprocessed
        ]

        current_profile = {}
        if profile:
            if profile.psychology:
                current_profile["psychology"] = profile.psychology.model_dump()
            if profile.reliability:
                current_profile["reliability"] = profile.reliability.model_dump()

        return {
            "current_profile": current_profile,
            "conversation": conversation,
            "deal_result": deal_result,
            "_message_ids": [m["id"] for m in unprocessed],
        }

    async def for_verification(
        self, claimer_tg_id: int, claimed_contact_id: str | None = None
    ) -> dict[str, Any]:
        """Build context for Verification Agent (WF-11, step 2)."""
        active_deals: list[dict[str, Any]] = []
        driver_match = False
        claimed_name: str | None = None

        if claimed_contact_id:
            contact = await self._contacts.get_by_id(claimed_contact_id)
            if contact:
                claimed_name = contact.first_name
            deals = await self._deals.get_active_deals_for_contact(
                claimed_contact_id,
            )
            active_deals = [
                {"deal_id": d.id, "route": f"{d.route_from}→{d.route_to}", "status": d.status}
                for d in deals
            ]

        # Перевірка по driver_contacts
        driver = await self._deals.get_driver_by_tg_id(claimer_tg_id)
        if driver:
            driver_match = True

        return {
            "claimer_tg_id": claimer_tg_id,
            "claimed_contact_name": claimed_name,
            "claimed_contact_id": claimed_contact_id,
            "active_deals_with_claimed": active_deals,
            "driver_contacts_match": driver_match,
            "shared_groups": [],  # потребує Telethon API
        }

    async def for_contact_briefing(
        self, contact_id: str
    ) -> dict[str, Any]:
        """Build context for Contact Briefing (WF-12, step 3)."""
        profile_task = self._contacts.get_full_profile(contact_id)
        deals_task = self._deals.get_active_deals_for_contact(contact_id)
        msgs_task = self._messages.get_recent_messages(contact_id, limit=20)

        profile, deals, recent_msgs = await asyncio.gather(
            profile_task, deals_task, msgs_task,
        )

        deal_ids = [d.id for d in deals]
        events = await self._deals.get_recent_events_for_deals(
            deal_ids, limit=10,
        )

        # Відкриті вантажі по маршрутах контакту
        open_cargos: list[dict[str, Any]] = []
        if profile and profile.routes:
            for from_city, _to_city in profile.routes[:5]:
                offers = await self._cargo.get_open_offers(route_from=from_city)
                for o in offers:
                    open_cargos.append({
                        "route": f"{o.direction_from}→{o.direction_to}",
                        "container_type": o.container_type,
                        "departure_date": str(o.departure_date)
                        if o.departure_date
                        else None,
                        "price": o.price,
                    })

        contact_data: dict[str, Any] = {}
        if profile:
            contact_data = {
                "name": profile.contact.first_name or "Невідомий",
                "type": profile.contact.type,
                "tg_username": profile.contact.tg_username,
                "phones": profile.phones,
                "last_seen": str(profile.contact.last_seen),
                "active_routes": [f"{f}→{t}" for f, t in profile.routes],
            }
            if profile.psychology:
                contact_data.update({
                    "style": profile.psychology.communication_style,
                    "language": profile.psychology.language,
                    "best_pattern": profile.psychology.best_response_pattern,
                    "trust_level": profile.psychology.trust_level,
                })
            if profile.reliability:
                contact_data.update({
                    "reliability": profile.reliability.overall_reliability,
                    "deals_total": profile.reliability.deals_total,
                    "deals_completed": profile.reliability.deals_completed,
                })

        return {
            "contact": contact_data,
            "active_deals": [
                {
                    "deal_id": d.id,
                    "route": f"{d.route_from}→{d.route_to}",
                    "status": d.status,
                    "date": str(d.departure_date) if d.departure_date else None,
                    "container_type": d.container_type,
                    "my_price": d.customer_price
                    if d.customer_contact_id == contact_id
                    else d.carrier_price,
                }
                for d in deals
            ],
            "recent_deal_events": [
                {
                    "deal_id": e.deal_id,
                    "event_type": e.event_type,
                    "note": e.note,
                    "created_at": str(e.created_at),
                }
                for e in events
            ],
            "recent_messages": [
                {
                    "from": "contact" if m["direction"] == "in" else "agent",
                    "text": m["text"],
                    "date": m["created_at"],
                }
                for m in reversed(recent_msgs)
            ],
            "our_open_cargos": open_cargos,
            "current_date": date.today().isoformat(),
        }
