"""Verification Agent — verify drivers and duplicate accounts (WF-11)."""

from __future__ import annotations

import json
import logging
from typing import Any

from src.agent.codex import PromptLoader
from src.agent.context import ContextAssembler
from src.db.repositories.deal_repo import DealRepository
from src.models.ai_outputs import VerificationOutput
from src.services.claude_client import ClaudeClient

logger = logging.getLogger(__name__)


class VerificationAgent:
    """Verify drivers and handle duplicate account claims (WF-11)."""

    def __init__(
        self,
        claude_client: ClaudeClient,
        prompt_loader: PromptLoader,
        context_assembler: ContextAssembler,
        deal_repo: DealRepository,
    ) -> None:
        self._claude = claude_client
        self._system_prompt = prompt_loader.load_verification()
        self._context = context_assembler
        self._deals = deal_repo

    async def verify(
        self,
        claimer_tg_id: int,
        claimed_contact_id: str | None = None,
    ) -> VerificationOutput:
        """WF-11: Determine if claimer is who they claim to be.

        Args:
            claimer_tg_id: Telegram ID of the claiming account.
            claimed_contact_id: UUID of the contact they claim to be.

        Returns:
            VerificationOutput with verdict, confidence, evidence.
        """
        ctx = await self._context.for_verification(
            claimer_tg_id, claimed_contact_id,
        )
        user_message = self._format_context(ctx)

        output = await self._claude.call_json(
            system_prompt=self._system_prompt,
            user_message=user_message,
            response_model=VerificationOutput,
            temperature=0.0,
            max_tokens=512,
        )

        # Записати event у відповідну угоду
        deals = ctx.get("active_deals_with_claimed", [])
        if deals:
            from src.db.repositories.base import new_id
            from src.models.deal import DealEvent

            for deal_info in deals:
                await self._deals.add_event(DealEvent(
                    id=new_id(),
                    deal_id=deal_info["deal_id"],
                    event_type="verification",
                    note=f"Verdict: {output.verdict}, reason: {output.reason}",
                ))

            # Ескалація при suspicious
            if output.verdict == "suspicious":
                for deal_info in deals:
                    await self._deals.set_escalated(
                        deal_info["deal_id"],
                        f"Suspicious verification: {output.reason}",
                    )

        # Верифікація водія
        if output.verdict == "verified_driver":
            driver = await self._deals.get_driver_by_tg_id(claimer_tg_id)
            if driver:
                await self._deals.verify_driver(driver.id)

        return output

    async def check_driver(
        self, tg_id: int, phone: str | None = None
    ) -> VerificationOutput:
        """Quick driver verification by phone/tg_id without full AI call."""
        # Перевірка по tg_id
        driver = await self._deals.get_driver_by_tg_id(tg_id)
        if driver and driver.verified:
            return VerificationOutput(
                verdict="verified_driver",
                confidence=1.0,
                reason="Already verified driver",
                recommended_action="grant_limited_access",
            )

        # Перевірка по телефону
        if phone:
            driver = await self._deals.get_driver_by_phone(phone)
            if driver:
                await self._deals.verify_driver(driver.id)
                return VerificationOutput(
                    verdict="verified_driver",
                    confidence=0.95,
                    reason="Phone matches driver_contacts",
                    recommended_action="grant_limited_access",
                )

        # Потрібна повна верифікація через AI
        return await self.verify(tg_id)

    def _format_context(self, ctx: dict[str, Any]) -> str:
        """Format verification context as user message."""
        parts = [
            f"CLAIMER tg_id: {ctx.get('claimer_tg_id')}",
            f"CLAIMED CONTACT: {ctx.get('claimed_contact_name', 'невідомий')}",
            f"CLAIMED CONTACT ID: {ctx.get('claimed_contact_id', 'N/A')}",
            f"DRIVER MATCH: {ctx.get('driver_contacts_match', False)}",
            "",
        ]
        deals = ctx.get("active_deals_with_claimed", [])
        if deals:
            parts.append("ACTIVE DEALS:")
            parts.append(json.dumps(deals, ensure_ascii=False, indent=2))
        else:
            parts.append("ACTIVE DEALS: none")

        groups = ctx.get("shared_groups", [])
        parts.append(f"\nSHARED GROUPS: {len(groups)}")

        return "\n".join(parts)
