"""Claude API message analysis for group messages (WF-1, step 3)."""

from __future__ import annotations

import logging
from datetime import date
from pathlib import Path

from src.models.ai_outputs import ParserOutput
from src.services.claude_client import ClaudeClient

logger = logging.getLogger(__name__)

_PROMPTS_DIR = Path(__file__).parent.parent.parent / "prompts"


class MessageAnalyzer:
    """Analyze Telegram group messages via Claude API Parser prompt."""

    def __init__(self, claude_client: ClaudeClient) -> None:
        self._claude = claude_client
        self._system_prompt = self._load_prompt()

    async def analyze(
        self,
        raw_text: str,
        sender_tg_id: int,
        source_group: str,
        current_date: date,
    ) -> ParserOutput:
        """Analyze a group message. Returns structured ParserOutput.

        Args:
            raw_text: Original message text from Telegram group.
            sender_tg_id: Telegram user ID of the sender.
            source_group: Name of the Telegram group.
            current_date: Today's date (for relative date calculation).

        Returns:
            ParserOutput with match, type, reason, and details.
        """
        user_message = self._build_user_message(
            raw_text, sender_tg_id, source_group, current_date,
        )
        return await self._claude.call_json(
            system_prompt=self._system_prompt,
            user_message=user_message,
            response_model=ParserOutput,
            temperature=0.0,
            max_tokens=512,
        )

    def _build_user_message(
        self,
        raw_text: str,
        sender_tg_id: int,
        source_group: str,
        current_date: date,
    ) -> str:
        """Format user message for the Parser prompt."""
        return (
            f"Група: {source_group}\n"
            f"Відправник tg_id: {sender_tg_id}\n"
            f"Сьогоднішня дата: {current_date.isoformat()}\n"
            f"\n"
            f"Повідомлення:\n{raw_text}"
        )

    def _load_prompt(self) -> str:
        """Load system prompt from prompts/parser_prompt.md."""
        prompt_path = _PROMPTS_DIR / "parser_prompt.md"
        return prompt_path.read_text(encoding="utf-8")
