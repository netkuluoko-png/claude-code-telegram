"""Telethon event handler for monitoring Telegram groups (WF-1)."""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime, timedelta

from telethon import TelegramClient, events

from src.config import Settings, is_polish_city, normalize_city
from src.db.repositories.base import new_id
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.message_repo import MessageRepository
from src.exceptions import ClaudeAPIError
from src.models.cargo import CargoOffer
from src.models.contact import PriceRecord
from src.parser.message_analyzer import MessageAnalyzer

logger = logging.getLogger(__name__)


class GroupMonitor:
    """Monitor Telegram groups via Telethon, parse messages via Claude API.

    Implements WF-1: new group message → Parser → cargo_offer → WF-2 trigger.
    """

    def __init__(
        self,
        client: TelegramClient,
        analyzer: MessageAnalyzer,
        contact_repo: ContactRepository,
        cargo_repo: CargoRepository,
        message_repo: MessageRepository,
        config: Settings,
        on_new_cargo: Callable[[CargoOffer], Awaitable[None]],
    ) -> None:
        self._client = client
        self._analyzer = analyzer
        self._contact_repo = contact_repo
        self._cargo_repo = cargo_repo
        self._message_repo = message_repo
        self._config = config
        self._on_new_cargo = on_new_cargo

    async def start(self) -> None:
        """Register event handler for monitored groups (by ID)."""
        group_ids = self._config.monitored_group_ids
        logger.info("Starting group monitor for IDs: %s", group_ids)

        @self._client.on(events.NewMessage(chats=group_ids))
        async def handler(event: events.NewMessage.Event) -> None:
            await self._handle_new_message(event)

    async def _handle_new_message(self, event: events.NewMessage.Event) -> None:
        """WF-1: full processing flow for a group message."""
        text = event.message.message
        if not text or len(text.strip()) < 10:
            return

        sender = await event.get_sender()
        if sender is None:
            return

        sender_tg_id: int = sender.id

        # Test whitelist — ігнорувати всіх крім дозволених
        whitelist = self._config.test_whitelist_tg_ids
        if whitelist and sender_tg_id not in whitelist:
            return

        sender_name: str | None = getattr(sender, "first_name", None)
        sender_username: str | None = getattr(sender, "username", None)
        group_name = ""
        chat = await event.get_chat()
        if chat:
            group_name = getattr(chat, "title", "")

        # 1. Знайти або створити контакт
        contact = await self._contact_repo.get_by_tg_id(sender_tg_id)
        if contact is None:
            contact = await self._contact_repo.create(
                tg_id=sender_tg_id,
                first_name=sender_name,
                tg_username=sender_username,
            )
            logger.info("New contact from group: %s (tg_id=%d)", sender_name, sender_tg_id)

        # 2. Оновити last_seen, total_messages, source_group
        await self._contact_repo.update_last_seen(contact.id)
        await self._contact_repo.increment_messages(contact.id)
        if group_name:
            chat_id = getattr(chat, "id", None)
            await self._contact_repo.add_source_group(contact.id, group_name, chat_id)

        # 3. AI-аналіз
        try:
            from datetime import date as date_type
            result = await self._analyzer.analyze(
                raw_text=text,
                sender_tg_id=sender_tg_id,
                source_group=group_name,
                current_date=date_type.today(),
            )
        except ClaudeAPIError as e:
            logger.error("Parser API failed for msg %s: %s", event.message.id, e)
            await self._message_repo.add_unprocessed(
                tg_msg_id=event.message.id,
                tg_user_id=sender_tg_id,
                chat_id=getattr(chat, "id", None),
                text=text,
                raw_data=None,
                reason="api_error",
            )
            return

        # 4. Зберегти повідомлення
        ai_json = result.model_dump_json()
        await self._message_repo.save_message(
            contact_id=contact.id,
            source=group_name,
            direction="in",
            text=text,
            tg_msg_id=event.message.id,
            ai_analysis=ai_json,
        )

        if not result.match or result.details is None:
            return

        # 5. Deduplication check (B-7)
        # 5a. По source_msg_id (той самий TG msg оброблений двічі)
        existing = await self._cargo_repo.get_by_source_msg_id(
            event.message.id, group_name
        )
        if existing:
            logger.warning(
                "cargo_offer already exists for msg_id=%d in %s, skipping duplicate",
                event.message.id,
                group_name,
            )
            return

        # 5b. Content-based dedup (різні msg_id, але ідентичний текст)
        content_dup = await self._cargo_repo.get_recent_duplicate(
            contact.id, text, within_minutes=10,
        )
        if content_dup:
            logger.warning(
                "Duplicate cargo content from %s (existing offer %s), skipping msg_id=%d",
                contact.id,
                content_dup.id,
                event.message.id,
            )
            return

        # 6. match=true → створити cargo_offer
        details = result.details
        route_from = normalize_city(details.route_from) if details.route_from else "Невідомо"
        route_to = normalize_city(details.route_to) if details.route_to else None

        ttl_hours = 72  # default, може бути з agent_config
        now = datetime.now(tz=UTC)
        expires_at = now + timedelta(hours=ttl_hours)

        offer = CargoOffer(
            id=new_id(),
            source_msg_id=event.message.id,
            source_group=group_name,
            sender_contact_id=contact.id,
            type=result.type or "cargo",
            direction_from=route_from,
            direction_to=route_to,
            container_type=details.container_type,
            weight_tons=details.weight_tons,
            cargo_description=details.cargo_description,
            departure_date=details.departure_date,
            price=details.price,
            price_currency=details.price_currency,
            payment_type=details.payment_type,
            contact_name_raw=details.contact_name,
            contact_phone_raw=details.contact_phone,
            raw_text=text,
            ai_analysis=ai_json,
            status="open",
            created_at=now,
            expires_at=expires_at,
        )
        await self._cargo_repo.create_offer(offer)
        logger.info(
            "New cargo offer: %s→%s, type=%s, id=%s",
            route_from, route_to, result.type, offer.id,
        )

        # 7. Оновити контактні дані
        if result.type:
            contact_type = "customer" if result.type == "cargo" else "carrier"
            if contact.type == "unknown":
                await self._contact_repo.update_type(contact.id, contact_type)
            elif contact.type != contact_type and contact.type != "both":
                await self._contact_repo.update_type(contact.id, "both")

        if route_to:
            await self._contact_repo.add_or_update_route(contact.id, route_from, route_to)

        if is_polish_city(route_from) or (route_to and is_polish_city(route_to)):
            await self._contact_repo.set_poland_related(contact.id, True)

        if details.contact_phone:
            await self._contact_repo.add_phone(contact.id, details.contact_phone, "message")

        if details.price is not None and route_to:
            price_record = PriceRecord(
                id=new_id(),
                contact_id=contact.id,
                route_from=route_from,
                route_to=route_to,
                container_type=details.container_type,
                price=details.price,
                currency=details.price_currency or "EUR",
                date=datetime.now(tz=UTC).date().isoformat(),
                source="message",
                source_msg_id=event.message.id,
            )
            await self._contact_repo.add_price_record(price_record)

        # 8. Тригерити WF-2 (Matcher)
        await self._on_new_cargo(offer)
