"""Profiler — update contact profiles after interactions (WF-4, step 9)."""

from __future__ import annotations

import json
import logging
from typing import Any

from src.agent.codex import PromptLoader
from src.agent.context import ContextAssembler
from src.db.repositories.base import new_id
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.message_repo import MessageRepository
from src.models.ai_outputs import ProfilerOutput
from src.models.contact import PriceRecord
from src.services.claude_client import ClaudeClient

logger = logging.getLogger(__name__)


class Profiler:
    """Update contact profiles after interactions via AI analysis."""

    def __init__(
        self,
        claude_client: ClaudeClient,
        prompt_loader: PromptLoader,
        context_assembler: ContextAssembler,
        contact_repo: ContactRepository,
        message_repo: MessageRepository,
    ) -> None:
        self._claude = claude_client
        self._system_prompt = prompt_loader.load_profiler()
        self._context = context_assembler
        self._contacts = contact_repo
        self._messages = message_repo

    async def update_profile(
        self,
        contact_id: str,
        deal_result: dict[str, Any] | None = None,
    ) -> ProfilerOutput | None:
        """On-demand Profiler call (WF-4, step 9).

        Args:
            contact_id: UUID of the contact to profile.
            deal_result: Optional deal outcome data.

        Returns:
            ProfilerOutput with updates, or None if no unprocessed messages.
        """
        ctx = await self._context.for_profiler(contact_id, deal_result)
        conversation = ctx.get("conversation", [])
        message_ids: list[str] = ctx.get("_message_ids", [])

        if not conversation:
            logger.debug("No unprocessed messages for contact %s", contact_id)
            return None

        user_message = self._format_context(ctx)
        output = await self._claude.call_json(
            system_prompt=self._system_prompt,
            user_message=user_message,
            response_model=ProfilerOutput,
            temperature=0.0,
            max_tokens=1024,
        )

        # Застосувати psychology_updates
        psych = output.psychology_updates.model_dump(exclude_none=True)
        if psych:
            await self._contacts.update_psychology(contact_id, psych)
            logger.info("Psychology updated for %s: %s", contact_id, list(psych.keys()))

        # Застосувати price_updates
        for pu in output.price_updates:
            parts = pu.route.split("→")
            route_from = parts[0].strip() if parts else ""
            route_to = parts[1].strip() if len(parts) > 1 else ""
            record = PriceRecord(
                id=new_id(),
                contact_id=contact_id,
                route_from=route_from,
                route_to=route_to,
                container_type=pu.container_type,
                price=pu.price,
                currency=pu.currency,
                date=__import__("datetime").date.today().isoformat(),
                source="profiler",
            )
            await self._contacts.add_price_record(record)

        # Застосувати reliability_updates
        rel = output.reliability_updates.model_dump(exclude_none=True)
        if rel:
            # dispute_description потребує окремої обробки
            dispute = rel.pop("dispute_description", None)
            if rel:
                await self._contacts.update_reliability(contact_id, rel)
            if dispute:
                existing = await self._contacts.get_reliability(contact_id)
                if existing:
                    disputes = existing.disputes_count + 1
                    await self._contacts.update_reliability(contact_id, {
                        "disputes_count": disputes,
                        "last_dispute_date": __import__("datetime").date.today().isoformat(),
                    })

        # Перерахувати overall_reliability
        if rel or output.price_updates:
            score = await self._contacts.recalculate_reliability(contact_id)
            logger.info("Reliability recalculated for %s: %d", contact_id, score)

        # Позначити повідомлення як оброблені
        if message_ids:
            await self._messages.mark_profiler_processed(message_ids)

        return output

    def _format_context(self, ctx: dict[str, Any]) -> str:
        """Format profiler context as user message."""
        parts: list[str] = []

        profile = ctx.get("current_profile", {})
        if profile:
            parts.append("ПОТОЧНИЙ ПРОФІЛЬ:")
            parts.append(json.dumps(profile, ensure_ascii=False, indent=2, default=str))
            parts.append("")

        conversation = ctx.get("conversation", [])
        if conversation:
            parts.append("НЕЩОДАВНЯ ПЕРЕПИСКА:")
            for m in conversation:
                sender = "Контакт" if m["from"] == "contact" else "Агент"
                parts.append(f"  [{m.get('date', '')}] {sender}: {m['text']}")
            parts.append("")

        deal_result = ctx.get("deal_result")
        if deal_result:
            parts.append("РЕЗУЛЬТАТ УГОДИ:")
            parts.append(json.dumps(deal_result, ensure_ascii=False, indent=2, default=str))

        return "\n".join(parts)
