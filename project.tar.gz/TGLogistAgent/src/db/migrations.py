"""Migration from existing logist_export database to the new schema."""

from __future__ import annotations

import logging
from pathlib import Path

import aiosqlite

from src.config import normalize_city
from src.db.database import init_db
from src.db.repositories.base import new_id, now_iso

logger = logging.getLogger(__name__)


async def migrate_from_export(export_db_path: Path, target_db_path: Path) -> dict[str, int]:
    """Migrate data from old logist_export.db to the new schema.

    Args:
        export_db_path: Path to the old database.
        target_db_path: Path to the new database (will be created/initialized).

    Returns:
        Dict with migration stats: contacts, messages, cargo_offers migrated.
    """
    stats = {"contacts": 0, "messages": 0, "cargo_offers": 0, "phones": 0, "routes": 0}

    # Ініціалізуємо нову БД
    target_conn = await init_db(target_db_path)

    try:
        # Відкриваємо стару БД
        export_conn = await aiosqlite.connect(str(export_db_path))
        export_conn.row_factory = aiosqlite.Row

        try:
            stats = await _do_migrate(export_conn, target_conn, stats)
        finally:
            await export_conn.close()
    finally:
        await target_conn.close()

    logger.info("Migration complete: %s", stats)
    return stats


async def _do_migrate(
    src: aiosqlite.Connection,
    dst: aiosqlite.Connection,
    stats: dict[str, int],
) -> dict[str, int]:
    """Internal migration logic."""
    ts = now_iso()

    # Міграція користувачів
    try:
        async with src.execute("SELECT * FROM users") as cursor:
            async for row in cursor:
                row_dict = dict(row)
                contact_id = new_id()
                tg_id = row_dict.get("tg_id") or row_dict.get("user_id")
                if tg_id is None:
                    continue

                # Визначити тип
                contact_type = _map_contact_type(row_dict.get("type", "unknown"))

                await dst.execute(
                    "INSERT OR IGNORE INTO contacts"
                    " (id, tg_id, tg_username, first_name, last_name, type,"
                    "  first_seen, last_seen, total_messages, created_at, updated_at)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        contact_id, tg_id,
                        row_dict.get("username"),
                        row_dict.get("first_name"),
                        row_dict.get("last_name"),
                        contact_type, ts, ts,
                        row_dict.get("message_count", 0),
                        ts, ts,
                    ),
                )
                stats["contacts"] += 1

                # Ініціалізувати psychology та reliability
                await dst.execute(
                    "INSERT OR IGNORE INTO contact_psychology (contact_id) VALUES (?)",
                    (contact_id,),
                )
                await dst.execute(
                    "INSERT OR IGNORE INTO contact_reliability (contact_id) VALUES (?)",
                    (contact_id,),
                )

                # Телефони
                phones_raw = row_dict.get("phones") or row_dict.get("phone")
                if phones_raw:
                    for phone in _parse_phones(str(phones_raw)):
                        await dst.execute(
                            "INSERT OR IGNORE INTO contact_phones"
                            " (id, contact_id, phone, source, created_at)"
                            " VALUES (?, ?, ?, 'migration', ?)",
                            (new_id(), contact_id, phone, ts),
                        )
                        stats["phones"] += 1

                # Маршрути
                routes_raw = row_dict.get("routes") or row_dict.get("directions")
                if routes_raw:
                    for from_city, to_city in _parse_routes(str(routes_raw)):
                        await dst.execute(
                            "INSERT OR IGNORE INTO contact_routes"
                            " (id, contact_id, from_city, to_city, frequency, last_seen)"
                            " VALUES (?, ?, ?, ?, 1, ?)",
                            (new_id(), contact_id, from_city, to_city, ts),
                        )
                        stats["routes"] += 1

    except Exception as e:
        logger.warning("Could not migrate users table: %s", e)

    # Міграція повідомлень
    try:
        async with src.execute("SELECT * FROM messages") as cursor:
            async for row in cursor:
                row_dict = dict(row)
                text = row_dict.get("text", "")
                if not text:
                    continue

                # Знайти contact_id по tg_id
                sender_tg_id = row_dict.get("user_id") or row_dict.get("tg_id")
                contact_id = None
                if sender_tg_id:
                    c_row = await dst.execute(
                        "SELECT id FROM contacts WHERE tg_id = ?", (sender_tg_id,)
                    )
                    c = await c_row.fetchone()
                    if c:
                        contact_id = c[0]

                source = row_dict.get("group_name", "unknown")
                ai_analysis = row_dict.get("ai_analysis")

                await dst.execute(
                    "INSERT INTO messages"
                    " (id, tg_msg_id, contact_id, source, direction, text,"
                    "  ai_analysis, created_at)"
                    " VALUES (?, ?, ?, ?, 'in', ?, ?, ?)",
                    (
                        new_id(),
                        row_dict.get("msg_id"),
                        contact_id, source, text, ai_analysis, ts,
                    ),
                )
                stats["messages"] += 1

                # Якщо match = true → створити cargo_offer
                is_match = row_dict.get("match") or row_dict.get("is_match")
                if str(is_match).lower() in ("true", "1", "так", "yes"):
                    await dst.execute(
                        "INSERT INTO cargo_offers"
                        " (id, source_msg_id, source_group, sender_contact_id,"
                        "  type, direction_from, raw_text, status, created_at)"
                        " VALUES (?, ?, ?, ?, 'cargo', ?, ?, 'archived', ?)",
                        (
                            new_id(),
                            row_dict.get("msg_id"),
                            source, contact_id,
                            "Невідомо",
                            text, ts,
                        ),
                    )
                    stats["cargo_offers"] += 1

    except Exception as e:
        logger.warning("Could not migrate messages table: %s", e)

    await dst.commit()
    return stats


def _map_contact_type(raw: str) -> str:
    """Map old type names to new enum."""
    mapping = {
        "замовник": "customer",
        "customer": "customer",
        "перевізник": "carrier",
        "carrier": "carrier",
        "обидва": "both",
        "both": "both",
    }
    return mapping.get(raw.lower().strip(), "unknown")


def _parse_phones(raw: str) -> list[str]:
    """Parse phone numbers from a raw string."""
    import re
    phones = re.findall(r"[\+]?\d[\d\s\-\(\)]{8,}", raw)
    result = []
    for p in phones:
        cleaned = "".join(c for c in p if c.isdigit() or c == "+")
        if len(cleaned) >= 10:
            result.append(cleaned)
    return result


async def migrate_add_cargo_source_index(db_path: Path) -> None:
    """Add unique index on cargo_offers(source_msg_id, source_group).

    Idempotent — safe to run multiple times. Removes duplicate rows
    (keeping the earliest) before creating the constraint.

    Args:
        db_path: Path to the database file.
    """
    async with aiosqlite.connect(str(db_path)) as db:
        db.row_factory = aiosqlite.Row

        # Видалити дублікати, залишивши найстаріший запис
        deleted = await db.execute(
            "DELETE FROM cargo_offers WHERE rowid NOT IN ("
            "  SELECT MIN(rowid) FROM cargo_offers"
            "  WHERE source_msg_id IS NOT NULL"
            "  GROUP BY source_msg_id, source_group"
            ") AND source_msg_id IS NOT NULL"
            " AND rowid IN ("
            "  SELECT rowid FROM cargo_offers WHERE source_msg_id IS NOT NULL"
            ")",
        )
        if deleted.rowcount > 0:
            logger.info(
                "Removed %d duplicate cargo_offers before creating index",
                deleted.rowcount,
            )

        await db.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_cargo_source_msg"
            " ON cargo_offers(source_msg_id, source_group)"
            " WHERE source_msg_id IS NOT NULL",
        )
        await db.commit()
        logger.info("Migration B-7: idx_cargo_source_msg created")


def _parse_routes(raw: str) -> list[tuple[str, str]]:
    """Parse routes from a raw string like 'Гданськ→Київ, Одеса→Львів'."""
    routes = []
    for part in raw.replace(";", ",").split(","):
        part = part.strip()
        for sep in ["→", "->", "-", "–"]:
            if sep in part:
                cities = part.split(sep, 1)
                if len(cities) == 2:
                    from_city = normalize_city(cities[0].strip())
                    to_city = normalize_city(cities[1].strip())
                    if from_city and to_city:
                        routes.append((from_city, to_city))
                break
    return routes
