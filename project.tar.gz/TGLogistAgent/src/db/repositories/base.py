"""Base repository with common async CRUD operations."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

import aiosqlite


def new_id() -> str:
    """Generate a new UUID string."""
    return str(uuid.uuid4())


def now_iso() -> str:
    """Current UTC datetime as ISO string."""
    return datetime.now(tz=UTC).isoformat()


class BaseRepository:
    """Base class for all repositories. Provides async DB helpers."""

    def __init__(self, db: aiosqlite.Connection) -> None:
        self._db = db

    async def _execute(
        self, query: str, params: tuple[Any, ...] = ()
    ) -> aiosqlite.Cursor:
        """Execute a query and return cursor."""
        return await self._db.execute(query, params)

    async def _fetch_one(
        self, query: str, params: tuple[Any, ...] = ()
    ) -> dict[str, Any] | None:
        """Fetch a single row as dict, or None."""
        async with self._db.execute(query, params) as cursor:
            row = await cursor.fetchone()
            if row is None:
                return None
            return dict(row)

    async def _fetch_all(
        self, query: str, params: tuple[Any, ...] = ()
    ) -> list[dict[str, Any]]:
        """Fetch all rows as list of dicts."""
        async with self._db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
            return [dict(r) for r in rows]

    async def _insert(self, table: str, data: dict[str, Any]) -> str:
        """Insert a row. Returns the id (must be in data or auto-generated)."""
        if "id" not in data:
            data["id"] = new_id()
        columns = ", ".join(data.keys())
        placeholders = ", ".join("?" for _ in data)
        query = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
        await self._db.execute(query, tuple(data.values()))
        await self._db.commit()
        return str(data["id"])

    async def _update(
        self,
        table: str,
        data: dict[str, Any],
        where: str,
        params: tuple[Any, ...],
    ) -> int:
        """Update rows. Returns number of affected rows."""
        set_clause = ", ".join(f"{k} = ?" for k in data)
        query = f"UPDATE {table} SET {set_clause} WHERE {where}"
        cursor = await self._db.execute(query, (*data.values(), *params))
        await self._db.commit()
        return cursor.rowcount

    async def _delete(
        self, table: str, where: str, params: tuple[Any, ...] = ()
    ) -> int:
        """Delete rows. Returns number of affected rows."""
        query = f"DELETE FROM {table} WHERE {where}"
        cursor = await self._db.execute(query, params)
        await self._db.commit()
        return cursor.rowcount

    async def _count(
        self, table: str, where: str = "1=1", params: tuple[Any, ...] = ()
    ) -> int:
        """Count rows matching condition."""
        query = f"SELECT COUNT(*) FROM {table} WHERE {where}"
        async with self._db.execute(query, params) as cursor:
            row = await cursor.fetchone()
            return row[0] if row else 0
