"""Repository for deals, events, documents, drivers (Zone 2 + Zone 4)."""

from __future__ import annotations

from typing import Any

from src.db.repositories.base import BaseRepository, new_id, now_iso
from src.models.common import DealStatus
from src.models.deal import Deal, DealDocument, DealEvent, DealSummary, DriverContact


class DealRepository(BaseRepository):
    """CRUD for deals and related tables."""

    # ── deals ─────────────────────────────────────────────────

    async def create(self, deal: Deal) -> str:
        """Insert a new deal. Returns the ID."""
        data = {
            "id": deal.id or new_id(),
            "cargo_offer_id": deal.cargo_offer_id,
            "customer_contact_id": deal.customer_contact_id,
            "carrier_contact_id": deal.carrier_contact_id,
            "route_from": deal.route_from,
            "route_to": deal.route_to,
            "container_type": deal.container_type,
            "departure_date": str(deal.departure_date) if deal.departure_date else None,
            "customer_price": deal.customer_price,
            "customer_currency": deal.customer_currency,
            "carrier_price": deal.carrier_price,
            "carrier_currency": deal.carrier_currency,
            "margin": deal.margin,
            "status": deal.status,
            "escalated": 1 if deal.escalated else 0,
            "escalation_reason": deal.escalation_reason,
            "notes": deal.notes,
            "created_at": now_iso(),
            "updated_at": now_iso(),
        }
        return await self._insert("deals", data)

    async def get_by_id(self, deal_id: str) -> Deal | None:
        """Get deal by ID."""
        row = await self._fetch_one("SELECT * FROM deals WHERE id = ?", (deal_id,))
        return Deal(**row) if row else None

    async def get_by_cargo_offer_id(self, cargo_offer_id: str) -> Deal | None:
        """Get deal by its linked cargo_offer_id."""
        row = await self._fetch_one(
            "SELECT * FROM deals WHERE cargo_offer_id = ? LIMIT 1",
            (cargo_offer_id,),
        )
        return Deal(**row) if row else None

    async def get_active_deals_for_contact(self, contact_id: str) -> list[Deal]:
        """Get all active deals involving this contact."""
        rows = await self._fetch_all(
            "SELECT * FROM deals"
            " WHERE (customer_contact_id = ? OR carrier_contact_id = ?)"
            " AND status IN ('prospecting','negotiating','agreed','in_transit')"
            " ORDER BY created_at DESC",
            (contact_id, contact_id),
        )
        return [Deal(**r) for r in rows]

    async def get_deals_by_status(self, status: DealStatus) -> list[Deal]:
        """Get all deals with a given status."""
        rows = await self._fetch_all(
            "SELECT * FROM deals WHERE status = ? ORDER BY created_at DESC",
            (status,),
        )
        return [Deal(**r) for r in rows]

    async def update_status(
        self, deal_id: str, new_status: DealStatus, note: str | None = None
    ) -> None:
        """Update deal status and log event."""
        deal = await self.get_by_id(deal_id)
        old_status = deal.status if deal else None

        await self._update(
            "deals",
            {"status": new_status, "updated_at": now_iso()},
            "id = ?", (deal_id,),
        )
        await self.add_event(DealEvent(
            id=new_id(), deal_id=deal_id, event_type="status_change",
            old_value=old_status, new_value=new_status, note=note,
        ))

    async def update_prices(
        self,
        deal_id: str,
        customer_price: float | None = None,
        carrier_price: float | None = None,
    ) -> None:
        """Update deal prices and recalculate margin."""
        updates: dict[str, Any] = {"updated_at": now_iso()}
        if customer_price is not None:
            updates["customer_price"] = customer_price
        if carrier_price is not None:
            updates["carrier_price"] = carrier_price

        # Перерахунок маржі
        deal = await self.get_by_id(deal_id)
        if deal:
            cp = customer_price if customer_price is not None else deal.customer_price
            crp = carrier_price if carrier_price is not None else deal.carrier_price
            if cp is not None and crp is not None:
                updates["margin"] = cp - crp

        await self._update("deals", updates, "id = ?", (deal_id,))

    async def set_carrier(self, deal_id: str, carrier_contact_id: str) -> None:
        """Set carrier for a deal."""
        await self._update(
            "deals",
            {"carrier_contact_id": carrier_contact_id, "updated_at": now_iso()},
            "id = ?", (deal_id,),
        )

    async def set_escalated(self, deal_id: str, reason: str) -> None:
        """Mark deal as escalated."""
        await self._update(
            "deals",
            {"escalated": 1, "escalation_reason": reason, "updated_at": now_iso()},
            "id = ?", (deal_id,),
        )
        await self.add_event(DealEvent(
            id=new_id(), deal_id=deal_id, event_type="escalation",
            note=reason,
        ))

    async def clear_escalation(self, deal_id: str) -> None:
        """Clear escalation flag."""
        await self._update(
            "deals",
            {"escalated": 0, "escalation_reason": None, "updated_at": now_iso()},
            "id = ?", (deal_id,),
        )

    async def has_active_deal_with_carrier(self, carrier_contact_id: str) -> bool:
        """Check if carrier has any active (non-completed/cancelled) deal."""
        row = await self._fetch_one(
            "SELECT 1 FROM deals"
            " WHERE carrier_contact_id = ?"
            " AND status IN ('prospecting','negotiating','agreed','in_transit')",
            (carrier_contact_id,),
        )
        return row is not None

    # ── deal_events ───────────────────────────────────────────

    async def add_event(self, event: DealEvent) -> None:
        """Insert a deal event."""
        await self._insert("deal_events", {
            "id": event.id or new_id(),
            "deal_id": event.deal_id,
            "event_type": event.event_type,
            "old_value": event.old_value,
            "new_value": event.new_value,
            "note": event.note,
            "created_at": now_iso(),
        })

    async def get_events(self, deal_id: str, limit: int = 10) -> list[DealEvent]:
        """Get recent events for a deal."""
        rows = await self._fetch_all(
            "SELECT * FROM deal_events WHERE deal_id = ?"
            " ORDER BY created_at DESC LIMIT ?",
            (deal_id, limit),
        )
        return [DealEvent(**r) for r in rows]

    async def get_recent_events_for_deals(
        self, deal_ids: list[str], limit: int = 10
    ) -> list[DealEvent]:
        """Get recent events across multiple deals."""
        if not deal_ids:
            return []
        placeholders = ",".join("?" for _ in deal_ids)
        rows = await self._fetch_all(
            f"SELECT * FROM deal_events WHERE deal_id IN ({placeholders})"
            f" ORDER BY created_at DESC LIMIT ?",
            (*deal_ids, limit),
        )
        return [DealEvent(**r) for r in rows]

    # ── deal_documents ────────────────────────────────────────

    async def add_document(self, doc: DealDocument) -> None:
        """Insert a deal document record."""
        await self._insert("deal_documents", {
            "id": doc.id or new_id(),
            "deal_id": doc.deal_id,
            "doc_type": doc.doc_type,
            "file_path": doc.file_path,
            "file_name": doc.file_name,
            "uploaded_by": doc.uploaded_by,
            "forwarded_to": doc.forwarded_to,
            "created_at": now_iso(),
        })

    async def get_documents(self, deal_id: str) -> list[DealDocument]:
        """Get all documents for a deal."""
        rows = await self._fetch_all(
            "SELECT * FROM deal_documents WHERE deal_id = ? ORDER BY created_at",
            (deal_id,),
        )
        return [DealDocument(**r) for r in rows]

    async def mark_forwarded(self, doc_id: str, forwarded_to: str) -> None:
        """Mark document as forwarded."""
        await self._update(
            "deal_documents", {"forwarded_to": forwarded_to}, "id = ?", (doc_id,),
        )

    # ── driver_contacts ───────────────────────────────────────

    async def add_driver(self, driver: DriverContact) -> None:
        """Insert a driver contact."""
        await self._insert("driver_contacts", {
            "id": driver.id or new_id(),
            "deal_id": driver.deal_id,
            "carrier_contact_id": driver.carrier_contact_id,
            "driver_name": driver.driver_name,
            "driver_phone": driver.driver_phone,
            "driver_tg_id": driver.driver_tg_id,
            "driver_tg_username": driver.driver_tg_username,
            "verified": 1 if driver.verified else 0,
            "created_at": now_iso(),
        })

    async def get_driver_by_phone(self, phone: str) -> DriverContact | None:
        """Find driver by phone number."""
        digits = "".join(c for c in phone if c.isdigit())
        if len(digits) >= 10:
            digits = digits[-10:]
        row = await self._fetch_one(
            "SELECT * FROM driver_contacts WHERE driver_phone LIKE ?",
            (f"%{digits}",),
        )
        return DriverContact(**row) if row else None

    async def get_driver_by_tg_id(self, tg_id: int) -> DriverContact | None:
        """Find driver by Telegram ID."""
        row = await self._fetch_one(
            "SELECT * FROM driver_contacts WHERE driver_tg_id = ?", (tg_id,),
        )
        return DriverContact(**row) if row else None

    async def verify_driver(self, driver_id: str) -> None:
        """Mark driver as verified."""
        await self._update("driver_contacts", {"verified": 1}, "id = ?", (driver_id,))

    # ── archive ───────────────────────────────────────────────

    async def archive_old_deals(self, days: int) -> int:
        """Move completed/cancelled deals older than N days to archive."""
        ts = now_iso()
        cursor = await self._db.execute(
            "INSERT INTO deals_archive"
            " SELECT *, ? FROM deals"
            " WHERE status IN ('completed','cancelled')"
            " AND updated_at < datetime('now', ?)",
            (ts, f"-{days} days"),
        )
        count = cursor.rowcount
        if count > 0:
            await self._db.execute(
                "DELETE FROM deals"
                " WHERE status IN ('completed','cancelled')"
                " AND updated_at < datetime('now', ?)",
                (f"-{days} days",),
            )
        await self._db.commit()
        return count

    # ── summary for AI ────────────────────────────────────────

    async def get_deal_summaries_for_contact(
        self, contact_id: str
    ) -> list[DealSummary]:
        """Get lightweight deal summaries for AI context."""
        deals = await self.get_active_deals_for_contact(contact_id)
        summaries = []
        for d in deals:
            is_customer = d.customer_contact_id == contact_id
            my_price = d.customer_price if is_customer else d.carrier_price
            summaries.append(DealSummary(
                deal_id=d.id,
                route=f"{d.route_from}→{d.route_to}",
                status=d.status,
                departure_date=d.departure_date,
                my_price=my_price,
                customer_price=d.customer_price,
                carrier_price=d.carrier_price,
                margin=d.margin,
                container_type=d.container_type,
            ))
        return summaries
