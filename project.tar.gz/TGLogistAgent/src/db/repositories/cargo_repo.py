"""Repository for cargo_offers, market_prices, exchange_rates (Zone 1)."""

from __future__ import annotations

from typing import Any

from src.db.repositories.base import BaseRepository, new_id, now_iso
from src.models.cargo import CargoOffer
from src.models.common import CargoOfferStatus, CargoType


class CargoRepository(BaseRepository):
    """CRUD for cargo offers, market prices, and exchange rates."""

    # ── cargo_offers ──────────────────────────────────────────

    async def create_offer(self, offer: CargoOffer) -> str:
        """Insert a new cargo/transport offer. Returns the ID."""
        data = {
            "id": offer.id or new_id(),
            "source_msg_id": offer.source_msg_id,
            "source_group": offer.source_group,
            "sender_contact_id": offer.sender_contact_id,
            "type": offer.type,
            "direction_from": offer.direction_from,
            "direction_to": offer.direction_to,
            "container_type": offer.container_type,
            "weight_tons": offer.weight_tons,
            "cargo_description": offer.cargo_description,
            "departure_date": str(offer.departure_date) if offer.departure_date else None,
            "price": offer.price,
            "price_currency": offer.price_currency,
            "payment_type": offer.payment_type,
            "contact_name_raw": offer.contact_name_raw,
            "contact_phone_raw": offer.contact_phone_raw,
            "raw_text": offer.raw_text,
            "ai_analysis": offer.ai_analysis,
            "status": offer.status,
            "created_at": now_iso(),
            "expires_at": str(offer.expires_at) if offer.expires_at else None,
        }
        return await self._insert("cargo_offers", data)

    async def get_by_id(self, cargo_id: str) -> CargoOffer | None:
        """Get cargo offer by ID."""
        row = await self._fetch_one("SELECT * FROM cargo_offers WHERE id = ?", (cargo_id,))
        return CargoOffer(**row) if row else None

    async def get_by_source_msg_id(
        self, source_msg_id: int, source_group: str = "dm"
    ) -> CargoOffer | None:
        """Check if cargo offer with this source_msg_id already exists.

        Args:
            source_msg_id: Telegram message ID.
            source_group: Source group name or 'dm' for direct messages.

        Returns:
            Existing CargoOffer if found, None otherwise.
        """
        row = await self._fetch_one(
            "SELECT * FROM cargo_offers WHERE source_msg_id = ? AND source_group = ?",
            (source_msg_id, source_group),
        )
        return CargoOffer(**row) if row else None

    async def get_recent_duplicate(
        self,
        sender_contact_id: str,
        raw_text: str,
        within_minutes: int = 10,
    ) -> CargoOffer | None:
        """Check for duplicate cargo offer with same sender and text.

        Content-based dedup: catches identical messages sent as separate
        TG messages (different msg_id) within a time window.

        Args:
            sender_contact_id: UUID of the sending contact.
            raw_text: Raw message text to match exactly.
            within_minutes: Time window to check for duplicates.

        Returns:
            Existing CargoOffer if duplicate found, None otherwise.
        """
        row = await self._fetch_one(
            "SELECT * FROM cargo_offers"
            " WHERE sender_contact_id = ? AND raw_text = ?"
            " AND created_at > datetime('now', ?)"
            " ORDER BY created_at DESC LIMIT 1",
            (sender_contact_id, raw_text, f"-{within_minutes} minutes"),
        )
        return CargoOffer(**row) if row else None

    async def get_open_offers(
        self,
        cargo_type: CargoType | None = None,
        route_from: str | None = None,
    ) -> list[CargoOffer]:
        """Get open offers, optionally filtered by type and route."""
        query = "SELECT * FROM cargo_offers WHERE status = 'open'"
        params: list[Any] = []
        if cargo_type:
            query += " AND type = ?"
            params.append(cargo_type)
        if route_from:
            query += " AND direction_from = ?"
            params.append(route_from)
        query += " ORDER BY created_at DESC"
        rows = await self._fetch_all(query, tuple(params))
        return [CargoOffer(**r) for r in rows]

    async def get_open_offers_all(self, limit: int = 10) -> list[CargoOffer]:
        """Get all open offers (for Responder context)."""
        rows = await self._fetch_all(
            "SELECT * FROM cargo_offers WHERE status = 'open'"
            " ORDER BY created_at DESC LIMIT ?",
            (limit,),
        )
        return [CargoOffer(**r) for r in rows]

    async def update_status(self, cargo_id: str, new_status: CargoOfferStatus) -> None:
        """Update cargo offer status."""
        await self._update("cargo_offers", {"status": new_status}, "id = ?", (cargo_id,))

    async def expire_old_offers(self, ttl_hours: int) -> int:
        """Expire offers older than TTL. Returns count."""
        cursor = await self._db.execute(
            "UPDATE cargo_offers SET status = 'expired'"
            " WHERE status = 'open'"
            " AND expires_at IS NOT NULL"
            " AND expires_at < datetime('now')",
        )
        await self._db.commit()
        return cursor.rowcount

    async def expire_past_departure(self) -> int:
        """Expire offers where departure_date has passed."""
        cursor = await self._db.execute(
            "UPDATE cargo_offers SET status = 'expired'"
            " WHERE status = 'open'"
            " AND departure_date IS NOT NULL"
            " AND departure_date < date('now')",
        )
        await self._db.commit()
        return cursor.rowcount

    async def delete_expired_older_than(self, days: int) -> int:
        """Delete expired offers older than N days."""
        return await self._delete(
            "cargo_offers",
            "status = 'expired' AND created_at < datetime('now', ?)",
            (f"-{days} days",),
        )

    # ── market_prices ─────────────────────────────────────────

    async def get_market_avg_price(
        self,
        route_from: str,
        route_to: str,
        container_type: str | None = None,
    ) -> float | None:
        """Get latest average carrier price for a route."""
        query = (
            "SELECT avg_carrier_price FROM market_prices"
            " WHERE route_from = ? AND route_to = ?"
        )
        params: list[Any] = [route_from, route_to]
        if container_type:
            query += " AND container_type = ?"
            params.append(container_type)
        query += " ORDER BY period_start DESC LIMIT 1"
        row = await self._fetch_one(query, tuple(params))
        return row["avg_carrier_price"] if row else None

    async def recalculate_market_prices(self) -> int:
        """Recalculate weekly market prices from price_records. Returns count."""
        # Агрегація по маршруту за останній тиждень
        rows = await self._fetch_all(
            "SELECT route_from, route_to, container_type,"
            " AVG(CASE WHEN c.type = 'customer' THEN pr.price END) as avg_cust,"
            " AVG(CASE WHEN c.type = 'carrier' THEN pr.price END) as avg_carr,"
            " COUNT(*) as cnt"
            " FROM price_records pr"
            " JOIN contacts c ON pr.contact_id = c.id"
            " WHERE pr.date >= date('now', '-7 days')"
            " GROUP BY route_from, route_to, container_type",
        )
        count = 0
        for r in rows:
            avg_cust = r["avg_cust"]
            avg_carr = r["avg_carr"]
            spread = (avg_cust - avg_carr) if avg_cust and avg_carr else None
            ts = now_iso()
            await self._db.execute(
                "INSERT INTO market_prices"
                " (id, route_from, route_to, container_type, period, period_start,"
                "  avg_customer_price, avg_carrier_price, avg_spread,"
                "  sample_count, created_at)"
                " VALUES (?, ?, ?, ?, 'week', date('now', '-7 days'),"
                "  ?, ?, ?, ?, ?)"
                " ON CONFLICT(route_from, route_to, container_type, period, period_start)"
                " DO UPDATE SET avg_customer_price = excluded.avg_customer_price,"
                "  avg_carrier_price = excluded.avg_carrier_price,"
                "  avg_spread = excluded.avg_spread,"
                "  sample_count = excluded.sample_count",
                (new_id(), r["route_from"], r["route_to"], r["container_type"],
                 avg_cust, avg_carr, spread, r["cnt"], ts),
            )
            count += 1
        await self._db.commit()
        return count

    # ── exchange_rates ────────────────────────────────────────

    async def get_exchange_rate(self, currency: str) -> float | None:
        """Get exchange rate to UAH for currency."""
        row = await self._fetch_one(
            "SELECT rate_uah FROM exchange_rates WHERE currency = ?",
            (currency.upper(),),
        )
        return row["rate_uah"] if row else None

    async def update_exchange_rate(
        self, currency: str, rate_uah: float, rate_date: str
    ) -> None:
        """Upsert exchange rate."""
        await self._db.execute(
            "INSERT INTO exchange_rates (currency, rate_uah, date, updated_at)"
            " VALUES (?, ?, ?, ?)"
            " ON CONFLICT(currency)"
            " DO UPDATE SET rate_uah = excluded.rate_uah,"
            " date = excluded.date, updated_at = excluded.updated_at",
            (currency.upper(), rate_uah, rate_date, now_iso()),
        )
        await self._db.commit()
