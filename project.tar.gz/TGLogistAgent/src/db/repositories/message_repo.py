"""Repository for messages and unprocessed_messages queue."""

from __future__ import annotations

from typing import Any

from src.db.repositories.base import BaseRepository, new_id, now_iso
from src.models.common import MessageDirection


class MessageRepository(BaseRepository):
    """CRUD for messages and unprocessed message queue."""

    # ── messages ──────────────────────────────────────────────

    async def save_message(
        self,
        contact_id: str | None,
        source: str,
        direction: MessageDirection,
        text: str,
        tg_msg_id: int | None = None,
        ai_analysis: str | None = None,
        deal_id: str | None = None,
    ) -> str:
        """Save a message. Returns the message ID."""
        return await self._insert("messages", {
            "id": new_id(),
            "tg_msg_id": tg_msg_id,
            "contact_id": contact_id,
            "source": source,
            "direction": direction,
            "text": text,
            "ai_analysis": ai_analysis,
            "deal_id": deal_id,
            "profiler_processed": 0,
            "created_at": now_iso(),
        })

    async def get_recent_messages(
        self, contact_id: str, limit: int = 20
    ) -> list[dict[str, Any]]:
        """Get recent messages for a contact, newest first."""
        return await self._fetch_all(
            "SELECT * FROM messages WHERE contact_id = ?"
            " ORDER BY created_at DESC LIMIT ?",
            (contact_id, limit),
        )

    async def get_unprocessed_for_profiler(
        self, contact_id: str
    ) -> list[dict[str, Any]]:
        """Get messages not yet processed by Profiler."""
        return await self._fetch_all(
            "SELECT * FROM messages"
            " WHERE contact_id = ? AND profiler_processed = 0"
            " ORDER BY created_at ASC",
            (contact_id,),
        )

    async def mark_profiler_processed(self, message_ids: list[str]) -> None:
        """Mark messages as processed by Profiler."""
        if not message_ids:
            return
        placeholders = ",".join("?" for _ in message_ids)
        await self._db.execute(
            f"UPDATE messages SET profiler_processed = 1"
            f" WHERE id IN ({placeholders})",
            tuple(message_ids),
        )
        await self._db.commit()

    async def update_ai_analysis(self, message_id: str, ai_analysis: str) -> None:
        """Update ai_analysis field on an existing message."""
        await self._db.execute(
            "UPDATE messages SET ai_analysis = ? WHERE id = ?",
            (ai_analysis, message_id),
        )
        await self._db.commit()

    async def get_recent_out_for_deal(
        self,
        contact_id: str,
        deal_id: str,
        within_minutes: int = 2,
    ) -> list[dict[str, Any]]:
        """Check if an outgoing message was recently sent to contact for this deal.

        Used to avoid duplicate notifications (e.g. forward + proactive).

        Args:
            contact_id: Target contact UUID.
            deal_id: Deal UUID.
            within_minutes: Time window to check.

        Returns:
            List of recent outgoing messages (empty if none).
        """
        return await self._fetch_all(
            "SELECT * FROM messages"
            " WHERE contact_id = ? AND deal_id = ? AND direction = 'out'"
            " AND created_at > datetime('now', ?)"
            " LIMIT 1",
            (contact_id, deal_id, f"-{within_minutes} minutes"),
        )

    # ── unprocessed_messages ──────────────────────────────────

    async def add_unprocessed(
        self,
        tg_msg_id: int | None,
        tg_user_id: int | None,
        chat_id: int | None,
        text: str | None,
        raw_data: str | None,
        reason: str,
    ) -> int:
        """Add a message to the unprocessed queue. Returns row ID."""
        cursor = await self._db.execute(
            "INSERT INTO unprocessed_messages"
            " (tg_msg_id, tg_user_id, chat_id, text, raw_data, reason, received_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)",
            (tg_msg_id, tg_user_id, chat_id, text, raw_data, reason, now_iso()),
        )
        await self._db.commit()
        return cursor.lastrowid or 0

    async def get_unprocessed(self) -> list[dict[str, Any]]:
        """Get all unprocessed messages, oldest first."""
        return await self._fetch_all(
            "SELECT * FROM unprocessed_messages"
            " WHERE processed = 0"
            " ORDER BY received_at ASC",
        )

    async def mark_processed(self, msg_id: int) -> None:
        """Mark unprocessed message as processed."""
        await self._db.execute(
            "UPDATE unprocessed_messages SET processed = 1, processed_at = ?"
            " WHERE id = ?",
            (now_iso(), msg_id),
        )
        await self._db.commit()

    async def get_unprocessed_count(self) -> int:
        """Count unprocessed messages in the queue."""
        return await self._count("unprocessed_messages", "processed = 0")

    # ── archive ───────────────────────────────────────────────

    async def archive_old_messages(self, days: int) -> int:
        """Move messages for completed deals older than N days to archive."""
        ts = now_iso()
        cursor = await self._db.execute(
            "INSERT INTO messages_archive"
            " SELECT m.*, ? FROM messages m"
            " JOIN deals d ON m.deal_id = d.id"
            " WHERE d.status IN ('completed','cancelled')"
            " AND m.created_at < datetime('now', ?)",
            (ts, f"-{days} days"),
        )
        count = cursor.rowcount
        if count > 0:
            await self._db.execute(
                "DELETE FROM messages WHERE id IN ("
                "  SELECT m.id FROM messages m"
                "  JOIN deals d ON m.deal_id = d.id"
                "  WHERE d.status IN ('completed','cancelled')"
                "  AND m.created_at < datetime('now', ?)"
                ")",
                (f"-{days} days",),
            )
        await self._db.commit()
        return count
