"""Repository for contacts and related tables (Zone 3)."""

from __future__ import annotations

from typing import Any

from src.db.repositories.base import BaseRepository, new_id, now_iso
from src.models.common import ContactType, PriceTendency
from src.models.contact import (
    Contact,
    ContactProfile,
    ContactPsychology,
    ContactReliability,
    ContactSlice,
    PriceRecord,
)


class ContactRepository(BaseRepository):
    """CRUD for contacts, phones, routes, groups, psychology, reliability, prices."""

    # ── contacts ──────────────────────────────────────────────

    async def get_by_tg_id(self, tg_id: int) -> Contact | None:
        """Find contact by Telegram user ID."""
        row = await self._fetch_one("SELECT * FROM contacts WHERE tg_id = ?", (tg_id,))
        return Contact(**row) if row else None

    async def get_by_id(self, contact_id: str) -> Contact | None:
        """Find contact by UUID."""
        row = await self._fetch_one("SELECT * FROM contacts WHERE id = ?", (contact_id,))
        return Contact(**row) if row else None

    async def create(
        self,
        tg_id: int,
        first_name: str | None = None,
        last_name: str | None = None,
        tg_username: str | None = None,
        contact_type: ContactType = "unknown",
    ) -> Contact:
        """Create a new contact. Returns the created Contact."""
        contact_id = new_id()
        ts = now_iso()
        await self._db.execute(
            "INSERT INTO contacts (id, tg_id, tg_username, first_name, last_name,"
            " type, first_seen, last_seen, created_at, updated_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (contact_id, tg_id, tg_username, first_name, last_name,
             contact_type, ts, ts, ts, ts),
        )
        # Ініціалізуємо psychology та reliability
        await self._db.execute(
            "INSERT INTO contact_psychology (contact_id) VALUES (?)",
            (contact_id,),
        )
        await self._db.execute(
            "INSERT INTO contact_reliability (contact_id) VALUES (?)",
            (contact_id,),
        )
        await self._db.commit()
        return Contact(
            id=contact_id, tg_id=tg_id, tg_username=tg_username,
            first_name=first_name, last_name=last_name, type=contact_type,
            first_seen=ts, last_seen=ts, created_at=ts, updated_at=ts,
        )

    async def update_last_seen(self, contact_id: str) -> None:
        """Update last_seen timestamp."""
        await self._update(
            "contacts", {"last_seen": now_iso(), "updated_at": now_iso()},
            "id = ?", (contact_id,),
        )

    async def increment_messages(self, contact_id: str) -> None:
        """Increment total_messages counter."""
        await self._db.execute(
            "UPDATE contacts SET total_messages = total_messages + 1,"
            " updated_at = ? WHERE id = ?",
            (now_iso(), contact_id),
        )
        await self._db.commit()

    async def update_type(self, contact_id: str, contact_type: ContactType) -> None:
        """Update contact type."""
        await self._update(
            "contacts", {"type": contact_type, "updated_at": now_iso()},
            "id = ?", (contact_id,),
        )

    async def search_by_phone(self, phone: str) -> Contact | None:
        """Find contact by phone number (partial match)."""
        # Нормалізуємо пошук — шукаємо по останніх 10 цифрах
        digits = "".join(c for c in phone if c.isdigit())
        if len(digits) >= 10:
            digits = digits[-10:]
        row = await self._fetch_one(
            "SELECT c.* FROM contacts c JOIN contact_phones cp ON c.id = cp.contact_id"
            " WHERE cp.phone LIKE ?",
            (f"%{digits}",),
        )
        return Contact(**row) if row else None

    async def search_by_username(self, username: str) -> Contact | None:
        """Find contact by Telegram username."""
        clean = username.lstrip("@").lower()
        row = await self._fetch_one(
            "SELECT * FROM contacts WHERE LOWER(tg_username) = ?", (clean,)
        )
        return Contact(**row) if row else None

    # ── phones ────────────────────────────────────────────────

    async def add_phone(self, contact_id: str, phone: str, source: str = "message") -> None:
        """Add phone number if not exists."""
        await self._db.execute(
            "INSERT OR IGNORE INTO contact_phones (id, contact_id, phone, source, created_at)"
            " VALUES (?, ?, ?, ?, ?)",
            (new_id(), contact_id, phone, source, now_iso()),
        )
        await self._db.commit()

    async def get_phones(self, contact_id: str) -> list[str]:
        """Get all phone numbers for contact."""
        rows = await self._fetch_all(
            "SELECT phone FROM contact_phones WHERE contact_id = ?", (contact_id,)
        )
        return [r["phone"] for r in rows]

    # ── routes ────────────────────────────────────────────────

    async def add_or_update_route(
        self, contact_id: str, from_city: str, to_city: str
    ) -> None:
        """Add route or increment frequency."""
        existing = await self._fetch_one(
            "SELECT id, frequency FROM contact_routes"
            " WHERE contact_id = ? AND from_city = ? AND to_city = ?",
            (contact_id, from_city, to_city),
        )
        if existing:
            await self._update(
                "contact_routes",
                {"frequency": existing["frequency"] + 1, "last_seen": now_iso()},
                "id = ?", (existing["id"],),
            )
        else:
            await self._insert("contact_routes", {
                "id": new_id(), "contact_id": contact_id,
                "from_city": from_city, "to_city": to_city,
                "frequency": 1, "last_seen": now_iso(),
            })

    async def get_routes(self, contact_id: str) -> list[tuple[str, str]]:
        """Get all routes for contact as (from, to) tuples."""
        rows = await self._fetch_all(
            "SELECT from_city, to_city FROM contact_routes WHERE contact_id = ?",
            (contact_id,),
        )
        return [(r["from_city"], r["to_city"]) for r in rows]

    async def get_carriers_for_route(
        self, from_city: str, min_reliability: int = 0
    ) -> list[dict[str, Any]]:
        """Find carriers with route matching from_city and reliability above threshold."""
        return await self._fetch_all(
            "SELECT c.*, cr.overall_reliability, cr2.from_city, cr2.to_city"
            " FROM contacts c"
            " JOIN contact_reliability cr ON c.id = cr.contact_id"
            " JOIN contact_routes cr2 ON c.id = cr2.contact_id"
            " WHERE c.type IN ('carrier', 'both')"
            " AND cr2.from_city = ?"
            " AND cr.overall_reliability >= ?"
            " ORDER BY cr.overall_reliability DESC",
            (from_city, min_reliability),
        )

    # ── source groups ─────────────────────────────────────────

    async def add_source_group(
        self, contact_id: str, group_name: str, group_tg_id: int | None = None
    ) -> None:
        """Record that contact was seen in a group."""
        ts = now_iso()
        await self._db.execute(
            "INSERT INTO contact_source_groups"
            " (id, contact_id, group_name, group_tg_id, first_seen, last_seen)"
            " VALUES (?, ?, ?, ?, ?, ?)"
            " ON CONFLICT(contact_id, group_name)"
            " DO UPDATE SET last_seen = excluded.last_seen",
            (new_id(), contact_id, group_name, group_tg_id, ts, ts),
        )
        await self._db.commit()

    async def is_from_monitored_group(
        self, contact_id: str, monitored_groups: list[str]
    ) -> bool:
        """Check if contact was ever seen in one of the monitored groups."""
        if not monitored_groups:
            return False
        placeholders = ",".join("?" for _ in monitored_groups)
        row = await self._fetch_one(
            f"SELECT 1 FROM contact_source_groups"
            f" WHERE contact_id = ? AND group_name IN ({placeholders})",
            (contact_id, *monitored_groups),
        )
        return row is not None

    # ── psychology ────────────────────────────────────────────

    async def get_psychology(self, contact_id: str) -> ContactPsychology | None:
        """Get psychological profile."""
        row = await self._fetch_one(
            "SELECT * FROM contact_psychology WHERE contact_id = ?", (contact_id,)
        )
        return ContactPsychology(**row) if row else None

    async def update_psychology(self, contact_id: str, updates: dict[str, Any]) -> None:
        """Update psychology fields (only non-None values)."""
        filtered = {k: v for k, v in updates.items() if v is not None}
        if not filtered:
            return
        filtered["updated_at"] = now_iso()
        await self._update("contact_psychology", filtered, "contact_id = ?", (contact_id,))

    # ── reliability ───────────────────────────────────────────

    async def get_reliability(self, contact_id: str) -> ContactReliability | None:
        """Get reliability metrics."""
        row = await self._fetch_one(
            "SELECT * FROM contact_reliability WHERE contact_id = ?", (contact_id,)
        )
        return ContactReliability(**row) if row else None

    async def update_reliability(self, contact_id: str, updates: dict[str, Any]) -> None:
        """Update reliability fields."""
        filtered = {k: v for k, v in updates.items() if v is not None}
        if not filtered:
            return
        filtered["updated_at"] = now_iso()
        await self._update("contact_reliability", filtered, "contact_id = ?", (contact_id,))

    async def recalculate_reliability(self, contact_id: str) -> int:
        """Recalculate overall_reliability using the formula from 03_CONTACT_PROFILE.md."""
        rel = await self.get_reliability(contact_id)
        if rel is None:
            return 50

        score = 50
        score += min(rel.deals_completed * 5, 50)
        score -= rel.deals_cancelled * 15
        score -= int(rel.avg_payment_delay_days * 2)
        score += (rel.communication_culture - 3) * 5
        score -= rel.disputes_count * 10
        score = max(0, min(100, score))

        await self.update_reliability(contact_id, {"overall_reliability": score})
        return score

    # ── price records ─────────────────────────────────────────

    async def add_price_record(self, record: PriceRecord) -> None:
        """Insert a price observation."""
        await self._insert("price_records", {
            "id": record.id or new_id(),
            "contact_id": record.contact_id,
            "route_from": record.route_from,
            "route_to": record.route_to,
            "container_type": record.container_type,
            "price": record.price,
            "currency": record.currency,
            "date": record.date,
            "source": record.source,
            "source_msg_id": record.source_msg_id,
            "created_at": now_iso(),
        })

    async def get_price_records(
        self,
        contact_id: str,
        route_from: str | None = None,
        route_to: str | None = None,
    ) -> list[PriceRecord]:
        """Get price history for contact, optionally filtered by route."""
        query = "SELECT * FROM price_records WHERE contact_id = ?"
        params: list[Any] = [contact_id]
        if route_from:
            query += " AND route_from = ?"
            params.append(route_from)
        if route_to:
            query += " AND route_to = ?"
            params.append(route_to)
        query += " ORDER BY date DESC"
        rows = await self._fetch_all(query, tuple(params))
        return [PriceRecord(**r) for r in rows]

    async def get_price_tendency(
        self, contact_id: str, route_from: str, route_to: str
    ) -> PriceTendency:
        """Calculate price tendency vs market average."""
        # Середня ціна контакту
        contact_avg = await self._fetch_one(
            "SELECT AVG(price) as avg_p FROM price_records"
            " WHERE contact_id = ? AND route_from = ? AND route_to = ?",
            (contact_id, route_from, route_to),
        )
        if not contact_avg or contact_avg["avg_p"] is None:
            return "at_market"

        # Середня ринкова
        market_avg = await self._fetch_one(
            "SELECT AVG(price) as avg_p FROM price_records"
            " WHERE route_from = ? AND route_to = ?",
            (route_from, route_to),
        )
        if not market_avg or market_avg["avg_p"] is None:
            return "at_market"

        deviation = (contact_avg["avg_p"] - market_avg["avg_p"]) / market_avg["avg_p"]
        if deviation < -0.05:
            return "below_market"
        elif deviation > 0.05:
            return "above_market"
        return "at_market"

    async def set_poland_related(self, contact_id: str, value: bool) -> None:
        """Set poland_related flag on contact."""
        await self._update(
            "contacts", {"poland_related": int(value), "updated_at": now_iso()},
            "id = ?", (contact_id,),
        )

    # ── context slice (для AI) ────────────────────────────────

    async def get_contact_slice(self, contact_id: str) -> ContactSlice | None:
        """Build minimal context slice for AI prompts."""
        contact = await self.get_by_id(contact_id)
        if contact is None:
            return None

        psychology = await self.get_psychology(contact_id)
        reliability = await self.get_reliability(contact_id)
        routes = await self.get_routes(contact_id)

        route_strings = [f"{f}→{t}" for f, t in routes]

        return ContactSlice(
            id=contact.id,
            name=contact.first_name or "Невідомий",
            type=contact.type,
            reliability=reliability.overall_reliability if reliability else 50,
            style=psychology.communication_style if psychology else None,
            language=psychology.language if psychology else None,
            best_pattern=psychology.best_response_pattern if psychology else None,
            active_routes=route_strings,
            trust_level=psychology.trust_level if psychology else "new",
            bargaining=psychology.bargaining_behavior if psychology else None,
        )

    async def get_full_profile(self, contact_id: str) -> ContactProfile | None:
        """Build full contact profile (all sub-tables)."""
        contact = await self.get_by_id(contact_id)
        if contact is None:
            return None

        psychology = await self.get_psychology(contact_id)
        reliability = await self.get_reliability(contact_id)
        phones = await self.get_phones(contact_id)
        routes = await self.get_routes(contact_id)

        groups_rows = await self._fetch_all(
            "SELECT group_name FROM contact_source_groups WHERE contact_id = ?",
            (contact_id,),
        )
        groups = [r["group_name"] for r in groups_rows]

        return ContactProfile(
            contact=contact,
            psychology=psychology,
            reliability=reliability,
            phones=phones,
            routes=routes,
            source_groups=groups,
        )
