"""Repository for agent_config table."""

from __future__ import annotations

from typing import Any

from src.db.repositories.base import BaseRepository, now_iso


class ConfigRepository(BaseRepository):
    """CRUD for agent_config key-value store."""

    async def get_all(self) -> dict[str, str]:
        """Get all config key-value pairs."""
        rows = await self._fetch_all("SELECT key, value FROM agent_config")
        return {r["key"]: r["value"] for r in rows}

    async def get(self, key: str) -> str | None:
        """Get a single config value by key."""
        row = await self._fetch_one(
            "SELECT value FROM agent_config WHERE key = ?", (key,)
        )
        return row["value"] if row else None

    async def set(self, key: str, value: Any) -> None:
        """Upsert a config value."""
        await self._db.execute(
            "INSERT INTO agent_config (key, value, updated_at) VALUES (?, ?, ?)"
            " ON CONFLICT(key) DO UPDATE SET value = excluded.value,"
            " updated_at = excluded.updated_at",
            (key, str(value), now_iso()),
        )
        await self._db.commit()
