-- LogistAgent Database Schema
-- SQLite, 18 tables + 2 archive + indexes
-- Order respects FK dependencies

PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

-- ============================================================
-- Level 0: no FK dependencies
-- ============================================================

CREATE TABLE IF NOT EXISTS contacts (
    id              TEXT PRIMARY KEY,
    tg_id           INTEGER UNIQUE NOT NULL,
    tg_username     TEXT,
    first_name      TEXT,
    last_name       TEXT,
    type            TEXT CHECK(type IN ('customer','carrier','both','unknown')) DEFAULT 'unknown',
    poland_related  INTEGER DEFAULT 0,
    first_seen      TEXT NOT NULL,
    last_seen       TEXT NOT NULL,
    total_messages  INTEGER DEFAULT 0,
    created_at      TEXT DEFAULT (datetime('now')),
    updated_at      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS agent_config (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL,
    updated_at  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS exchange_rates (
    currency    TEXT PRIMARY KEY,
    rate_uah    REAL NOT NULL,
    date        TEXT NOT NULL,
    updated_at  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS unprocessed_messages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tg_msg_id       INTEGER,
    tg_user_id      INTEGER,
    chat_id         INTEGER,
    text            TEXT,
    raw_data        TEXT,
    reason          TEXT,
    received_at     TEXT DEFAULT (datetime('now')),
    processed       INTEGER DEFAULT 0,
    processed_at    TEXT
);

-- ============================================================
-- Level 1: FK -> contacts
-- ============================================================

CREATE TABLE IF NOT EXISTS contact_phones (
    id          TEXT PRIMARY KEY,
    contact_id  TEXT NOT NULL REFERENCES contacts(id),
    phone       TEXT NOT NULL,
    source      TEXT,
    created_at  TEXT DEFAULT (datetime('now')),
    UNIQUE(contact_id, phone)
);

CREATE TABLE IF NOT EXISTS contact_routes (
    id          TEXT PRIMARY KEY,
    contact_id  TEXT NOT NULL REFERENCES contacts(id),
    from_city   TEXT NOT NULL,
    to_city     TEXT NOT NULL,
    direction   TEXT,
    frequency   INTEGER DEFAULT 1,
    last_seen   TEXT,
    UNIQUE(contact_id, from_city, to_city)
);

CREATE TABLE IF NOT EXISTS contact_source_groups (
    id          TEXT PRIMARY KEY,
    contact_id  TEXT NOT NULL REFERENCES contacts(id),
    group_name  TEXT NOT NULL,
    group_tg_id INTEGER,
    first_seen  TEXT,
    last_seen   TEXT,
    UNIQUE(contact_id, group_name)
);

CREATE TABLE IF NOT EXISTS contact_psychology (
    contact_id              TEXT PRIMARY KEY REFERENCES contacts(id),
    communication_style     TEXT,
    language                TEXT,
    response_speed          TEXT,
    bargaining_behavior     TEXT,
    preferred_contact_time  TEXT,
    typical_message_length  TEXT,
    emoji_usage             TEXT,
    best_response_pattern   TEXT,
    trust_level             TEXT DEFAULT 'new',
    updated_at              TEXT
);

CREATE TABLE IF NOT EXISTS contact_reliability (
    contact_id              TEXT PRIMARY KEY REFERENCES contacts(id),
    deals_total             INTEGER DEFAULT 0,
    deals_completed         INTEGER DEFAULT 0,
    deals_cancelled         INTEGER DEFAULT 0,
    cancellation_rate       REAL DEFAULT 0,
    payment_punctuality     TEXT DEFAULT 'unknown',
    avg_payment_delay_days  REAL DEFAULT 0,
    communication_culture   INTEGER DEFAULT 3,
    disputes_count          INTEGER DEFAULT 0,
    who_cancelled           TEXT,
    last_dispute_date       TEXT,
    dispute_descriptions    TEXT,
    overall_reliability     INTEGER DEFAULT 50,
    manual_notes            TEXT,
    updated_at              TEXT
);

CREATE TABLE IF NOT EXISTS price_records (
    id              TEXT PRIMARY KEY,
    contact_id      TEXT NOT NULL REFERENCES contacts(id),
    route_from      TEXT NOT NULL,
    route_to        TEXT NOT NULL,
    container_type  TEXT,
    price           REAL NOT NULL,
    currency        TEXT DEFAULT 'EUR',
    date            TEXT NOT NULL,
    source          TEXT DEFAULT 'message',
    source_msg_id   INTEGER,
    created_at      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS cargo_offers (
    id                  TEXT PRIMARY KEY,
    source_msg_id       INTEGER,
    source_group        TEXT,
    sender_contact_id   TEXT REFERENCES contacts(id),
    type                TEXT CHECK(type IN ('cargo','transport')) NOT NULL,
    direction_from      TEXT NOT NULL,
    direction_to        TEXT,
    container_type      TEXT,
    weight_tons         REAL,
    cargo_description   TEXT,
    departure_date      TEXT,
    price               REAL,
    price_currency      TEXT,
    payment_type        TEXT,
    contact_name_raw    TEXT,
    contact_phone_raw   TEXT,
    raw_text            TEXT NOT NULL,
    ai_analysis         TEXT,
    status              TEXT DEFAULT 'open' CHECK(status IN ('open','matched','expired','archived')),
    created_at          TEXT DEFAULT (datetime('now')),
    expires_at          TEXT
);

-- ============================================================
-- Level 2: FK -> contacts + cargo_offers
-- ============================================================

CREATE TABLE IF NOT EXISTS deals (
    id                  TEXT PRIMARY KEY,
    cargo_offer_id      TEXT REFERENCES cargo_offers(id),
    customer_contact_id TEXT REFERENCES contacts(id),
    carrier_contact_id  TEXT REFERENCES contacts(id),
    route_from          TEXT NOT NULL,
    route_to            TEXT NOT NULL,
    container_type      TEXT,
    departure_date      TEXT,
    customer_price      REAL,
    customer_currency   TEXT DEFAULT 'EUR',
    carrier_price       REAL,
    carrier_currency    TEXT DEFAULT 'EUR',
    margin              REAL,
    status              TEXT DEFAULT 'prospecting' CHECK(status IN (
                            'prospecting','negotiating','agreed','in_transit',
                            'completed','cancelled','disputed'
                        )),
    escalated           INTEGER DEFAULT 0,
    escalation_reason   TEXT,
    notes               TEXT,
    created_at          TEXT DEFAULT (datetime('now')),
    updated_at          TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS market_prices (
    id                  TEXT PRIMARY KEY,
    route_from          TEXT NOT NULL,
    route_to            TEXT NOT NULL,
    container_type      TEXT,
    period              TEXT NOT NULL,
    period_start        TEXT NOT NULL,
    avg_customer_price  REAL,
    avg_carrier_price   REAL,
    avg_spread          REAL,
    sample_count        INTEGER,
    currency            TEXT DEFAULT 'EUR',
    created_at          TEXT DEFAULT (datetime('now')),
    UNIQUE(route_from, route_to, container_type, period, period_start)
);

-- Messages: FK -> contacts. deal_id FK added separately.
CREATE TABLE IF NOT EXISTS messages (
    id                  TEXT PRIMARY KEY,
    tg_msg_id           INTEGER,
    contact_id          TEXT REFERENCES contacts(id),
    source              TEXT NOT NULL,
    direction           TEXT CHECK(direction IN ('in','out')),
    text                TEXT NOT NULL,
    ai_analysis         TEXT,
    deal_id             TEXT REFERENCES deals(id),
    profiler_processed  INTEGER DEFAULT 0,
    created_at          TEXT DEFAULT (datetime('now'))
);

-- ============================================================
-- Level 3: FK -> deals
-- ============================================================

CREATE TABLE IF NOT EXISTS deal_events (
    id          TEXT PRIMARY KEY,
    deal_id     TEXT NOT NULL REFERENCES deals(id),
    event_type  TEXT NOT NULL,
    old_value   TEXT,
    new_value   TEXT,
    note        TEXT,
    created_at  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS deal_documents (
    id          TEXT PRIMARY KEY,
    deal_id     TEXT NOT NULL REFERENCES deals(id),
    doc_type    TEXT,
    file_path   TEXT,
    file_name   TEXT,
    uploaded_by TEXT REFERENCES contacts(id),
    forwarded_to TEXT REFERENCES contacts(id),
    created_at  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS driver_contacts (
    id                  TEXT PRIMARY KEY,
    deal_id             TEXT REFERENCES deals(id),
    carrier_contact_id  TEXT REFERENCES contacts(id),
    driver_name         TEXT NOT NULL,
    driver_phone        TEXT,
    driver_tg_id        INTEGER,
    driver_tg_username  TEXT,
    verified            INTEGER DEFAULT 0,
    created_at          TEXT DEFAULT (datetime('now'))
);

-- ============================================================
-- Archive tables (no FK, mirror structure)
-- ============================================================

CREATE TABLE IF NOT EXISTS deals_archive (
    id TEXT, cargo_offer_id TEXT, customer_contact_id TEXT, carrier_contact_id TEXT,
    route_from TEXT, route_to TEXT, container_type TEXT, departure_date TEXT,
    customer_price REAL, customer_currency TEXT, carrier_price REAL, carrier_currency TEXT,
    margin REAL, status TEXT, escalated INTEGER, escalation_reason TEXT, notes TEXT,
    created_at TEXT, updated_at TEXT, archived_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS messages_archive (
    id TEXT, tg_msg_id INTEGER, contact_id TEXT, source TEXT, direction TEXT,
    text TEXT, ai_analysis TEXT, deal_id TEXT, profiler_processed INTEGER,
    created_at TEXT, archived_at TEXT DEFAULT (datetime('now'))
);

-- ============================================================
-- Indexes
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_price_route ON price_records(route_from, route_to, date);
CREATE INDEX IF NOT EXISTS idx_price_contact ON price_records(contact_id, date);
CREATE UNIQUE INDEX IF NOT EXISTS idx_cargo_source_msg
ON cargo_offers(source_msg_id, source_group)
WHERE source_msg_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_cargo_status ON cargo_offers(status, type);
CREATE INDEX IF NOT EXISTS idx_cargo_route ON cargo_offers(direction_from, direction_to, status);
CREATE INDEX IF NOT EXISTS idx_cargo_date ON cargo_offers(departure_date, status);
CREATE INDEX IF NOT EXISTS idx_deals_status ON deals(status);
CREATE INDEX IF NOT EXISTS idx_deals_customer ON deals(customer_contact_id, status);
CREATE INDEX IF NOT EXISTS idx_deals_carrier ON deals(carrier_contact_id, status);
CREATE INDEX IF NOT EXISTS idx_deal_events ON deal_events(deal_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_contact ON messages(contact_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_deal ON messages(deal_id, created_at);
CREATE INDEX IF NOT EXISTS idx_driver_deal ON driver_contacts(deal_id);
CREATE INDEX IF NOT EXISTS idx_driver_tg ON driver_contacts(driver_tg_id);
CREATE INDEX IF NOT EXISTS idx_driver_phone ON driver_contacts(driver_phone);

-- ============================================================
-- Seed: default agent_config
-- ============================================================

INSERT OR IGNORE INTO agent_config VALUES ('margin_threshold_usd', '100', datetime('now'));
INSERT OR IGNORE INTO agent_config VALUES ('max_carriers_to_contact', '3', datetime('now'));
INSERT OR IGNORE INTO agent_config VALUES ('response_wait_hours', '2', datetime('now'));
INSERT OR IGNORE INTO agent_config VALUES ('cargo_ttl_hours', '72', datetime('now'));
INSERT OR IGNORE INTO agent_config VALUES ('escalation_amount_eur', '5000', datetime('now'));
INSERT OR IGNORE INTO agent_config VALUES ('active_mode_enabled', '1', datetime('now'));
INSERT OR IGNORE INTO agent_config VALUES ('min_reliability_for_active', '50', datetime('now'));
INSERT OR IGNORE INTO agent_config VALUES ('carrier_channel_id', '', datetime('now'));
INSERT OR IGNORE INTO agent_config VALUES ('nbu_rate_update_interval', 'daily', datetime('now'));
INSERT OR IGNORE INTO agent_config VALUES ('first_contact_approval', '1', datetime('now'));
