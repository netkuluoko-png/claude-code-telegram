"""Entry point: DI wiring, startup, graceful shutdown."""

from __future__ import annotations

import asyncio
import logging
import sys
from pathlib import Path

from src.config import AgentConfig, Settings, load_settings
from src.db.database import close_db, init_db


async def main() -> None:
    """Initialize all components and run the agent."""
    # 1. Load settings
    settings = load_settings()

    # 2. Setup logging
    _setup_logging(settings)
    logger = logging.getLogger(__name__)
    logger.info("Starting LogistAgent...")

    # 3. Initialize database
    db = await init_db(settings.db_path)

    # 4. Load agent config from DB
    agent_config = AgentConfig()
    await agent_config.load(db)

    # 5. Initialize repositories
    from src.db.repositories.cargo_repo import CargoRepository
    from src.db.repositories.contact_repo import ContactRepository
    from src.db.repositories.deal_repo import DealRepository
    from src.db.repositories.message_repo import MessageRepository

    contact_repo = ContactRepository(db)
    cargo_repo = CargoRepository(db)
    deal_repo = DealRepository(db)
    message_repo = MessageRepository(db)

    # 6. Initialize services
    from src.services.claude_client import ClaudeClient
    from src.services.nbu_rates import NBURatesService

    claude = ClaudeClient(settings.anthropic_api_key, settings.claude_model)
    nbu = NBURatesService(cargo_repo)

    # 7. Initialize AI components
    from src.agent.codex import PromptLoader
    from src.agent.context import ContextAssembler
    from src.agent.matcher import Matcher
    from src.agent.responder import Responder
    from src.agent.verification import VerificationAgent

    prompt_loader = PromptLoader()
    context_assembler = ContextAssembler(
        contact_repo,
        deal_repo,
        cargo_repo,
        message_repo,
    )
    responder = Responder(claude, prompt_loader)
    matcher = Matcher(claude, prompt_loader, context_assembler, agent_config)
    verification = VerificationAgent(
        claude,
        prompt_loader,
        context_assembler,
        deal_repo,
    )

    # 8. Initialize Notifier
    from src.notifications.notifier import Notifier

    notifier = Notifier(settings.admin_bot_token, settings.admin_tg_id)

    # 9. Initialize Deal Manager
    from telethon import TelegramClient

    userbot = TelegramClient(
        settings.tg_session_name,
        settings.tg_api_id,
        settings.tg_api_hash,
    )

    from src.deals.manager import DealManager

    deal_manager = DealManager(
        deal_repo,
        cargo_repo,
        contact_repo,
        message_repo,
        notifier,
        userbot,
        agent_config,
    )

    # 10. Initialize Profiler
    from src.profiler.profiler import Profiler

    profiler = Profiler(  # noqa: F841
        claude,
        prompt_loader,
        context_assembler,
        contact_repo,
        message_repo,
    )

    # 11. Initialize Parser (GroupMonitor)
    from src.parser.group_monitor import GroupMonitor
    from src.parser.message_analyzer import MessageAnalyzer

    analyzer = MessageAnalyzer(claude)

    async def on_new_cargo(offer: CargoOffer) -> None:  # noqa: F821
        """WF-2 trigger: evaluate new cargo via Matcher."""
        logger.info(
            "on_new_cargo triggered: offer_id=%s, type=%s, route=%s→%s",
            offer.id,
            offer.type,
            offer.direction_from,
            offer.direction_to,
        )
        if offer.type != "cargo":
            logger.info("on_new_cargo skipped: type=%s (not cargo)", offer.type)
            return
        try:
            result = await matcher.evaluate(offer)
            if result.action == "active":
                deal = await deal_manager.create_deal_from_match(offer)
                await deal_manager.initiate_carrier_search(
                    deal,
                    result.candidates,
                )
            elif result.action == "passive":
                customer_name = "Замовник"
                if offer.sender_contact_id:
                    c = await contact_repo.get_by_id(offer.sender_contact_id)
                    if c:
                        customer_name = c.first_name or "Замовник"
                await notifier.send(
                    f"📦 Новий вантаж (passive): "
                    f"{offer.direction_from}→{offer.direction_to}\n"
                    f"Замовник: {customer_name}\n"
                    f"Причина: {result.reason}",
                )
        except Exception:
            logger.exception("Matcher/DealManager failed for %s", offer.id)

    group_monitor = GroupMonitor(
        userbot,
        analyzer,
        contact_repo,
        cargo_repo,
        message_repo,
        settings,
        on_new_cargo,
    )

    # 12. Initialize Router
    from src.agent.router import Router

    router = Router(
        userbot,
        context_assembler,
        responder,
        analyzer,
        contact_repo,
        deal_repo,
        message_repo,
        cargo_repo,
        notifier,
        settings,
        agent_config,
        deal_manager,
        on_new_cargo,
        verification,
    )

    # 13. Initialize Admin Bot
    from src.bot.contact_briefing import ContactBriefingService
    from src.bot.telegram_bot import AdminBot

    briefing_service = ContactBriefingService(
        claude,
        prompt_loader,
        context_assembler,
    )
    admin_bot = AdminBot(
        settings.admin_bot_token,
        settings.admin_tg_id,
        contact_repo,
        deal_repo,
        message_repo,
        briefing_service,
    )

    # 14. Initialize Health Monitor
    from src.monitoring.health import HealthMonitor

    health = HealthMonitor(
        db,
        cargo_repo,
        contact_repo,
        deal_repo,
        message_repo,
        notifier,
        settings,
    )

    # 15. Fetch initial NBU rates
    try:
        await nbu.fetch_and_update()
    except Exception:
        logger.warning("Initial NBU rate fetch failed, will retry later")

    # 16. Start all components
    await userbot.start(phone=settings.tg_phone)
    logger.info("Userbot connected")

    await group_monitor.start()
    await router.start()
    await admin_bot.start()
    await health.start()

    logger.info("LogistAgent is running")

    # 17. Run until interrupted
    try:
        await userbot.run_until_disconnected()
    finally:
        logger.info("Shutting down...")
        await health.stop()
        await admin_bot.close()
        await notifier.close()
        await claude.close()
        await close_db(db)
        logger.info("LogistAgent stopped")


def _setup_logging(settings: Settings) -> None:
    """Configure logging with file rotation."""
    log_dir = Path(settings.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    from datetime import date

    log_file = log_dir / f"logist_{date.today().isoformat()}.log"

    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(str(log_file), encoding="utf-8"),
        ],
    )
    # Заглушити спам від httpx polling та telegram internals
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("telegram.ext").setLevel(logging.WARNING)


if __name__ == "__main__":
    asyncio.run(main())
