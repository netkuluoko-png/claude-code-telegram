"""Health monitoring and cron jobs (WF-8)."""

from __future__ import annotations

import asyncio
import logging
import shutil
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import aiosqlite

from src.config import Settings
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository
from src.notifications.notifier import Notifier

logger = logging.getLogger(__name__)


class HealthMonitor:
    """Health checks and periodic cron jobs."""

    def __init__(
        self,
        db_connection: aiosqlite.Connection,
        cargo_repo: CargoRepository,
        contact_repo: ContactRepository,
        deal_repo: DealRepository,
        message_repo: MessageRepository,
        notifier: Notifier,
        config: Settings,
    ) -> None:
        self._db = db_connection
        self._cargo = cargo_repo
        self._contacts = contact_repo
        self._deals = deal_repo
        self._messages = message_repo
        self._notifier = notifier
        self._config = config
        self._tasks: list[asyncio.Task[None]] = []

    async def start(self) -> None:
        """Start periodic health check and cron tasks."""
        self._tasks.append(asyncio.create_task(self._health_loop()))
        self._tasks.append(asyncio.create_task(self._hourly_loop()))
        self._tasks.append(asyncio.create_task(self._daily_loop()))
        logger.info("Health monitor started")

    async def stop(self) -> None:
        """Cancel all periodic tasks."""
        for task in self._tasks:
            task.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()

    async def check_all(self) -> dict[str, dict[str, Any]]:
        """Check health of all modules. Returns status dict for /health."""
        results: dict[str, dict[str, Any]] = {}

        results["database"] = await self._check_database()
        results["unprocessed_queue"] = await self._check_unprocessed()

        return results

    async def _check_database(self) -> dict[str, Any]:
        """Test database read/write."""
        try:
            async with self._db.execute("SELECT 1") as cursor:
                await cursor.fetchone()
            return {"status": "ok"}
        except Exception as e:
            return {"status": "error", "detail": str(e)[:100]}

    async def _check_unprocessed(self) -> dict[str, Any]:
        """Check unprocessed message queue size."""
        count = await self._messages.get_unprocessed_count()
        status = "ok" if count == 0 else "warning"
        return {"status": status, "count": count}

    # --- Cron jobs ---

    async def _health_loop(self) -> None:
        """Periodic health check every 5 minutes."""
        while True:
            await asyncio.sleep(300)
            try:
                results = await self.check_all()
                errors = [k for k, v in results.items() if v.get("status") == "error"]
                if errors:
                    text = "❌ Health check failed:\n" + "\n".join(
                        f"- {k}: {results[k].get('detail', 'unknown')}"
                        for k in errors
                    )
                    await self._notifier.send(text, priority="critical")
            except Exception:
                logger.exception("Health check failed")

    async def _hourly_loop(self) -> None:
        """Hourly cleanup: expire old cargo offers."""
        while True:
            await asyncio.sleep(3600)
            try:
                await self._hourly_cleanup()
            except Exception:
                logger.exception("Hourly cleanup failed")

    async def _daily_loop(self) -> None:
        """Daily tasks: market prices, NBU rates, backup, digest, archive."""
        while True:
            await asyncio.sleep(86400)
            try:
                await self._daily_tasks()
            except Exception:
                logger.exception("Daily tasks failed")

    async def _hourly_cleanup(self) -> None:
        """WF-8: expire old cargo_offers."""
        expired_ttl = await self._cargo.expire_old_offers(ttl_hours=72)
        expired_date = await self._cargo.expire_past_departure()
        total = expired_ttl + expired_date
        if total > 0:
            logger.info("Expired %d cargo offers", total)

    async def _daily_tasks(self) -> None:
        """WF-8: daily recalculations, backup, digest."""
        # Перерахунок market_prices
        count = await self._cargo.recalculate_market_prices()
        logger.info("Recalculated %d market prices", count)

        # Архівування старих угод (>90 днів)
        archived_deals = await self._deals.archive_old_deals(90)
        archived_msgs = await self._messages.archive_old_messages(90)
        if archived_deals or archived_msgs:
            logger.info(
                "Archived %d deals, %d messages",
                archived_deals, archived_msgs,
            )

        # Видалення expired cargo > 30 днів
        deleted = await self._cargo.delete_expired_older_than(30)
        if deleted:
            logger.info("Deleted %d old expired cargo offers", deleted)

        # Бекап
        await self._backup_database()

        # Дайджест
        await self._send_daily_digest()

    async def _backup_database(self) -> None:
        """Backup SQLite database file."""
        db_path = Path(self._config.db_path)
        if not db_path.exists():
            return

        backup_dir = Path(self._config.backup_dir)
        backup_dir.mkdir(parents=True, exist_ok=True)

        ts = datetime.now(tz=UTC).strftime("%Y%m%d_%H%M")
        backup_path = backup_dir / f"logist_backup_{ts}.db"

        try:
            shutil.copy2(str(db_path), str(backup_path))
            logger.info("Database backed up to %s", backup_path)

            # Очистити старі бекапи
            backups = sorted(backup_dir.glob("logist_backup_*.db"))
            retain = self._config.backup_retain_count
            for old in backups[:-retain]:
                old.unlink()
                logger.info("Removed old backup: %s", old.name)
        except Exception:
            logger.exception("Database backup failed")

    async def _send_daily_digest(self) -> None:
        """WF-5: send daily digest to operator."""
        try:
            # Підрахунок за сьогодні (спрощений)
            queue_count = await self._messages.get_unprocessed_count()
            text = (
                "📊 *ЩОДЕННИЙ ДАЙДЖЕСТ*\n\n"
                f"Необроблених повідомлень: {queue_count}\n"
            )
            await self._notifier.send(text)
        except Exception:
            logger.exception("Daily digest failed")
