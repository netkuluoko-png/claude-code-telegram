"""Configuration: .env settings, agent_config cache, city normalization."""

from __future__ import annotations

import logging
from pathlib import Path

import aiosqlite
from dotenv import load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings

logger = logging.getLogger(__name__)


class Settings(BaseSettings):
    """Application settings loaded from .env file."""

    # Telegram Userbot (Telethon)
    tg_api_id: int = 0
    tg_api_hash: str = ""
    tg_session_name: str = "logist_agent"
    tg_phone: str = ""

    # Telegram Admin Bot
    admin_bot_token: str = ""
    admin_tg_id: int = 0

    # Claude API
    anthropic_api_key: str = ""
    claude_model: str = "claude-sonnet-4-6"

    # Database
    db_path: Path = Path("data/logist.db")
    db_test_path: Path = Path("data/logist_test.db")

    # Telegram entities
    monitored_group_ids: list[int] = Field(
        default_factory=lambda: [3560542856]
    )
    carrier_channel_id: int | None = None

    # Test whitelist — обробляти повідомлення ТІЛЬКИ від цих tg_id (пусто = всі)
    test_whitelist_tg_ids: list[int] = Field(
        default_factory=lambda: [8085511361, 7351418211]
    )

    # Logging
    log_level: str = "INFO"
    log_dir: Path = Path("logs")

    # Backup
    backup_dir: Path = Path("backups")
    backup_interval_hours: int = 6
    backup_retain_count: int = 14

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8", "extra": "ignore"}


def load_settings() -> Settings:
    """Load settings from .env file."""
    load_dotenv()
    return Settings()


class AgentConfig:
    """Runtime config cache from agent_config DB table.

    Loaded once at startup, refreshed on demand.
    """

    def __init__(self) -> None:
        self._data: dict[str, str] = {}

    async def load(self, db: aiosqlite.Connection) -> None:
        """Load all config values from DB."""
        async with db.execute("SELECT key, value FROM agent_config") as cursor:
            rows = await cursor.fetchall()
            self._data = {row[0]: row[1] for row in rows}
        logger.info("AgentConfig loaded: %d keys", len(self._data))

    def get(self, key: str, default: str = "") -> str:
        """Get config value by key."""
        return self._data.get(key, default)

    def get_int(self, key: str, default: int = 0) -> int:
        """Get config value as int."""
        val = self._data.get(key)
        if val is None:
            return default
        return int(val)

    def get_bool(self, key: str, default: bool = False) -> bool:
        """Get config value as bool."""
        val = self._data.get(key)
        if val is None:
            return default
        return val in ("1", "true", "True", "yes")

    @property
    def margin_threshold_usd(self) -> int:
        return self.get_int("margin_threshold_usd", 100)

    @property
    def max_carriers_to_contact(self) -> int:
        return self.get_int("max_carriers_to_contact", 3)

    @property
    def response_wait_hours(self) -> int:
        return self.get_int("response_wait_hours", 2)

    @property
    def cargo_ttl_hours(self) -> int:
        return self.get_int("cargo_ttl_hours", 72)

    @property
    def escalation_amount_eur(self) -> int:
        return self.get_int("escalation_amount_eur", 5000)

    @property
    def active_mode_enabled(self) -> bool:
        return self.get_bool("active_mode_enabled", True)

    @property
    def min_reliability_for_active(self) -> int:
        return self.get_int("min_reliability_for_active", 50)

    @property
    def first_contact_approval(self) -> bool:
        return self.get_bool("first_contact_approval", True)


# --- City normalization ---

CITY_NORMALIZATION: dict[str, str] = {
    # Гданськ
    "гданск": "Гданськ",
    "gdansk": "Гданськ",
    "гданьск": "Гданськ",
    "гданськ": "Гданськ",
    # Гдиня
    "гдыня": "Гдиня",
    "gdynia": "Гдиня",
    "гдиня": "Гдиня",
    # Київ
    "киев": "Київ",
    "київ": "Київ",
    "kiev": "Київ",
    "kyiv": "Київ",
    # Одеса
    "одесса": "Одеса",
    "одеса": "Одеса",
    "odessa": "Одеса",
    "odesa": "Одеса",
    # Львів
    "львов": "Львів",
    "львів": "Львів",
    "lviv": "Львів",
    "lvov": "Львів",
    # Дніпро
    "днепр": "Дніпро",
    "дніпро": "Дніпро",
    "dnipro": "Дніпро",
    # Харків
    "харьков": "Харків",
    "харків": "Харків",
    "kharkiv": "Харків",
    # Варшава
    "варшава": "Варшава",
    "warszawa": "Варшава",
    "warsaw": "Варшава",
    # Вроцлав
    "вроцлав": "Вроцлав",
    "wroclaw": "Вроцлав",
}


POLISH_CITIES: frozenset[str] = frozenset({
    "Гданськ", "Гдиня", "Варшава", "Вроцлав",
})


def is_polish_city(city: str) -> bool:
    """Check if city is a Polish city (normalized)."""
    return normalize_city(city) in POLISH_CITIES


def normalize_city(city: str) -> str:
    """Normalize city name using the dictionary."""
    return CITY_NORMALIZATION.get(city.lower().strip(), city.strip())
