"""Deal lifecycle models (Zone 2 + Zone 4)."""

from __future__ import annotations

from datetime import UTC, date, datetime

from pydantic import BaseModel, Field

from src.models.common import (
    ContainerType,
    DealEventType,
    DealStatus,
    DocType,
)


class Deal(BaseModel):
    """Zone 2: matched cargo-carrier pair."""

    id: str
    cargo_offer_id: str | None = None
    customer_contact_id: str | None = None
    carrier_contact_id: str | None = None
    route_from: str
    route_to: str
    container_type: ContainerType | None = None
    departure_date: date | None = None
    customer_price: float | None = None
    customer_currency: str = "EUR"
    carrier_price: float | None = None
    carrier_currency: str = "EUR"
    margin: float | None = None
    status: DealStatus = "prospecting"
    escalated: bool = False
    escalation_reason: str | None = None
    notes: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))


class DealEvent(BaseModel):
    """Audit log entry for a deal."""

    id: str
    deal_id: str
    event_type: DealEventType
    old_value: str | None = None
    new_value: str | None = None
    note: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))


class DealSummary(BaseModel):
    """Lightweight deal projection for AI context."""

    deal_id: str
    route: str
    status: DealStatus
    departure_date: date | None = None
    my_price: float | None = None
    customer_price: float | None = None
    carrier_price: float | None = None
    margin: float | None = None
    container_type: ContainerType | None = None


class DealDocument(BaseModel):
    """Zone 4: document attached to a deal."""

    id: str
    deal_id: str
    doc_type: DocType | None = None
    file_path: str | None = None
    file_name: str | None = None
    uploaded_by: str | None = None
    forwarded_to: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))


class DriverContact(BaseModel):
    """Verified driver linked to a deal."""

    id: str
    deal_id: str | None = None
    carrier_contact_id: str | None = None
    driver_name: str
    driver_phone: str | None = None
    driver_tg_id: int | None = None
    driver_tg_username: str | None = None
    verified: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
