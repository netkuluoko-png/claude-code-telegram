"""Shared types, enums, and literals used across all models."""

from typing import Literal

# --- Contact ---
ContactType = Literal["customer", "carrier", "both", "unknown"]
TrustLevel = Literal["new", "developing", "established", "trusted"]
CommunicationStyle = Literal["formal", "informal", "blunt", "mixed"]
Language = Literal["uk", "ru", "mixed"]
ResponseSpeed = Literal["fast", "normal", "slow"]
BargainingBehavior = Literal["flexible", "firm", "aggressive"]
PriceTendency = Literal["below_market", "at_market", "above_market"]
PaymentPunctuality = Literal["on_time", "slight_delay", "problematic", "unknown"]
MessageLength = Literal["short", "medium", "long"]
EmojiUsage = Literal["none", "rare", "frequent"]

# --- Cargo ---
CargoType = Literal["cargo", "transport"]
CargoOfferStatus = Literal["open", "matched", "expired", "archived"]
ContainerType = Literal["20", "40", "40HC", "45", "reefer"]
PaymentType = Literal["cash", "bank"]

# --- Deal ---
DealStatus = Literal[
    "prospecting",
    "negotiating",
    "agreed",
    "in_transit",
    "completed",
    "cancelled",
    "disputed",
]
DealEventType = Literal["status_change", "note", "escalation", "document", "verification"]
DocType = Literal["application", "cmr", "ttn", "invoice", "other"]

# --- Message ---
MessageDirection = Literal["in", "out"]

# --- Verification ---
VerificationVerdict = Literal["verified_driver", "suspicious", "unverified"]
VerificationAction = Literal[
    "grant_limited_access",
    "escalate_to_operator",
    "deny_and_suggest_main_account",
]

# --- Responder context types ---
ContextType = Literal[
    "deal_response",
    "new_offer",
    "price_inquiry",
    "availability_check",
    "document",
    "complaint",
    "greeting",
    "unknown",
]

# --- Urgency ---
Urgency = Literal["low", "medium", "high"]
