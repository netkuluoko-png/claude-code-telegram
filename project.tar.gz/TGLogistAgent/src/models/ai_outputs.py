"""Output models for all 6 AI prompts."""

from __future__ import annotations

from pydantic import BaseModel, Field

from src.models.common import (
    BargainingBehavior,
    CargoType,
    CommunicationStyle,
    ContactType,
    ContainerType,
    ContextType,
    DealStatus,
    Language,
    PaymentPunctuality,
    ResponseSpeed,
    TrustLevel,
    Urgency,
    VerificationAction,
    VerificationVerdict,
)

# ---------------------------------------------------------------------------
# Responder (main prompt) — WF-4
# ---------------------------------------------------------------------------


class ResponderAction(BaseModel):
    """Single action from Responder output."""

    type: str
    # Параметри залежать від type — зберігаємо як опціональні поля
    role: ContactType | None = None  # create_contact
    cargo_offer_id: str | None = None  # create_deal
    contact_role: str | None = None  # create_deal
    deal_id: str | None = None  # update_deal_status, escalate, forward
    new_status: DealStatus | None = None  # update_deal_status
    contact_id: str | None = None  # update_price
    price: float | None = None  # update_price
    currency: str | None = None  # update_price
    route: str | None = None  # update_price
    reason: str | None = None  # escalate
    text: str | None = None  # notify_operator
    message: str | None = None  # forward_to_other_party
    message_draft: str | None = None  # send_to_carrier_channel
    driver_name: str | None = None  # save_driver
    driver_phone: str | None = None  # save_driver
    driver_tg_id: int | None = None  # save_driver
    driver_tg_username: str | None = None  # save_driver


class ResponderOutput(BaseModel):
    """Structured output from Responder prompt."""

    context_type: ContextType
    deal_id: str | None = None
    response_text: str
    actions: list[ResponderAction] = Field(default_factory=list)
    confidence: float
    internal_note: str = ""


# ---------------------------------------------------------------------------
# Parser — WF-1
# ---------------------------------------------------------------------------


class ParserDetails(BaseModel):
    """Structured details extracted by Parser."""

    route_from: str | None = None
    route_to: str | None = None
    container_type: ContainerType | None = None
    shipping_line: str | None = None
    weight_tons: float | None = None
    cargo_description: str | None = None
    departure_date: str | None = None
    price: float | None = None
    price_currency: str | None = None
    payment_type: str | None = None
    contact_name: str | None = None
    contact_phone: str | None = None


class ParserOutput(BaseModel):
    """Output from Parser prompt."""

    match: bool
    type: CargoType | None = None
    reason: str
    details: ParserDetails | None = None


# ---------------------------------------------------------------------------
# Matcher — WF-2
# ---------------------------------------------------------------------------


class MatcherCandidate(BaseModel):
    """Carrier candidate selected by Matcher."""

    contact_id: str
    name: str
    reliability: int
    priority: int
    message_draft: str


class MatcherOutput(BaseModel):
    """Output from Matcher prompt."""

    action: str  # "active" | "passive" | "skip"
    reason: str
    estimated_margin: float | None = None
    candidates: list[MatcherCandidate] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Profiler — WF-4.9
# ---------------------------------------------------------------------------


class PsychologyUpdates(BaseModel):
    """Psychology fields to update."""

    communication_style: CommunicationStyle | None = None
    language: Language | None = None
    response_speed: ResponseSpeed | None = None
    bargaining_behavior: BargainingBehavior | None = None
    best_response_pattern: str | None = None
    trust_level: TrustLevel | None = None


class PriceUpdate(BaseModel):
    """Single price observation from Profiler."""

    route: str
    price: float
    currency: str
    container_type: ContainerType | None = None


class ReliabilityUpdates(BaseModel):
    """Reliability fields to update."""

    payment_punctuality: PaymentPunctuality | None = None
    communication_culture: int | None = None
    dispute_description: str | None = None


class ProfilerOutput(BaseModel):
    """Output from Profiler prompt."""

    psychology_updates: PsychologyUpdates = Field(default_factory=PsychologyUpdates)
    price_updates: list[PriceUpdate] = Field(default_factory=list)
    reliability_updates: ReliabilityUpdates = Field(default_factory=ReliabilityUpdates)
    notes: str = ""


# ---------------------------------------------------------------------------
# Verification Agent — WF-11
# ---------------------------------------------------------------------------


class VerificationEvidence(BaseModel):
    """Evidence collected during verification."""

    phone_match: bool = False
    name_match: bool = False
    shared_groups_count: int = 0
    has_active_deals: bool = False


class VerificationOutput(BaseModel):
    """Output from Verification Agent prompt."""

    verdict: VerificationVerdict
    confidence: float
    reason: str
    evidence: VerificationEvidence = Field(default_factory=VerificationEvidence)
    recommended_action: VerificationAction


# ---------------------------------------------------------------------------
# Contact Briefing — WF-12
# ---------------------------------------------------------------------------


class ContactBriefingOutput(BaseModel):
    """Output from Contact Briefing prompt."""

    briefing_text: str
    likely_intent: str
    urgency: Urgency
    suggested_talking_points: list[str] = Field(default_factory=list)
