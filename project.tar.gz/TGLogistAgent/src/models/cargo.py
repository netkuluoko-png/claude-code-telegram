"""Cargo offer and parser models."""

from __future__ import annotations

from datetime import UTC, date, datetime

from pydantic import BaseModel, Field

from src.models.common import CargoOfferStatus, CargoType, ContainerType, PaymentType


class CargoDetails(BaseModel):
    """Structured cargo/transport details extracted by Parser."""

    route_from: str
    route_to: str | None = None
    container_type: ContainerType | None = None
    shipping_line: str | None = None
    weight_tons: float | None = None
    cargo_description: str | None = None
    departure_date: date | None = None
    price: float | None = None
    price_currency: str | None = None
    payment_type: PaymentType | None = None
    contact_name: str | None = None
    contact_phone: str | None = None


class CargoOffer(BaseModel):
    """Zone 1: cargo or transport offer from a Telegram group."""

    id: str
    source_msg_id: int | None = None
    source_group: str | None = None
    sender_contact_id: str | None = None
    type: CargoType
    direction_from: str
    direction_to: str | None = None
    container_type: ContainerType | None = None
    weight_tons: float | None = None
    cargo_description: str | None = None
    departure_date: date | None = None
    price: float | None = None
    price_currency: str | None = None
    payment_type: PaymentType | None = None
    contact_name_raw: str | None = None
    contact_phone_raw: str | None = None
    raw_text: str
    ai_analysis: str | None = None
    status: CargoOfferStatus = "open"
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    expires_at: datetime | None = None
