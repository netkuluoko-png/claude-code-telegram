"""Contact profile models (Zone 3)."""

from __future__ import annotations

from datetime import UTC, datetime

from pydantic import BaseModel, Field

from src.models.common import (
    BargainingBehavior,
    CommunicationStyle,
    ContactType,
    ContainerType,
    EmojiUsage,
    Language,
    MessageLength,
    PaymentPunctuality,
    PriceTendency,
    ResponseSpeed,
    TrustLevel,
)


class Contact(BaseModel):
    """Base contact record."""

    id: str
    tg_id: int
    tg_username: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    type: ContactType = "unknown"
    poland_related: bool = False
    first_seen: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    last_seen: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    total_messages: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))


class ContactPhone(BaseModel):
    """Phone number linked to a contact."""

    id: str
    contact_id: str
    phone: str
    source: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))


class ContactRoute(BaseModel):
    """Known route for a contact."""

    id: str
    contact_id: str
    from_city: str
    to_city: str
    direction: str | None = None
    frequency: int = 1
    last_seen: datetime | None = None


class ContactSourceGroup(BaseModel):
    """Telegram group where contact was seen."""

    id: str
    contact_id: str
    group_name: str
    group_tg_id: int | None = None
    first_seen: datetime | None = None
    last_seen: datetime | None = None


class ContactPsychology(BaseModel):
    """Psychological profile updated by Profiler."""

    contact_id: str
    communication_style: CommunicationStyle | None = None
    language: Language | None = None
    response_speed: ResponseSpeed | None = None
    bargaining_behavior: BargainingBehavior | None = None
    preferred_contact_time: str | None = None
    typical_message_length: MessageLength | None = None
    emoji_usage: EmojiUsage | None = None
    best_response_pattern: str | None = None
    trust_level: TrustLevel = "new"
    updated_at: datetime | None = None


class ContactReliability(BaseModel):
    """Reliability metrics updated by Deal Manager."""

    contact_id: str
    deals_total: int = 0
    deals_completed: int = 0
    deals_cancelled: int = 0
    cancellation_rate: float = 0.0
    payment_punctuality: PaymentPunctuality = "unknown"
    avg_payment_delay_days: float = 0.0
    communication_culture: int = 3
    disputes_count: int = 0
    who_cancelled: str | None = None  # JSON array
    last_dispute_date: str | None = None
    dispute_descriptions: str | None = None  # JSON array
    overall_reliability: int = 50
    manual_notes: str | None = None
    updated_at: datetime | None = None


class ContactSlice(BaseModel):
    """Minimal context slice for AI prompts (Zone 3 projection)."""

    id: str
    name: str
    type: ContactType
    reliability: int
    style: CommunicationStyle | None = None
    language: Language | None = None
    best_pattern: str | None = None
    price_tendency: PriceTendency | None = None
    active_routes: list[str]
    trust_level: TrustLevel = "new"
    bargaining: BargainingBehavior | None = None


class ContactProfile(BaseModel):
    """Full contact profile (all sub-tables combined)."""

    contact: Contact
    psychology: ContactPsychology | None = None
    reliability: ContactReliability | None = None
    phones: list[str] = Field(default_factory=list)
    routes: list[tuple[str, str]] = Field(default_factory=list)
    source_groups: list[str] = Field(default_factory=list)


class PriceRecord(BaseModel):
    """Historical price observation for a contact."""

    id: str
    contact_id: str
    route_from: str
    route_to: str
    container_type: ContainerType | None = None
    price: float
    currency: str = "EUR"
    date: str
    source: str = "message"
    source_msg_id: int | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
