"""Custom exceptions for LogistAgent."""


class LogistAgentError(Exception):
    """Base exception for all LogistAgent errors."""


class DatabaseError(LogistAgentError):
    """Database operation failed."""


class ClaudeAPIError(LogistAgentError):
    """Claude API call failed."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class TelegramError(LogistAgentError):
    """Telegram operation failed."""


class EscalationRequiredError(LogistAgentError):
    """Situation requires operator escalation."""

    def __init__(self, reason: str, deal_id: str | None = None) -> None:
        super().__init__(reason)
        self.reason = reason
        self.deal_id = deal_id


class LowConfidenceError(LogistAgentError):
    """AI confidence below threshold (0.7)."""

    def __init__(self, confidence: float, context: str) -> None:
        super().__init__(f"Low confidence {confidence}: {context}")
        self.confidence = confidence
        self.context = context


class ContactNotFoundError(LogistAgentError):
    """Contact not found in database."""

    def __init__(self, identifier: str) -> None:
        super().__init__(f"Contact not found: {identifier}")
        self.identifier = identifier


class DealNotFoundError(LogistAgentError):
    """Deal not found in database."""

    def __init__(self, deal_id: str) -> None:
        super().__init__(f"Deal not found: {deal_id}")
        self.deal_id = deal_id


class InvalidDealTransitionError(LogistAgentError):
    """Invalid deal status transition."""

    def __init__(self, deal_id: str, current: str, target: str) -> None:
        super().__init__(f"Deal {deal_id}: cannot transition {current} → {target}")
        self.deal_id = deal_id
        self.current_status = current
        self.target_status = target
