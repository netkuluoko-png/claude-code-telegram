"""Deal lifecycle manager (WF-2→WF-3, WF-3.5, WF-6)."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from telethon import TelegramClient

from src.config import AgentConfig
from src.db.repositories.base import new_id
from src.db.repositories.cargo_repo import CargoRepository
from src.db.repositories.contact_repo import ContactRepository
from src.db.repositories.deal_repo import DealRepository
from src.db.repositories.message_repo import MessageRepository
from src.exceptions import DealNotFoundError, InvalidDealTransitionError
from src.models.ai_outputs import MatcherCandidate
from src.models.cargo import CargoOffer
from src.models.deal import Deal, DealEvent

if TYPE_CHECKING:
    from src.notifications.notifier import Notifier

logger = logging.getLogger(__name__)

VALID_TRANSITIONS: dict[str, list[str]] = {
    "prospecting": ["negotiating", "cancelled"],
    "negotiating": ["agreed", "cancelled", "disputed"],
    "agreed": ["in_transit", "cancelled", "disputed"],
    "in_transit": ["completed", "cancelled", "disputed"],
    "completed": [],
    "cancelled": [],
    "disputed": ["negotiating", "cancelled"],
}


class DealManager:
    """Manage deal lifecycle from prospecting to completion."""

    def __init__(
        self,
        deal_repo: DealRepository,
        cargo_repo: CargoRepository,
        contact_repo: ContactRepository,
        message_repo: MessageRepository,
        notifier: Notifier,
        client: TelegramClient,
        agent_config: AgentConfig,
    ) -> None:
        self._deals = deal_repo
        self._cargo = cargo_repo
        self._contacts = contact_repo
        self._messages = message_repo
        self._notifier = notifier
        self._client = client
        self._config = agent_config

    async def create_deal_from_match(
        self,
        cargo_offer: CargoOffer,
        carrier_contact_id: str | None = None,
    ) -> Deal:
        """Create a deal from a matched cargo offer (status=prospecting).

        Args:
            cargo_offer: The cargo offer that triggered the match.
            carrier_contact_id: Optional carrier (set later if searching).

        Returns:
            Created Deal.
        """
        deal = Deal(
            id=new_id(),
            cargo_offer_id=cargo_offer.id,
            customer_contact_id=cargo_offer.sender_contact_id,
            carrier_contact_id=carrier_contact_id,
            route_from=cargo_offer.direction_from,
            route_to=cargo_offer.direction_to or "",
            container_type=cargo_offer.container_type,
            departure_date=cargo_offer.departure_date,
            customer_price=cargo_offer.price,
            customer_currency=cargo_offer.price_currency or "EUR",
            status="prospecting",
        )
        await self._deals.create(deal)
        await self._deals.add_event(DealEvent(
            id=new_id(), deal_id=deal.id,
            event_type="status_change", new_value="prospecting",
            note="Deal created from matcher",
        ))

        logger.info("Deal created: %s (%s→%s)", deal.id, deal.route_from, deal.route_to)
        return deal

    async def transition_status(
        self,
        deal_id: str,
        new_status: str,
        note: str | None = None,
    ) -> None:
        """Transition deal status with validation.

        Raises:
            DealNotFoundError: If deal not found.
            InvalidDealTransitionError: If transition is invalid.
        """
        deal = await self._deals.get_by_id(deal_id)
        if deal is None:
            raise DealNotFoundError(deal_id)

        valid = VALID_TRANSITIONS.get(deal.status, [])
        if new_status not in valid:
            raise InvalidDealTransitionError(deal_id, deal.status, new_status)

        await self._deals.update_status(deal_id, new_status, note)
        logger.info("Deal %s: %s → %s", deal_id, deal.status, new_status)

    async def initiate_carrier_search(
        self,
        deal: Deal,
        candidates: list[MatcherCandidate],
    ) -> int:
        """WF-3: Send proposals to carrier candidates.

        Args:
            deal: The deal to find carriers for.
            candidates: Sorted carrier candidates from Matcher.

        Returns:
            Number of messages sent.
        """
        max_carriers = self._config.max_carriers_to_contact
        sent = 0

        for candidate in candidates[:max_carriers]:
            # Перевірити чи немає активної угоди з цим перевізником
            has_active = await self._deals.has_active_deal_with_carrier(
                candidate.contact_id,
            )
            if has_active:
                logger.info(
                    "Skipping carrier %s (active deal exists)",
                    candidate.name,
                )
                continue

            # Отримати tg_id перевізника
            contact = await self._contacts.get_by_id(candidate.contact_id)
            if contact is None:
                continue

            # Відправити повідомлення
            try:
                await self._client.send_message(
                    contact.tg_id, candidate.message_draft,
                )
                await self._messages.save_message(
                    contact_id=candidate.contact_id,
                    source="dm", direction="out",
                    text=candidate.message_draft,
                    deal_id=deal.id,
                )
                sent += 1
                logger.info(
                    "Sent proposal to %s: %s",
                    candidate.name, candidate.message_draft,
                )
            except Exception:
                logger.exception(
                    "Failed to send proposal to %s", candidate.name,
                )

        if sent > 0:
            await self.transition_status(
                deal.id, "negotiating",
                f"Sent proposals to {sent} carriers",
            )

        return sent

    async def handle_carrier_response(
        self,
        deal_id: str,
        carrier_contact_id: str,
        accepted: bool,
    ) -> None:
        """Handle carrier's response to a proposal.

        If accepted: fix carrier, notify others "вже не актуально".
        If rejected: wait for other candidates.
        """
        deal = await self._deals.get_by_id(deal_id)
        if deal is None:
            return

        if accepted:
            await self._deals.set_carrier(deal_id, carrier_contact_id)
            await self._deals.add_event(DealEvent(
                id=new_id(), deal_id=deal_id,
                event_type="status_change",
                note=f"Carrier {carrier_contact_id} accepted",
            ))
            carrier = await self._contacts.get_by_id(carrier_contact_id)
            carrier_name = carrier.first_name if carrier else "Перевізник"

            await self._notifier.send_new_match(
                route=f"{deal.route_from}→{deal.route_to}",
                customer_name="Замовник",
                estimated_margin=deal.margin or 0,
            )
            logger.info(
                "Carrier %s accepted deal %s", carrier_name, deal_id,
            )

    async def check_cargo_actuality(self, deal: Deal) -> None:
        """WF-3.5: Ask customer if cargo is still actual."""
        if not deal.customer_contact_id:
            return

        customer = await self._contacts.get_by_id(deal.customer_contact_id)
        if customer is None:
            return

        text = f"Маю авто на {deal.route_from}→{deal.route_to}"
        if deal.departure_date:
            text += f", {deal.departure_date}"
        text += ". Актуально?"

        try:
            await self._client.send_message(customer.tg_id, text)
            await self._messages.save_message(
                contact_id=customer.id, source="dm",
                direction="out", text=text, deal_id=deal.id,
            )
        except Exception:
            logger.exception("Failed to check actuality with customer")

    async def escalate(self, deal_id: str, reason: str) -> None:
        """WF-6: Escalate deal to operator."""
        deal = await self._deals.get_by_id(deal_id)
        if deal is None:
            raise DealNotFoundError(deal_id)

        await self._deals.set_escalated(deal_id, reason)

        customer_name = "Невідомий"
        if deal.customer_contact_id:
            customer = await self._contacts.get_by_id(
                deal.customer_contact_id,
            )
            if customer:
                customer_name = customer.first_name or "Невідомий"

        await self._notifier.send_escalation(
            contact_name=customer_name,
            deal_id=deal_id,
            reason=reason,
            context=f"Route: {deal.route_from}→{deal.route_to}",
        )

    async def resolve_escalation(
        self, deal_id: str, instruction: str
    ) -> None:
        """Handle /resolve from operator."""
        await self._deals.clear_escalation(deal_id)
        await self._deals.add_event(DealEvent(
            id=new_id(), deal_id=deal_id,
            event_type="note",
            note=f"Resolved by operator: {instruction}",
        ))

    async def cancel_deal(
        self, deal_id: str, reason: str, cancelled_by: str
    ) -> None:
        """Cancel a deal with reason."""
        await self.transition_status(
            deal_id, "cancelled",
            f"Cancelled by {cancelled_by}: {reason}",
        )

        # Архівувати cargo_offer якщо є
        deal = await self._deals.get_by_id(deal_id)
        if deal and deal.cargo_offer_id:
            await self._cargo.update_status(deal.cargo_offer_id, "archived")
