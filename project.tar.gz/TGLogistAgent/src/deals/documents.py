"""Document forwarding between deal parties (WF-7)."""

from __future__ import annotations

import logging

from telethon import TelegramClient

from src.db.repositories.base import new_id
from src.db.repositories.deal_repo import DealRepository
from src.models.deal import Deal, DealDocument

logger = logging.getLogger(__name__)


class DocumentForwarder:
    """Forward documents between deal parties via Telethon."""

    def __init__(
        self,
        client: TelegramClient,
        deal_repo: DealRepository,
    ) -> None:
        self._client = client
        self._deals = deal_repo

    async def handle_incoming_document(
        self,
        file_path: str | None,
        file_name: str | None,
        sender_contact_id: str,
        deal_id: str,
        recipient_tg_id: int | None = None,
    ) -> None:
        """WF-7: Save document record and forward to the other party.

        Args:
            file_path: Local path to saved file (or None).
            file_name: Original file name.
            sender_contact_id: UUID of the contact who sent it.
            deal_id: UUID of the deal.
            recipient_tg_id: Telegram ID of the recipient (if known).
        """
        deal = await self._deals.get_by_id(deal_id)
        if deal is None:
            logger.warning("Document for unknown deal: %s", deal_id)
            return

        # Зберегти документ
        doc = DealDocument(
            id=new_id(),
            deal_id=deal_id,
            file_path=file_path,
            file_name=file_name,
            uploaded_by=sender_contact_id,
        )
        await self._deals.add_document(doc)

        # Визначити одержувача
        if recipient_tg_id is None:
            recipient_id = self._determine_recipient(
                deal, sender_contact_id,
            )
            if recipient_id is None:
                logger.warning(
                    "Cannot determine recipient for doc in deal %s",
                    deal_id,
                )
                return
            # Тут потрібно отримати tg_id одержувача
            # Це буде зроблено через contact_repo в router
            return

        # Переслати документ
        try:
            if file_path:
                await self._client.send_file(recipient_tg_id, file_path)
            await self._deals.mark_forwarded(doc.id, sender_contact_id)
            logger.info(
                "Document forwarded: %s → tg_id=%d",
                file_name, recipient_tg_id,
            )
        except Exception:
            logger.exception("Failed to forward document")

    async def send_application(
        self,
        deal_id: str,
        text: str,
        recipient_tg_id: int,
    ) -> None:
        """Send generated application text to a contact."""
        try:
            await self._client.send_message(recipient_tg_id, text)
            logger.info(
                "Application sent for deal %s to tg_id=%d",
                deal_id, recipient_tg_id,
            )
        except Exception:
            logger.exception("Failed to send application")

    def _determine_recipient(
        self, deal: Deal, sender_contact_id: str  # noqa: F821
    ) -> str | None:
        """Determine the other party in a deal."""
        if sender_contact_id == deal.customer_contact_id:
            return deal.carrier_contact_id
        if sender_contact_id == deal.carrier_contact_id:
            return deal.customer_contact_id
        return None
