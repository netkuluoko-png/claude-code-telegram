"""Application templates for deals (WF-4, status=agreed)."""

from __future__ import annotations

from src.models.contact import Contact
from src.models.deal import Deal

_TEMPLATE = """ЗАЯВКА НА ПЕРЕВЕЗЕННЯ #{deal_id}

Дата: {date}
Маршрут: {route_from} → {route_to}
Контейнер: {container_type}
Вага: {weight}
Тип вантажу: {cargo_desc}
Оплата: {payment}

{party_section}

Ціна перевезення: {price} {currency}
"""


class ApplicationTemplate:
    """Generate deal applications with different prices for each party."""

    def generate_for_customer(
        self, deal: Deal, customer: Contact, carrier: Contact
    ) -> str:
        """Generate application for the customer (with customer price).

        Customer sees: their own price + carrier contact (after signing).
        """
        party = (
            f"Замовник: {_contact_line(customer)}\n"
            f"Перевізник: {_contact_line(carrier)}"
        )
        return self._render(deal, party, deal.customer_price, deal.customer_currency)

    def generate_for_carrier(
        self, deal: Deal, customer: Contact, carrier: Contact
    ) -> str:
        """Generate application for the carrier (with carrier price).

        Carrier sees: their own price + customer contact (after signing).
        """
        party = (
            f"Замовник: {_contact_line(customer)}\n"
            f"Перевізник: {_contact_line(carrier)}"
        )
        return self._render(deal, party, deal.carrier_price, deal.carrier_currency)

    def _render(
        self,
        deal: Deal,
        party_section: str,
        price: float | None,
        currency: str,
    ) -> str:
        """Render the template with given values."""
        return _TEMPLATE.format(
            deal_id=deal.id[:12],
            date=str(deal.departure_date) if deal.departure_date else "—",
            route_from=deal.route_from,
            route_to=deal.route_to,
            container_type=deal.container_type or "—",
            weight="—",
            cargo_desc="—",
            payment="—",
            party_section=party_section,
            price=f"{price:.0f}" if price else "—",
            currency=currency,
        )


def _contact_line(contact: Contact) -> str:
    """Format contact as a single line for the application."""
    parts = []
    if contact.first_name:
        parts.append(contact.first_name)
    if contact.last_name:
        parts.append(contact.last_name)
    name = " ".join(parts) if parts else "—"

    if contact.tg_username:
        return f"{name} (@{contact.tg_username})"
    return name
