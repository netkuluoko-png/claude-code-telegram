"""Operator notifications via Telegram admin bot (WF-5)."""

from __future__ import annotations

import logging
from typing import Literal

from telegram import Bot

logger = logging.getLogger(__name__)


class Notifier:
    """Send notifications to operator via private Telegram bot."""

    def __init__(self, bot_token: str, admin_tg_id: int) -> None:
        self._bot = Bot(token=bot_token) if bot_token else None
        self._admin_id = admin_tg_id

    async def send(
        self,
        text: str,
        priority: Literal["low", "medium", "high", "critical"] = "medium",
    ) -> None:
        """Send a message to the operator."""
        if not self._bot or not self._admin_id:
            logger.error(
                "Notifier not configured (bot=%s, admin=%s), cannot send: %s",
                bool(self._bot),
                bool(self._admin_id),
                text[:200],
            )
            return

        try:
            await self._bot.send_message(
                chat_id=self._admin_id,
                text=text,
                parse_mode="Markdown",
            )
        except Exception:
            logger.exception("Failed to send notification")

    async def send_escalation(
        self,
        contact_name: str,
        deal_id: str | None,
        reason: str,
        context: str,
        recommendation: str | None = None,
    ) -> None:
        """Send formatted escalation message (WF-6)."""
        logger.info(
            "Sending escalation for contact=%s, deal=%s, reason=%s",
            contact_name,
            deal_id,
            reason,
        )
        parts = [
            "⚠️ *ЕСКАЛАЦІЯ*",
            "",
            f"Контакт: {contact_name}",
        ]
        if deal_id:
            parts.append(f"Угода: #{deal_id[:12]}")
        parts.append(f"Причина: {reason}")
        if context:
            parts.append(f"\nКонтекст: {context}")
        if recommendation:
            parts.append(f"\nРекомендація: {recommendation}")

        await self.send("\n".join(parts), priority="critical")
        logger.info("Escalation sent successfully to admin")

    async def send_new_match(
        self,
        route: str,
        customer_name: str,
        estimated_margin: float,
    ) -> None:
        """Notify about a new cargo match."""
        logger.info(
            "Sending new match notification: route=%s, customer=%s",
            route,
            customer_name,
        )
        text = (
            f"📦 *НОВИЙ МАТЧ*\n\n"
            f"Маршрут: {route}\n"
            f"Замовник: {customer_name}\n"
            f"Очікувана маржа: ~{estimated_margin:.0f}€\n"
            f"Агент шукає перевізника."
        )
        await self.send(text, priority="high")
        logger.info("New match notification sent for route=%s", route)

    async def send_deal_confirmed(
        self,
        deal_id: str,
        route: str,
        customer_price: float,
        carrier_price: float,
        margin: float,
    ) -> None:
        """Notify about a confirmed deal."""
        logger.info(
            "Sending deal confirmed notification: deal=%s, route=%s",
            deal_id[:12],
            route,
        )
        text = (
            f"✅ *УГОДА ПІДТВЕРДЖЕНА*\n\n"
            f"#{deal_id[:12]}: {route}\n"
            f"Ціна замовника: {customer_price:.0f}€\n"
            f"Ціна перевізника: {carrier_price:.0f}€\n"
            f"Маржа: {margin:.0f}€"
        )
        await self.send(text, priority="medium")
        logger.info("Deal confirmed notification sent for deal=%s", deal_id[:12])

    async def close(self) -> None:
        """Shutdown the bot."""
        if self._bot:
            await self._bot.shutdown()
