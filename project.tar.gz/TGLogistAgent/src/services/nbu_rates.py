"""NBU exchange rates service (api.bank.gov.ua)."""

from __future__ import annotations

import logging
from datetime import date

import httpx

from src.db.repositories.cargo_repo import CargoRepository

logger = logging.getLogger(__name__)

NBU_API_URL = "https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?json"
_TARGET_CURRENCIES = {"EUR", "USD"}


class NBURatesService:
    """Fetch and cache NBU exchange rates for EUR and USD."""

    def __init__(self, cargo_repo: CargoRepository) -> None:
        self._cargo_repo = cargo_repo

    async def fetch_and_update(self) -> dict[str, float]:
        """Fetch EUR and USD rates from NBU API, store in exchange_rates.

        Returns:
            Dict mapping currency code to UAH rate, e.g. {"EUR": 45.5, "USD": 41.2}.

        Raises:
            httpx.HTTPError: On network/HTTP errors.
        """
        rates: dict[str, float] = {}
        today = date.today().isoformat()

        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(NBU_API_URL)
            resp.raise_for_status()
            data = resp.json()

        for item in data:
            cc = item.get("cc", "")
            if cc in _TARGET_CURRENCIES:
                rate = float(item["rate"])
                rates[cc] = rate
                await self._cargo_repo.update_exchange_rate(cc, rate, today)
                logger.info("NBU rate updated: %s = %.4f UAH", cc, rate)

        if not rates:
            logger.warning("No EUR/USD rates found in NBU response")

        return rates

    async def get_rate(self, currency: str) -> float | None:
        """Get cached exchange rate from DB."""
        return await self._cargo_repo.get_exchange_rate(currency.upper())

    async def convert_to_usd(self, amount: float, currency: str) -> float:
        """Convert amount to USD using cached NBU rates.

        Args:
            amount: Amount in source currency.
            currency: Source currency code (EUR/USD/UAH).

        Returns:
            Amount in USD.
        """
        currency = currency.upper()
        if currency == "USD":
            return amount

        usd_rate = await self._cargo_repo.get_exchange_rate("USD")
        if usd_rate is None:
            logger.warning("USD rate not available, returning amount as-is")
            return amount

        if currency == "UAH":
            return amount / usd_rate

        # Конвертація через UAH: source → UAH → USD
        source_rate = await self._cargo_repo.get_exchange_rate(currency)
        if source_rate is None:
            logger.warning("%s rate not available, returning amount as-is", currency)
            return amount

        amount_uah = amount * source_rate
        return amount_uah / usd_rate

    async def convert(
        self, amount: float, from_currency: str, to_currency: str
    ) -> float:
        """Convert between any two supported currencies via UAH.

        Args:
            amount: Amount in source currency.
            from_currency: Source currency code.
            to_currency: Target currency code.

        Returns:
            Amount in target currency.
        """
        from_currency = from_currency.upper()
        to_currency = to_currency.upper()

        if from_currency == to_currency:
            return amount

        # Конвертуємо через UAH
        if from_currency == "UAH":
            amount_uah = amount
        else:
            from_rate = await self._cargo_repo.get_exchange_rate(from_currency)
            if from_rate is None:
                return amount
            amount_uah = amount * from_rate

        if to_currency == "UAH":
            return amount_uah

        to_rate = await self._cargo_repo.get_exchange_rate(to_currency)
        if to_rate is None:
            return amount
        return amount_uah / to_rate
