"""Async wrapper around Claude API with retry and structured output."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, TypeVar

import anthropic
from pydantic import BaseModel

from src.exceptions import ClaudeAPIError

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)

# Відомі невалідні статуси → валідні DealStatus
_STATUS_FALLBACK: dict[str, str] = {
    "awaiting_price": "negotiating",
    "carrier_cancelled": "cancelled",
    "customer_cancelled": "cancelled",
    "pending": "prospecting",
    "in_progress": "in_transit",
    "active": "negotiating",
}

_VALID_DEAL_STATUSES = {
    "prospecting", "negotiating", "agreed",
    "in_transit", "completed", "cancelled", "disputed",
}

# Retryable HTTP status codes
_RETRYABLE_STATUSES = {429, 500, 503, 529}
_MAX_RETRIES = 3
_BASE_DELAY = 1.0  # seconds


class ClaudeClient:
    """Async Claude API client with exponential backoff retry."""

    def __init__(self, api_key: str, model: str = "claude-sonnet-4-6") -> None:
        self._client = anthropic.AsyncAnthropic(api_key=api_key)
        self._model = model

    async def call(
        self,
        system_prompt: str,
        user_message: str,
        temperature: float = 0.0,
        max_tokens: int = 1024,
        timeout: float = 30.0,
    ) -> str:
        """Call Claude API. Retry on 429/500/503 with exponential backoff.

        Args:
            system_prompt: System prompt text.
            user_message: User message text.
            temperature: Sampling temperature (0.0 = deterministic).
            max_tokens: Max output tokens.
            timeout: Request timeout in seconds.

        Returns:
            Raw text response from Claude.

        Raises:
            ClaudeAPIError: On non-retryable errors or after max retries.
        """
        last_error: Exception | None = None

        for attempt in range(_MAX_RETRIES):
            try:
                response = await self._client.messages.create(
                    model=self._model,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    system=system_prompt,
                    messages=[{"role": "user", "content": user_message}],
                    timeout=timeout,
                )
                text = response.content[0].text
                logger.debug(
                    "Claude API call: %d input tokens, %d output tokens",
                    response.usage.input_tokens,
                    response.usage.output_tokens,
                )
                return text

            except anthropic.RateLimitError as e:
                last_error = e
                delay = _BASE_DELAY * (2**attempt)
                logger.warning(
                    "Rate limited (%d/%d), retry in %.1fs",
                    attempt + 1, _MAX_RETRIES, delay,
                )
                await asyncio.sleep(delay)

            except anthropic.InternalServerError as e:
                last_error = e
                delay = _BASE_DELAY * (2**attempt)
                logger.warning(
                    "Server error (%d/%d), retry in %.1fs",
                    attempt + 1, _MAX_RETRIES, delay,
                )
                await asyncio.sleep(delay)

            except anthropic.APIStatusError as e:
                if e.status_code in _RETRYABLE_STATUSES:
                    last_error = e
                    delay = _BASE_DELAY * (2**attempt)
                    logger.warning(
                        "Status %d (%d/%d), retry in %.1fs",
                        e.status_code, attempt + 1, _MAX_RETRIES, delay,
                    )
                    await asyncio.sleep(delay)
                else:
                    raise ClaudeAPIError(
                        str(e), status_code=e.status_code,
                    ) from e

            except anthropic.APIConnectionError as e:
                last_error = e
                delay = _BASE_DELAY * (2**attempt)
                logger.warning(
                    "Connection error (%d/%d), retry in %.1fs",
                    attempt + 1, _MAX_RETRIES, delay,
                )
                await asyncio.sleep(delay)

        raise ClaudeAPIError(f"Max retries exceeded: {last_error}") from last_error

    async def call_json(
        self,
        system_prompt: str,
        user_message: str,
        response_model: type[T],
        temperature: float = 0.0,
        max_tokens: int = 1024,
        timeout: float = 30.0,
    ) -> T:
        """Call Claude API and parse JSON response into a Pydantic model.

        Args:
            system_prompt: System prompt text.
            user_message: User message text.
            response_model: Pydantic model class to parse response into.
            temperature: Sampling temperature.
            max_tokens: Max output tokens.
            timeout: Request timeout in seconds.

        Returns:
            Parsed Pydantic model instance.

        Raises:
            ClaudeAPIError: On API errors or invalid JSON.
        """
        raw = await self.call(
            system_prompt=system_prompt,
            user_message=user_message,
            temperature=temperature,
            max_tokens=max_tokens,
            timeout=timeout,
        )

        # Очищення від markdown code blocks
        text = raw.strip()
        if text.startswith("```json"):
            text = text[7:]
        elif text.startswith("```"):
            text = text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

        try:
            data = json.loads(text)
        except json.JSONDecodeError as e:
            logger.error("Invalid JSON from Claude: %s\nRaw: %s", e, raw[:500])
            raise ClaudeAPIError(f"Invalid JSON response: {e}") from e

        _sanitize_deal_statuses(data)

        try:
            return response_model.model_validate(data)
        except Exception as e:
            logger.error("Pydantic validation failed: %s\nData: %s", e, str(data)[:500])
            raise ClaudeAPIError(f"Response validation failed: {e}") from e

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.close()


def _sanitize_deal_statuses(data: dict[str, Any]) -> None:
    """Replace known invalid deal statuses with valid ones in-place.

    Walks through 'actions' list in the response and fixes any
    'new_status' values that AI might hallucinate.
    """
    actions = data.get("actions")
    if not isinstance(actions, list):
        return
    for action in actions:
        if not isinstance(action, dict):
            continue
        new_status = action.get("new_status")
        if new_status is None:
            continue
        if new_status in _VALID_DEAL_STATUSES:
            continue
        replacement = _STATUS_FALLBACK.get(new_status)
        if replacement:
            logger.warning(
                "Sanitized invalid deal status %r → %r",
                new_status, replacement,
            )
            action["new_status"] = replacement
        else:
            logger.warning(
                "Unknown deal status %r, removing from action",
                new_status,
            )
            action["new_status"] = None
