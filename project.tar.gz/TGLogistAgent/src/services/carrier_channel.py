"""Carrier channel service — publish cargo offers to Telegram channel (WF-9)."""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta

from telethon import TelegramClient

logger = logging.getLogger(__name__)


class CarrierChannelService:
    """Publish cargo offers to the carrier Telegram channel."""

    def __init__(self, client: TelegramClient, channel_id: int) -> None:
        self._client = client
        self._channel_id = channel_id
        self._recent_publications: dict[str, datetime] = {}

    async def publish_cargo(
        self,
        route: str,
        container_type: str | None,
        weight: float | None,
        departure_date: str | None,
    ) -> int | None:
        """Publish a cargo offer to the carrier channel.

        Args:
            route: e.g. "Гданськ→Київ"
            container_type: e.g. "40HC"
            weight: Weight in tons.
            departure_date: Departure date string.

        Returns:
            Telegram message ID, or None if skipped.
        """
        if not self._channel_id:
            logger.warning("Carrier channel not configured")
            return None

        if self.is_recently_published(route):
            logger.info("Route %s was recently published, skipping", route)
            return None

        parts = [route]
        if container_type:
            parts.append(f"{container_type}")
        if weight:
            parts.append(f"{weight:.0f}т")
        if departure_date:
            parts.append(departure_date)
        parts.append("Хто вільний?")

        text = ", ".join(parts)

        try:
            msg = await self._client.send_message(self._channel_id, text)
            self._recent_publications[route] = datetime.now(tz=UTC)
            logger.info("Published to carrier channel: %s", text)
            return msg.id
        except Exception:
            logger.exception("Failed to publish to carrier channel")
            return None

    def is_recently_published(self, route: str) -> bool:
        """Check if this route was published within the last hour."""
        last = self._recent_publications.get(route)
        if last is None:
            return False
        return datetime.now(tz=UTC) - last < timedelta(hours=1)
