# LogistAgent

Автономний Telegram-агент логістичного посередника. Контейнерний імпорт Польща→Україна.
Python 3.11+, Telethon (userbot), python-telegram-bot (адмін-бот), aiosqlite, Claude API.

## Команди

```bash
uv run python src/main.py              # Запуск агента
uv run pytest tests/ -x                # Тести (зупинка на першому fail)
uv run mypy --strict src/              # Type check
uv run ruff check src/                 # Lint
uv run ruff format src/                # Format
uv run python src/db/migrations.py     # Міграція БД
```

## Архітектура

Потік даних: Telegram-група → Parser → Matcher → Deal Manager → Responder → Telegram DM

```
src/
├── config.py                  # Конфігурація, env, константи
├── main.py                    # Entry point, async event loop
├── models/                    # Pydantic-схеми (shared across layers)
├── db/                        # SQLite через aiosqlite, repository pattern
│   ├── schema.sql
│   ├── migrations.py
│   └── repositories/          # Весь доступ до БД — тільки через репозиторії
├── parser/                    # Моніторинг Telegram-груп (WF-1)
│   ├── group_monitor.py       # Telethon event handler
│   └── message_analyzer.py    # Claude API аналіз повідомлень
├── agent/                     # Ядро AI-агента
│   ├── codex.py               # Завантаження system prompt
│   ├── router.py              # Визначення контексту повідомлення (WF-4)
│   ├── matcher.py             # AI-based матчинг вантаж↔перевізник (WF-2)
│   ├── context.py             # Context Assembly по зонам
│   ├── responder.py           # Генерація відповідей (головний промпт)
│   └── verification.py        # Верифікація водіїв/дублікатів (WF-11)
├── deals/                     # Управління угодами (WF-3, WF-6, WF-7)
│   ├── manager.py
│   ├── documents.py
│   └── templates.py
├── services/                  # Зовнішні сервіси
│   ├── nbu_rates.py           # Курс НБУ (api.bank.gov.ua)
│   └── carrier_channel.py     # Публікація в Telegram-канал (WF-9)
├── profiler/                  # Оновлення профілів після взаємодій (WF-4.9)
│   └── profiler.py
├── monitoring/                # Health checks (кожні 5-10 хв)
│   └── health.py
├── notifications/             # Алерти оператору
│   └── notifier.py
└── bot/                       # Приватний Telegram-бот оператора (whitelist)
    ├── telegram_bot.py        # Команди: /resolve, /cancel, /health, /who
    └── contact_briefing.py    # AI-брифінг контакту (WF-12)
```

## 4 зони контексту (Context Isolation)

AI НІКОЛИ не отримує повний контекст. Кожен виклик — мінімальний зріз потрібних зон:
- **Зона 1** — актуальні вантажі/транспорт (cargo_offers)
- **Зона 2** — активні угоди (deals, deal_events)
- **Зона 3** — контакти + аналітика (contacts, psychology, reliability, prices)
- **Зона 4** — документи угод (deal_documents)

## 6 AI-промптів

| Промпт | Тип | Файл | Temperature |
|--------|-----|------|-------------|
| Responder | головний | prompts/agent_codex.md | 0.3 |
| Parser | побічний | prompts/parser_prompt.md | 0 |
| Matcher | побічний | prompts/matcher_prompt.md | 0 |
| Profiler | побічний | prompts/profiler_prompt.md | 0 |
| Verification | побічний | prompts/verification_prompt.md | 0 |
| Contact Briefing | побічний | prompts/contact_briefing_prompt.md | 0.3 |

## Конвенції

- **Async everywhere:** `async def` для всіх I/O операцій
- **Type hints** на ВСІХ сигнатурах, `mypy --strict`
- **Pydantic моделі** замість raw dict для всіх структур даних
- **Repository pattern:** весь доступ до БД через `src/db/repositories/`
- **DI через конструктори:** залежності передаються явно
- **Функції < 50 рядків, файли < 500 рядків**
- **Google-style docstrings** на всіх public функціях
- **JSON output** від всіх AI-промптів (structured output)
- **Мова коду:** англійська (назви, docstrings). Коментарі, промпти — українська

## Два Telegram-клієнти

1. **Userbot (Telethon)** — ВСЯ комунікація з контактами: моніторинг груп, DM, канал перевізників
2. **Адмін-бот (python-telegram-bot)** — виключно для оператора: нотифікації, команди, /who

## Ніколи

- Не використовуй raw SQL поза repository layer
- Не використовуй bare `except` — завжди конкретний тип
- Не використовуй блокуючий I/O в async handlers
- Не використовуй глобальний mutable state
- Не додавай `type: ignore`
- Не розкривай маржу, базу контактів, рейтинги в тексті для контакту
- Не передавай повний контекст всієї системи в AI-виклик
- Не модифікуй профіль контакту під час формування відповіді — тільки через окремий виклик Profiler (on-demand, коли Responder вирішить через action: update_profile)
- Не веди паралельні переговори за одне авто-місце з кількома перевізниками

## Документація

Повна проектна документація: `Docs/Design_docs/01..11_*.md`
Тестові сценарії: `Docs/Test_scenarios/01..08_*.md`
Змінні промптів: `Docs/Design_docs/variable-registry.md`
